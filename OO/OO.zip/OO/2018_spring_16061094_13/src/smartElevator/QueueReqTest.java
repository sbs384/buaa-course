package smartElevator;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class QueueReqTest {
	private QueueReq queue;

	@Before
	public void before() {
		queue=new QueueReq();
	}
	
	@After
	public void after() {
		queue=null;
	}
	
	@Test
	public void testRepOK() {
		assertEquals(true,queue.repOK());
		
		queue.setQueEfficient();
		assertEquals(false,queue.repOK());
	}
	
	@Test
	public void testManage() {
		int result;
		Request request_0=new Request("(FR,1,UP,1)");
		Request request_1=new Request("(FR,2,UP,0)");
		Request request_2=new Request("(ER,1,0)");
		Request request0=new Request("(FR,1,UP,0)");
		Request request1=new Request("(FR,2,UP,0)");
		Request request2=new Request("(ER,2,1)");
		Request request3=new Request("(ER,2,0)");
	
		result=queue.manage(request_0);
		assertEquals(1,result);
		assertEquals(0,queue.Len());
		
		result=queue.manage(request_1);
		assertEquals(1,result);
		assertEquals(0,queue.Len());
		
		result=queue.manage(request_2);
		assertEquals(1,result);
		assertEquals(0,queue.Len());
		
		result=queue.manage(request0);
		assertEquals(0,result);
		assertEquals(1,queue.Len());
		
		result=queue.manage(request1);
		assertEquals(0,result);
		assertEquals(2,queue.Len());
		
		result=queue.manage(request2);
		assertEquals(0,result);
		assertEquals(3,queue.Len());
		
		result=queue.manage(request3);
		assertEquals(1,result);
		assertEquals(3,queue.Len());
	}

}
