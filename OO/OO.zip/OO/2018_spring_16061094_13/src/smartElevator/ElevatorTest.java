package smartElevator;

import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.contrib.java.lang.system.SystemOutRule;

public class ElevatorTest {
	
	private Elevator ele;
	
	@Before
	public void before() {
		ele=new Elevator();
	}
	
	@After
	public void after() {
		ele=null;
	}
	
	@Rule
	public final SystemOutRule log = new SystemOutRule().enableLog();
	
	@Test
	public void testRepOK() {
		assertEquals(true,ele.repOK());
		
		ele.setMarkNull();
		assertEquals(false,ele.repOK());
		
		ele.setrSet(null);
		assertEquals(false,ele.repOK());
		
		ele.setrCom(null);
		assertEquals(false,ele.repOK());
		
		ele.setMDir(2);
		assertEquals(false,ele.repOK());
		
		ele.setOF(-1);
		assertEquals(false,ele.repOK());
		
		ele.setDestFloor(-1);
		assertEquals(false,ele.repOK());
		
		ele.setStartFloor(-1);
		assertEquals(false,ele.repOK());
		
		ele.setMDestTime(null);
		assertEquals(false,ele.repOK());
		
		ele.setMstaTime(null);
		assertEquals(false,ele.repOK());
		
		ele.setOT(null);
		assertEquals(false,ele.repOK());
	
	
	}


	@Test
	public void testMainExist() {
		List <Request> rSet=new ArrayList <Request> ();
		ele.setrSet(rSet);
		assertEquals(false,ele.MainExist());
		rSet.add(new Request("(FR,1,UP,0)"));
		assertEquals(true,ele.MainExist());
	}
	

	@Test
	public void testMain() {
		Request r;
		
		r=new Request("(ER,1,0)");
		ele.Main(r);
		assertEquals(-1,ele.getMDir());
		assertEquals(new BigDecimal("0"),ele.getOT());
		assertEquals(new BigDecimal("0"),ele.getMDestTime());
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		r=new Request("(ER,2,0)");
		ele.setOT(new BigDecimal("1"));
		ele.Main(r);
		assertEquals(1,ele.getMDir());
		assertEquals(new BigDecimal("1"),ele.getOT());
		assertEquals(new BigDecimal("1.5"),ele.getMDestTime());
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		r=new Request("(ER,2,4)");
		ele.setOT(new BigDecimal("2"));
		ele.setOF(3);
		ele.Main(r);
		assertEquals(0,ele.getMDir());
		assertEquals(new BigDecimal("4"),ele.getOT());
		assertEquals(new BigDecimal("4.5"),ele.getMDestTime());
		assertEquals(1,ele.rSetLen());
	
	}
	

	@Test
	public void testByWay() {
		List <Request> rSet=new ArrayList <Request> ();
		
		assertEquals(false,ele.ByWay(new Request("(FR,1,UP,0)")));
		
		ele.setMDir(0);
		ele.setMstaTime(new BigDecimal("2"));
		rSet.add(new Request("(FR,1,UP,0)"));
		ele.setrSet(rSet);
		assertEquals(false,ele.ByWay(new Request("(FR,2,UP,0)")));
	}
	

	@Test
	public void testLitByway() {
		//ask=1;
		ele.setMDir(-1);
		assertEquals(false,ele.litByway(new Request("(FR,1,UP,0)")));
		assertEquals(0,ele.rSetLen());
		
		ele.setMDir(1);
		ele.setStartFloor(2);
		ele.setDestFloor(4);
		assertEquals(true,ele.litByway(new Request("(FR,3,UP,0)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(FR,1,UP,0)")));
		assertEquals(0,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(FR,5,UP,0)")));
		assertEquals(0,ele.rSetLen());
		
		
		//ask=2;
		ele.setMDir(1);
		assertEquals(false,ele.litByway(new Request("(FR,3,DOWN,0)")));
		assertEquals(0,ele.rSetLen());
		
		ele.setMDir(0);
		ele.setStartFloor(4);
		ele.setDestFloor(2);
		assertEquals(true,ele.litByway(new Request("(FR,3,DOWN,0)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(FR,1,DOWN,0)")));
		assertEquals(0,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(FR,5,DOWN,0)")));
		assertEquals(0,ele.rSetLen());
		
		
		//ask=3;
		//MDir=-1;
		ele.setMDir(-1);
		assertEquals(false,ele.litByway(new Request("(ER,2,0)")));
		assertEquals(0,ele.rSetLen());
		
		//MDir=1;
		ele.rSetClear();
		ele.setMDir(1);
		ele.setStartFloor(4);
		assertEquals(true,ele.litByway(new Request("(ER,5,0)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(ER,3,0)")));
		assertEquals(0,ele.rSetLen());
		
		//MDir=0;
		ele.rSetClear();
		ele.setMDir(0);
		ele.setStartFloor(4);
		assertEquals(true,ele.litByway(new Request("(ER,3,0)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.litByway(new Request("(ER,5,0)")));
		assertEquals(0,ele.rSetLen());
	}
	

	@Test
	public void testBigByway() {
		//ComPareTime>=0;
		assertEquals(false,ele.bigByway(new Request("(FR,1,UP,0)")));
		
		//CompareTime<0;
		//ask=1;
		ele.setMDir(-1);
		ele.setMDestTime(new BigDecimal("1"));
		assertEquals(false,ele.bigByway(new Request("(FR,2,UP,0)")));
		
		ele.setMDir(1);
		ele.setMstaTime(new BigDecimal("0"));
		ele.setMDestTime(new BigDecimal("3"));
		ele.setStartFloor(1);
		ele.setDestFloor(7);
		assertEquals(true,ele.bigByway(new Request("(FR,4,UP,1)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.bigByway(new Request("(FR,2,UP,1)")));
		assertEquals(0,ele.rSetLen());
		
		assertEquals(false,ele.bigByway(new Request("(FR,8,UP,1)")));
		assertEquals(0,ele.rSetLen());
		
		//ask=2;
		ele.setMDir(-1);
		assertEquals(false,ele.bigByway(new Request("(FR,2,DOWN,0)")));
		
		ele.rSetClear();
		ele.setMDir(0); 
		ele.setMstaTime(new BigDecimal("4"));
		ele.setMDestTime(new BigDecimal("6"));
		ele.setStartFloor(7);
		ele.setDestFloor(3);
		assertEquals(true,ele.bigByway(new Request("(FR,4,DOWN,5)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.bigByway(new Request("(FR,6,DOWN,5)")));
		assertEquals(0,ele.rSetLen());
		
		assertEquals(false,ele.bigByway(new Request("(FR,1,DOWN,5)")));
		assertEquals(0,ele.rSetLen());
		
		//ask=3;
		//MDir=-1;
		ele.setMDir(-1);
		assertEquals(false,ele.bigByway(new Request("(ER,2,0)")));
		
		//MDir=1;
		ele.setMDir(1);
		ele.setMstaTime(new BigDecimal("0"));
		ele.setMDestTime(new BigDecimal("3"));
		ele.setStartFloor(1);
		ele.setDestFloor(7);
		assertEquals(true,ele.bigByway(new Request("(ER,4,1)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.bigByway(new Request("(ER,2,1)")));
		assertEquals(0,ele.rSetLen());
		
		//MDir=0;
		ele.setMDir(0);
		ele.setMstaTime(new BigDecimal("4"));
		ele.setMDestTime(new BigDecimal("6"));
		ele.setStartFloor(7);
		ele.setDestFloor(3);
		assertEquals(true,ele.bigByway(new Request("(ER,4,5)")));
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		assertEquals(false,ele.bigByway(new Request("(ER,6,5)")));
		assertEquals(0,ele.rSetLen());
		
	}
	

	@Test
	public void testCurfloor() {
		int floor;
		
		ele.setMstaTime(new BigDecimal("0"));
		ele.setStartFloor(1);
		floor=ele.curfloor(new Request("(ER,1,0)"));
		assertEquals(1,floor);
		
		ele.setStartFloor(1);
		ele.setMDir(1); 
		ele.setMark(2);
		floor=ele.curfloor(new Request("(ER,2,1)"));
		assertEquals(2,floor);
	
		ele.setMstaTime(new BigDecimal("2"));
		ele.setStartFloor(4);
		ele.setMDir(0);
		ele.setMark(2);
		floor=ele.curfloor(new Request("(ER,2,3)"));
		assertEquals(2,floor);
		
	}

	
	@Test
	public void testRSetInsert() {
		List <Request> rSet=new ArrayList <Request> ();
		Request r;
		ele.setrSet(rSet);
		
		//Mdir=1;
		ele.setMDir(1);
		
		//equal=1;big=0;i=size-1;
		ele.setDestFloor(1);
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,1,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		
		ele.setDestFloor(2);
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,1,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		
		assertEquals(1,ele.mark(1));
		assertEquals(1,ele.rFloor(1));
		assertEquals(1,ele.rAsk(1));
		
		
		
		//equal=1;big=0;i!=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,1,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(FR,1,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(1));
		assertEquals(1,ele.rFloor(1));
		assertEquals(1,ele.rAsk(1));
		
		//equal=1;big=1;i=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(FR,1,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(1));
		assertEquals(1,ele.rFloor(1));
		assertEquals(1,ele.rAsk(1));
		
		//equal=1;big=1;i!=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,1,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(3);
		rSet.add(r);
		r=new Request("(FR,1,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(1));
		assertEquals(1,ele.rFloor(1));
		assertEquals(1,ele.rAsk(1));
		
		
		//equal=0;big=0;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,2,UP,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(1,ele.rAsk(1));
		
		//equal=0;big=1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,1,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,3,UP,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(3,ele.rAsk(1));
		
		
		//MDir=0;
		ele.setMDir(0);
		
		//equal=1;lit=0;i=size-1;
		ele.setDestFloor(1);
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,2,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		
		ele.setDestFloor(3);
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,2,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(2,ele.rAsk(1));
		
		//equal=1;lit=0;i!=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(FR,2,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(2,ele.rAsk(1));
		
		//equal=1;lit=1;i=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,1,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(FR,2,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(2,ele.rAsk(1));
		
		//equal=1;lit=1;i!=size-1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(2); 
		rSet.add(r);
		r=new Request("(ER,1,0)");
		r.setOrder(3);
		rSet.add(r);
		r=new Request("(FR,2,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(2,ele.rAsk(1));
		
		//equal=0;lit=0;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,2,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,1,DOWN,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(1));
		assertEquals(1,ele.rFloor(1));
		assertEquals(2,ele.rAsk(1));
		
		//equal=0;lit=1;
		ele.rSetClear();
		ele.markClear();
		r=new Request("(ER,3,0)");
		r.setOrder(0);
		rSet.add(r);
		r=new Request("(FR,1,DOWN,0)");
		r.setOrder(2);
		rSet.add(r);
		r=new Request("(ER,2,0)");
		r.setOrder(1);
		ele.rSetInsert(r);
		assertEquals(1,ele.mark(2));
		assertEquals(2,ele.rFloor(1));
		assertEquals(3,ele.rAsk(1));
		
	}
	
	@Test
	public void testCurMDone() {
		List <Request> rSet=new ArrayList <Request> ();
		ele.setrSet(rSet);
		assertNull(ele.curMDone());
		
		ele.setOF(1);
		ele.setOT(new BigDecimal("0"));
		ele.setMDir(1);
		ele.setDestFloor(3);
		rSet.add(new Request("(ER,1,0)"));
		rSet.add(new Request("(ER,3,0)"));
		assertNotNull(ele.curMDone());
		assertEquals(2,ele.rComLen());
		assertEquals(0,ele.rSetLen());
		
		ele.rSetClear();
		ele.rComClear();
		ele.setOF(0);
		ele.setOT(new BigDecimal("0"));
		ele.setMDir(1);
		ele.setDestFloor(2);
		rSet.add(new Request("(ER,2,0)"));
		rSet.add(new Request("(ER,3,0)"));
		assertNotNull(ele.curMDone());
		assertEquals(1,ele.rComLen());
		assertEquals(1,ele.rSetLen());
		
		ele.rSetClear();
		ele.rComClear();
		ele.setOF(0);
		ele.setOT(new BigDecimal("0"));
		ele.setMDir(-1);
		ele.setDestFloor(1);
		rSet.add(new Request("(ER,1,0)"));
		assertNotNull(ele.curMDone());
		assertEquals(1,ele.rComLen());
		assertEquals(0,ele.rSetLen());
		
		ele.rSetClear();
		ele.rComClear();
		ele.setOF(3);
		ele.setOT(new BigDecimal("2"));
		ele.setMDir(0);
		ele.setDestFloor(1);
		rSet.add(new Request("(ER,2,0)"));
		rSet.add(new Request("(FR,1,DOWN,0)"));
		assertNotNull(ele.curMDone());
		assertEquals(2,ele.rComLen());
		assertEquals(0,ele.rSetLen());
		
		ele.rSetClear();
		ele.rComClear();
		ele.setOF(3);
		ele.setOT(new BigDecimal("2"));
		ele.setMDir(0);
		ele.setDestFloor(2);
		rSet.add(new Request("(ER,2,0)"));
		rSet.add(new Request("(FR,1,DOWN,0)"));
		assertNotNull(ele.curMDone());
		assertEquals(1,ele.rComLen());
		assertEquals(1,ele.rSetLen());
	}
	
	
	@Test
	public void testPrint() {
		ele.setOF(2);
		ele.setMDir(1);
		ele.setOT(new BigDecimal("1.5"));
		log.clearLog();
		ele.print(new Request("(FR,2,UP,0)"));
		assertEquals("[FR,2,UP,0]/(2,UP,0.5)\r\n",log.getLog());
		
		ele.setMDir(-1);
		ele.setOT(new BigDecimal("2"));
		log.clearLog();
		ele.print(new Request("(ER,2,2)"));
		assertEquals("[ER,2,2]/(2,STILL,3.0)\r\n",log.getLog());
		
		ele.setOF(3);
		ele.setMDir(0);
		ele.setOT(new BigDecimal("2"));
		log.clearLog();
		ele.print(new Request("(FR,1,DOWN,0)"));
		assertEquals("[FR,1,DOWN,0]/(1,DOWN,3.0)\r\n",log.getLog());
		
		ele.setOF(2);
		ele.setMDir(1);
		ele.setOT(new BigDecimal("2"));
		log.clearLog();
		ele.print(new Request("(FR,4,UP,0)"));
		assertEquals("[FR,4,UP,0]/(4,UP,3.0)\r\n",log.getLog());
	}
	

	@Test
	public void testFindCom() {
		boolean result;
		List <Request> rCom=new ArrayList <Request>();
		rCom.add(new Request("(ER,1,0)"));
		ele.setrCom(rCom);
		
		result=ele.findCom(new Request("(FR,2,UP,2)"));
		assertEquals(false,result);
		
		result=ele.findCom(new Request("ER,1,1)"));
		assertEquals(true,result);	
	}
	

	@Test
	public void testFindSet() {
		boolean result;
		List <Request> rSet=new ArrayList <Request>();
		rSet.add(new Request("(ER,1,0)"));
		ele.setrSet(rSet);
		
		result=ele.findSet(new Request("(FR,2,UP,2)"));
		assertEquals(false,result);
		
		result=ele.findSet(new Request("(ER,1,1)"));
		assertEquals(true,result);	
	}

	
	@Test
	public void testLimitCom() {
		Request request1=new Request("(ER,1,1)");
		request1.setLimit(new BigDecimal("2"));
		ele.rComAdd(request1);
		
		assertEquals(new BigDecimal("2"),ele.limitCom(new Request("(ER,1,2)")));
	}

}
