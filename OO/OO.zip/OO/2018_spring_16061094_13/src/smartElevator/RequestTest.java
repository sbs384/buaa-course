package smartElevator;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RequestTest {

	private Request request=new Request("(ER,3,2)");
	private Request requestNull=null;
	private QueueReq requestObj=new QueueReq();
	private Request requestFloor=new Request("(ER,2,02)");
	private Request requestAsk=new Request("(FR,+03,UP,+2)");
	private Request requestSame=new Request("(ER,+03,3)");
	
	private Request requestNothing1=new Request("(ER,+03,+4294967296)");
	private Request requestNothing2=new Request("(ER,+03,4294967296)");
	private Request requestNothing3=new Request("(ER,3a0)");
	private Request requestNothing4=new Request("(ER,3,+0a");
	private Request requestNothing5=new Request("(ER,1,a)");
	private Request requestNothing6=new Request("(ER,3,0a");
	private Request requestNothing7=new Request("(FR,3,DOWN,02)");
	
	
	@Test
	public void testEqualsObject() {
		boolean result;
		
		result=request.equals(request);
		assertEquals(true,result);
		
		result=request.equals(requestNull);
		assertEquals(false,result);
		
		result=request.equals(requestObj);
		assertEquals(false,result);
		
		result=request.equals(requestFloor);
		assertEquals(false,result);
		
		result=request.equals(requestAsk);
		assertEquals(false,result); 
		
		result=request.equals(requestSame);
		assertEquals(true,result);
	}

}
