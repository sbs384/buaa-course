package smartElevator;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MainTest {
	private Main main;

	@Before
	public void before() {
		main=new Main();
	}
	
	@After
	public void after() {
		main=null;
	}
	
	@Test
	public void testOpStr() {
		String result;
		String s="(FR,UP,  1,  1 0)";
		
		result=main.opStr(s);
		assertEquals("(FR,UP,1,10)",result);
	}

	@Test
	public void testJudgeInput() {	
		boolean result;
		
		result=main.judgeInput("(FR,1,UP,10)");
		assertEquals(true,result);
		
		result=main.judgeInput("(FR,10,UP,10)");
		assertEquals(false,result);
		
		result=main.judgeInput("(FR,2,DOWN,10)");
		assertEquals(true,result);
		
		result=main.judgeInput("(FR,1,DOWN,10)");
		assertEquals(false,result);
		
		result=main.judgeInput("(ER,10,10)");
		assertEquals(true,result);
		
		result=main.judgeInput("(ER,a,0)");
		assertEquals(false,result);
		
	}

}
