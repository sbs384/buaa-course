package smartElevator;
import java.util.Scanner;

 
public class Main {
	/*Overview:处理输入并且完成电梯运行的模拟*/
	
	public boolean repOK() {
		/**@REQUIRES:None;
        *@MODIFIES:None;
        *@EFFECTS:
        *		\result==true;;
        */
		
		return true;
	}
	
	public Main() {
		
	}
	
	//对输入的字符串进行处理
	public String opStr(String s) {
		 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==s.replaceAll("\\s+","");
         */
		
		String regexSp="\\s+";
		String strOp=s.replaceAll(regexSp,"");
		return strOp;
	}
	 
	//判断输入的请求是否合法
	public boolean judgeInput(String s) {
		 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==((s.matches(regex1)) || (s.matches(regex2)) || (s.matches(regex3))); 
         */
		
		String regex1="^\\(FR,[+]?0{0,100}[1-9],UP,[+]?0*\\d{1,10}\\)$";
		String regex2="^\\(FR,[+]?0{0,100}([2-9]|(10)),DOWN,[+]?0*\\d{1,10}\\)$";
		String regex3="^\\(ER,[+]?0{0,100}([1-9]|(10)),[+]?0*\\d{1,10}\\)$";
		
		
		if(s.matches(regex1)) return true;
		if(s.matches(regex2)) return true;
		if(s.matches(regex3)) return true;
		return false;
	} 
	
	public void input(QueueReq queue) {
		 /**@REQUIRES:queue!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		input the requires;
         */
		
		boolean resInput=false;
		int resManage=-1,inputNum=0;
		
		Scanner keyboard=new Scanner(System.in);
		String input=keyboard.nextLine();
		++inputNum;
		
		if(input.equals("RUN")) {
			System.out.println("#ERROR");
			System.out.println("#No request!Please run again!");
			System.exit(1);
		}
		
		//对输入的请求进行处理
		while(!input.equals("RUN")) {

			String inputOp=opStr(input);
			resInput=judgeInput(inputOp);
			
			if(resInput) {
				Request request=new Request(inputOp);
			
				if (request.flow()==1) {
					System.out.println("INVALID["+inputOp+"]");
				}
				else {
					resManage=queue.manage(request);
					if(resManage==1) System.out.println("INVALID["+inputOp+"]");
				}
			}
			
			
			else{
				System.out.println("INVALID["+inputOp+"]");
			}
			
			input=keyboard.nextLine();
			++inputNum;
			if(!input.equals("RUN") && inputNum==101) {
				System.out.println("#ERROR");
				System.out.println("#The number of request is more than 100!Please run again!");
				break;
			}
		}
		
		keyboard.close();
	}

	public static void main(String[] args) {
		 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		完成电梯运行实例;
         *		出现异常情况==>exceptional_behavior(Exception e);
         */
		
		//初始化相关对象实例
		Main main=new Main();
		QueueReq queue=new QueueReq();
		Elevator elevator=new Elevator();
		Controller controller=new Controller();
		
		try {
			main.input(queue);
		     
			if(queue.Len()==0) {
				System.out.println("#ERROR");
				System.out.println("#There's no legal request!Please run again!");
				System.exit(1);
			}
			   
		    //调用控制方法
            controller.deal(queue,elevator);
            System.exit(0);
			
		}catch(Exception e) {
			System.out.println("#ERROR");
			System.out.println("#Crush Error!Please run again!");
			System.exit(1);
		}

	}

}
