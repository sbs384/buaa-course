package smartElevator;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Controller{
	/*Overview:Controller类对请求进行调度*/
	
	public boolean repOK() {
		/** @REQUIRES:None;
        *@MODIFIES:None;
        *@EFFECTS:
        * 		\result==true; 
        */
		
		return true;
	}
	
	public Controller() {
		
	}
	
	public void deal(QueueReq Queue,Elevator e) {
		 /**@REQUIRES:Queue!=null && Queue.size!=0  && e!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		对请求进行调度
         */
		
		 List <Request> res=new ArrayList <Request>();
		 List <Request> queue=new ArrayList <Request>();
		 int i,k,sign,result;
		 Queue.queOut(queue);
		 
		 while(queue.size()!=0) {
			 k=0;
			 sign=0;
			 
			 while(sign==0) {
				 result=control(queue,queue.get(k),e);
				 if(result==0) {
					 if(queue.size()==0 || k==queue.size()) sign=1; 
				 }
				 else {
					 if(k==queue.size()-1) sign=1;
					 else ++k;
				 }
			 }
			 
			 e.curMDone(res); 
			 if(res!=null) {
				 for(i=res.size()-1;i>=0;i--) queue.add(0,res.get(i));
				 for(i=res.size()-1;i>=0;i--) res.remove(i);
			 }
		 }
	}
	

	public int control(List <Request> queue,Request r,Elevator e) {
		 /**@REQUIRE:queue!=null && r!=null && e!=null && i>=0 && i<queue.size();
         *@MODIFIES:None;
         *@EFFECTS:
         *		schedule(r,e)==0 ==> \result==0;
         *		schedule(r,e)==1 ==> \result==1;
         *		(schedule(r,e)==2 && e.MainExist()==true && e.ByWay(r)==true ==> \result==0;
         *		(schedule(r,e)==2 && e.MainExist()==true && e.ByWay(r)==false ==> \result==1;
         *		(schedule(r,e)==2 && e.MainExist()==false) ==> \result==0;
         */
		
		
		/*schedule==0,同质，删除
		 * schedule==1,跳过
		 * schedule==2非同质-->捎带：删除
		 *                 -->非捎带：跳过
		 *                 
		 * 删除：队列是否为空，是否为最后一个元素
		 * 跳过：是否还有下一个元素
		*/
		
		if(schedule(r,e)==0) {
			queue.remove(r);
			printSame(r);
			return 0;
		}
		
		else if(schedule(r,e)==1) return 1;
		
		else{
			if(e.MainExist()) {
				if(e.ByWay(r)) {
					queue.remove(r);
					return 0;
				}
				else return 1;
			}
			
			else {
				e.Main(r);
				queue.remove(r);
				return 0;
			}
		}
		
	}   
	
	public void printSame(Request r) {
		 /**@REQUIRES:r!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		System.out.println("#SAME[request]");
         */
		
		System.out.print("#SAME");
		if(r.ask()==1)        System.out.println("["+"FR"+","+r.floor()+","+"UP"+","+r.time()+"]");
		else if(r.ask()==2)   System.out.println("["+"FR"+","+r.floor()+","+"DOWN"+","+r.time()+"]");
		else                  System.out.println("["+"ER"+","+r.floor()+","+r.time()+"]");
	}
	
	
	public int schedule(Request r,Elevator e) {
		 /**@REQUIRES:r!=null && e!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		(e.findCom(r)==true && r.time().compareTo(e.limitCom(r))<=0)==> \result==0;
         *		(e.findCom(r)==true && r.time().compareTo(e.limitCom(r))>0 && e.findSet(r)==true) ==> \result==1;
         *		(e.findCom(r)==true && r.time().compareTo(e.limitCom(r))>0 && e.findSet(r)==false)==> \result==2;
         *		(e.findCom(r)==false && e.findSet(r)==true) ==> \result==1;
         *		(e.findCom(r)==false && e.findSet(r)==false) ==> \result==2;
         */
		
		BigDecimal limitTime;
		
		if(e.findCom(r)) {
			limitTime=e.limitCom(r);
			if(r.time().compareTo(limitTime)<=0) return 0;
			else {
				if(e.findSet(r)) return 1;
				else return 2;
			}
		}
		
		else {
			if(e.findSet(r)) return 1;
			else return 2;
		}
		
	}

}
