package smartElevator;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
 
public class Elevator extends Object implements Iemethod {
	/*Overview:Elevator类模拟电梯运动*/
	
    private BigDecimal OT=new BigDecimal("0");
    private BigDecimal MStaTime=new BigDecimal("0");
    private BigDecimal MDestTime=new BigDecimal("0");
    private int MStaF=0;
    private int MDestF=0;
    private int OF=1;
    private int MDir;
	private List <Request> rCom=new ArrayList <Request>();
	private List <Request> rSet=new ArrayList <Request>();
	private int mark[]=new int [11];
	private String out;
	
	
	public boolean repOK() {
		/** @REQUIRES:None;
        *@MODIFIES:None;
        *@EFFECTS:
        * 		\result==!(OT==null || MStaTime==null || MDestTime==null || MStaF<1 || MStaF>10|| MDestF<1||MDestF>10 || OF<1 ||OF>10|| (MDir!=1 && MDir!=0 && MDir!=-1) ||
		*		rCom==null || rSet==null || mark==null);
        */
		
		if(OT==null || MStaTime==null || MDestTime==null || MStaF<1 || MStaF>10 ||MDestF>10 || OF>10 ||MDestF<1 || OF<1 || (MDir!=1 && MDir!=0 && MDir!=-1) ||
				rCom==null || rSet==null || mark==null) return false;
		return true;
	}
	
	public Elevator() {
		
	}
    
	
	public boolean MainExist() {
		 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		(\this.rSet.size()==0) ==> \result==false;
         *		(\this.rSet.size()!=0) ==> \result==true;
         */
		
		if(rSet.size()!=0) return true;
		else return false;
	}
	
	public void Main(Request r) {
		/**@REQUIRES:r!=null;
		*@MODIFIES:
		*		\this.MStaF;
		*		\this.MDestF;
		*		\this.MDir;
		*		\this.MStaTime;
		*		\this.MDestTime;
		*		\this.rSet;
		*		\this.OT;
		*@EFFECTS:
		*		\this.MStaF==OF;
		*		\this.MDestF==r.floor();
		*		\this.MDestTime==add(MStaTime,Math.abs(MDestF-MStaF)*0.5);
		*		(r.time().compareTo(OT)==-1) ==> \this.MStaTime==OT;
		*		!(r.time().compareTo(OT)==-1) ==> \this.MStaTime==r.time();
		*		(MDesTF-MStaF>0) ==> \this.MDir==1;
		*		(MDesTF-MStaF<0) ==> \this.MDir==0;
		*		(MDesTF-MStaF==0) ==> \this.MDir==-1;
		*		(\this.rSet.size == \old(\this.rSet).size+1) && (\this.rSet.contains(r)==true);
		*		\this.OT==MStaTime;
		*/
		
		double fdiffer;
		
		MStaF=OF;
		MDestF=r.floor();
		
		
		if(MDestF-MStaF>0) {
			MDir=1;
			fdiffer=MDestF-MStaF;
		}
		else if(MDestF-MStaF==0) {
			MDir=-1;
			fdiffer=MDestF-MStaF;
		}
		else {
			MDir=0;
			fdiffer=MStaF-MDestF;
		}
	    
		
		if(r.time().compareTo(OT)==-1) MStaTime=OT;
		else MStaTime=r.time();
		OT=MStaTime;
	
		fdiffer=fdiffer*0.5;
		MDestTime=add(MStaTime,fdiffer);
		
		rSet.add(r);
	}
    
	public boolean ByWay(Request r){
		/**@REQUIRES:r!=null;
		*@MODIFIES:None;
		*@EFFECTS:
		*		BywayJudge(r)==true ==> (\result==true);
		*		BywayJudge(r)==false ==> (\result==false);
		*		r.time().compareTo(MDestTime)!=-1 ==> (\result==false);
		*/

		if(r.time().compareTo(MStaTime)==-1) return BywayJudge(r,0);
		else {
			if(r.time().compareTo(MDestTime)!=-1) return false;
			return BywayJudge(r,1);
		}
	}
	
	
	public boolean BywayJudge(Request r,int flag) {
		/**@REQUIRES:r!=null;
		*@MODIFIES:None;
		*@EFFECTS:
		*		\result==(r.ask()==1 && MDir==1 && curFloor<r.floor() && r.floor()<=MDestF) ||
		*		(r.ask()==2 && MDir==0 && curFloor>r.floor() && r.floor()>=MDestF) ||
		*		(r.ask()==3 && MDir==1 && curFloor<r.floor()) ||
		*		(r.ask()==3 && MDir==0 && curFloor>r.floor());
		*/
		
		int curFloor;
		if(flag==0) curFloor=MStaF;
		else curFloor=curfloor(r);
		
		if(r.ask()==1) {
			if(MDir==1) {
				if(curFloor<r.floor() && r.floor()<=MDestF) {
					rSetInsertUp(r);
					return true;
				}
				else return false;
			}
				
		   else return false;
		}
			
		else if(r.ask()==2) {
			if(MDir==0) {
				if(r.floor()<curFloor && r.floor()>=MDestF) {
					rSetInsertDown(r);
					return true;
				}
				else return false;
			}
				
		    else return false;
        }
			
			
		else{
			if(MDir==1) {
				if(r.floor()>curFloor) {
					rSetInsertUp(r);
					return true;
				}
				else return false;
			}
				
			else if(MDir==0) {
				if(r.floor()<curFloor) {
					rSetInsertDown(r);
					return true;
				}
				
				else return false;
			}
				
			else return false;
		}
					
	}

	
	@Override
	public int curfloor(Request r) {
		/**@REQUIRES:r!=null;
	    *@MODIFIES:None;
	    *@EFFECTS:
	    *		返回被查询请求请求时刻电梯运行到的楼层数;
	    */
		
		BigDecimal t,T;
		int i;
		
		t=MStaTime;
		T=r.time();
		
		if(r.time().compareTo(MStaTime)==0) return MStaF;
		else {
			if(MDir==1) i=MStaF+1;
			else i=MStaF-1;
		
			for(;t.compareTo(T)==-1;){
				if(mark[i]==1) t=add(t,1.5);	
				else t=add(t,0.5);
			
				if(MDir==1) ++i;
				else --i;
			}
			
			if(MDir==1) return i-1;
			else return i+1;
		}
	}
	
	public  void rSetInsertUp(Request r) {
		/**@REQUIRES:r!=null;
        *@MODIFIES:\this.rSet;
        *@EFFECTS:
        *		(\this.rSet.size == \old(\this.rSet).size+1) && (\this.rSet.contains(r)==true);
        *		按照请求楼层升序将请求插入rSet队列，楼层相同则按照输入顺序插入
        */
		
		int i=0,j=0,k=0,equal=0,big=0,lit=0;
		double one=1.0;
		//寻找
		for(i=0;i<rSet.size();i++) {
			Request rcp=rSet.get(i);
			if(rcp.floor()==r.floor()) {
				if(equal==1) continue;
				equal=1;
				j=i;
			}
			
			if(rcp.floor()>r.floor()) {
				big=1;
				k=i;
				break;
			}
		}
	
		//插入
		if(equal==1) {
			if(big==0) k=rSet.size();
			for(i=j;i<k;i++) {
				Request rcp=rSet.get(i);
				if(rcp.order()>r.order()) {
					rSet.add(i,r);
					equal=0;
					big=0;
					break;
				}
			}
			
			if(i==k) {
				if(big==1) {
					rSet.add(k,r);
					equal=0;
					big=0;
				}
				else{
					rSet.add(r);
					equal=0;
					big=0;
				}
			}
		}
		
		else {
			if(big==1) {
				rSet.add(k,r);
				big=0;
			}
			else rSet.add(r);
		}
		
		
		mark[r.floor()]=1;
		if(r.floor()<MDestF) MDestTime=add(MDestTime,one);
	}
	
	public  void rSetInsertDown(Request r) {
		/**@REQUIRES:r!=null;
	    *@MODIFIES:\this.rSet;
	    *@EFFECTS:
	    *		(\this.rSet.size == \old(\this.rSet).size+1) && (\this.rSet.contains(r)==true);
	    *		按照请求楼层降序将请求插入rSet队列，楼层相同则按照输入顺序插入
	    */
		
		int i=0,j=0,k=0,equal=0,big=0,lit=0;
		double one=1.0;
		
				
		for(i=0;i<rSet.size();i++) {
			Request rcp=rSet.get(i);
			if(rcp.floor()==r.floor()) {
				if(equal==1) continue;
				equal=1;
				j=i;
			}
			
			if(rcp.floor()<r.floor()) {
				lit=1;
				k=i;
				break;
			}
		}
	
		if(equal==1) {
			if(lit==0) k=rSet.size();
			for(i=j;i<k;i++) {
				Request rcp=rSet.get(i);
				if(rcp.order()>r.order()) {
					rSet.add(i,r);
					equal=0;
					lit=0;
					break;
				}
			}
			
			if(i==k) {
				if(lit==1) {
					rSet.add(k,r);
					equal=0;
					lit=0;
				}
				else{
					rSet.add(r);
					equal=0;
					lit=0;
				}
			}
		}
		
		else {
			if(lit==1) {
				rSet.add(k,r);
				lit=0;
			}
			else rSet.add(r);
		}	
				
	
		mark[r.floor()]=1;
		if(r.floor()>MDestF) MDestTime=add(MDestTime,one);
		
	}
	
    public void curMDone(List <Request> list) {
    	/**@REQUIRES:None;
        *@MODIFIES:
        *		\this.rSet;
        *		\this.rCom;
        *		\this.mark;	
        *@EFFECTS:
        *		(rSet.size()!=0) ==> (\result==rSet);
        *		(rSet.size()==0) ==> (\result==null);
        *		(\all int i;i>0 && i<11) ==> mark[i]==0;
        *		调度完成的请求加入rCom队列并从rSet队列中去除
        *		rSet.size==0 ==> \result==null;
        *		rSet.size!=0 ==> \result=rSet;
        */
    	
    	int i;
        Request rout;
        if(rSet.size()!=0) {
        	if(MDir==1 || MDir==-1) { 
        		do {
        			rout=rSet.get(0);
        			print(rout);
        			rCom.add(rout);
        			rSet.remove(0);
        		}while(rSet.size()!=0 && rSet.get(0).floor()<=MDestF );
        	}
        
        	else {
        		do {
        			rout=rSet.get(0);
        			print(rout);
        			rCom.add(rout);
        			rSet.remove(0);
        		}while(rSet.size()!=0 && rSet.get(0).floor()>=MDestF );
        	}
        
        	for(i=1;i<11;i++) mark[i]=0;
        	
        	for(;rSet.size()!=0;) {
        		list.add(rSet.get(0));
        		rSet.remove(0);
        		
        	}
        }
        else list=null;
    }
	
	public void print(Request r) {
		/**@REQUIRES:r!=null;
         *@MODIFIES:
         *		\this.OT;
         *		\this.OF;
         *		\this.out;
         *@EFFECTS:
         *		\this.OT==add()
         *		\this.OF==r.floor();
         *		((r.floor()-OF)==0 && MDir==-1) ==> (OT==add(OT,1.0);
         *		((r.floor()-OF)!=0 || MDir!=-1) ==> (OT==add(time,1.0));
         *		\this.out=the information to be output
         *		输出请求及请求完成信息;
         */
		
		BigDecimal time;
		double differ;
		differ=r.floor()-OF;
		String s=new String();
		if(MDir==-1)      s="STILL";
		else if(MDir==0)  s="DOWN";
		else s="UP";
		
		
		if(differ==0) {
			
			if(MDir!=-1) time=add(OT,-1.0);
			else{
				time=add(OT,1.0);
				OT=add(OT,1.0);
			}
			r.setLimit(OT);
		}
		else if(differ<0) {
			differ=0-differ;
			differ=differ*0.5;
			time=add(OT,differ);
			OT=add(time,1.0);
			r.setLimit(OT);
		}
		else {
			differ=differ*0.5;
			time=add(OT,differ);
			OT=add(time,1.0);
			r.setLimit(OT);
		}
		   
	    
		
	
		if(r.ask()==1) {
			System.out.print("["+"FR"+","+r.floor()+","+"UP"+","+r.time()+"]/");
			out="("+r.floor()+","+s+","+time.setScale(1,BigDecimal.ROUND_DOWN)+")";
			System.out.println(toString());
		}
		else if(r.ask()==2) {
			System.out.print("["+"FR"+","+r.floor()+","+"DOWN"+","+r.time()+"]/");
			out="("+r.floor()+","+s+","+time.setScale(1,BigDecimal.ROUND_DOWN)+")";
			System.out.println(toString());
		}
		else {
			System.out.print("["+"ER"+","+r.floor()+","+r.time()+"]/");
			out="("+r.floor()+","+s+","+time.setScale(1,BigDecimal.ROUND_DOWN)+")";
			System.out.println(toString());
		}
	
		OF=r.floor();
	}
	
	
	
    public boolean findCom(Request r) {
    	 /**@REQUIRES:r!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		(\this.rCom.contains(r)==true)==>(\result==true);
         *		(\this.rCom.contains(r)==false)==>(\result==false);
         */
    	
    	if(rCom.contains(r)) return true;
    	else return false;
    }
    
    
    public boolean findSet(Request r) {
    	 /**@REQUIRES:r!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		(\this.rSet.contains(r)==true)==>(\result==true);
         *		(\this.rSet.contains(r)==false)==>(\result==false);
         */
    	
    	if(rSet.contains(r)) return true;
    	else return false;
    }
    
 
    public BigDecimal limitCom(Request r) {
    	 /**@REQUIRES:r!=null && rCom.contains(r)==true;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==rCom.get(last).limit();
         */
    	
    	BigDecimal time;
    	int index;
    	Request rLast;
    	index=rCom.lastIndexOf(r);
    	rLast=(Request)rCom.get(index);
    	time=rLast.limit();
    	return time;
    }
 
   
    public double addOut(BigDecimal b1,double d2){ 
    	 /**@REQUIRES:b1!=null && d2>=0;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==b1.add(b2).doubleValue();
         */
    	
        BigDecimal b2 = new BigDecimal(d2);  
        return b1.add(b2).doubleValue();
        
	}

    public BigDecimal add(BigDecimal b1,double d2){   
    	 /**@REQUIRES:b1!=null && d2>=0;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==b1.add(b2);
         */
    	
        BigDecimal b2 = new BigDecimal(d2);  
        return b1.add(b2);
        
	}
   
	
	public String toString() {
		 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==out;
         */
		
		return out;
	}
	
	
	
}
