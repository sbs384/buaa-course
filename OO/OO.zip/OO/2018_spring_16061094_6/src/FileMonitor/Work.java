package FileMonitor;

import java.io.File;

public class Work {
    private int sort=-1;//0:文件；1:目录
    private String path;
    private int mission;
    private int tigger;
	

	public Work(String s) {
		String regex=" ";
		String [] strWork=s.split(regex);
		
		//sort
		File file=new File(strWork[1]);
		if(file.exists()) {
			if (file.isDirectory()) sort=1;
			else sort=0;
			
			//tigger
			if(strWork[2].equals("renamed")) 			tigger=0;
			else if(strWork[2].equals("path-changed"))  tigger=1;
			else if(strWork[2].equals("modified")) 	    tigger=2;
			else 										tigger=3;
			
			//mission
			if(strWork[4].equals("record-summary"))		 mission=0;
			else if(strWork[4].equals("record-detail"))  mission=1;
			else										 mission=2;
			
			path=strWork[1];
		}
		
		else System.out.println("#ERROR!The monitoring object is not existed!");	
	}
    
    
	@Override
	public boolean equals(Object obj) {
		if(this==obj) return true;
		if(obj==null) return false;
		if(!(obj instanceof Work)) return false;
		Work work=(Work)obj;
		if(this.path.equals(work.path) && this.mission==work.mission && this.tigger==work.tigger ) return true;
		else return false;
	  }


	public int sort() {
		return sort;
	}


	public void setSort(int sort) {
		this.sort = sort;
	}


	public String path() {
		return path;
	}


	public void setPath(String path) {
		this.path = path;
	}


	public int mission() {
		return mission;
	}


	public void setMission(int mission) {
		this.mission = mission;
	}


	public int tigger() {
		return tigger;
	}


	public void setTigger(int tigger) {
		this.tigger = tigger;
	}

}


