package FileMonitor;

import java.io.File;
import java.util.List;
import java.util.ArrayList;


public class Snapshot implements Cloneable{
    private String path=null;
    private long time=0;
    private long size=0;
    private String name=null;
    private List <Snapshot> list=new ArrayList();
    
    
    public Snapshot() {
    	
    }
    
    public Snapshot(File file) {
		this.name=file.getName();
	    this.time=file.lastModified();
	    this.size=file.length();
	    this.path=file.getAbsolutePath();
    }
    
	public String path() {
		return path;
	}
	
	public long time() {
		return time;
	}
	
	public long size() {
		return size;
	}
	
	public String name() {
		return name;
	}
	
	public void setList(List <Snapshot> list) {
		this.list=list;
	}
	
	public int Len() {
		return list.size();
	}
	
	public void remove(int i) {
		list.remove(i);
	}
	
	public void add(int i,Snapshot s) {
		list.add(i,s);
	}
	
	public boolean contains(Snapshot s) {
		if(list.contains(s)) return true;
		else return false;
	}
	
	public Object clone(){  
        Snapshot s = null;  
        try{  
            s = (Snapshot)super.clone();  
            }catch(CloneNotSupportedException e){  
                e.printStackTrace();  
            }  
        return s;   
    }  

	
	@Override
	public boolean equals(Object obj) {
		if(this==obj) return true;
		if(obj==null) return false;
		if(!(obj instanceof Snapshot)) return false;
		Snapshot s=(Snapshot)obj;
		if(this.time==s.time && this.size==s.size && this.name().equals(s.name) && this.path.equals(s.path)) return true;
		else return false;
   }
    
    
}
