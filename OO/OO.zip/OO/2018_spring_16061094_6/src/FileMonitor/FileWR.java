package FileMonitor;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class FileWR{
	
	//文件写操作
	public boolean addFile(String path) {
        File file = new File(path);
        if(!file.exists()){
            file.getParentFile().mkdirs();  
        	try {
            	file.createNewFile();
            } catch (IOException e) {
            	e.printStackTrace();
            }
            return true;
        }
        else return false;
	}
	
	
	public boolean renameFile(String From,String To) {
		File oldFile=new File(From);
		File newFile=new File(To);
		
		try {
		if(!oldFile.getParent().equals(newFile.getParent())) return false;
		else {
			oldFile.renameTo(newFile);
			return true;
		}
		}catch(Exception e) {
			return false;
		}
	}
	
	
	public boolean deleteFile(String path) {
		File file=new File(path);
		try {
		if(file.exists() && file.isFile()) {
			file.delete();
			return true;
		}
		else return false;
		}catch(Exception e) {
			return false;
		}
	}
	
	
	public boolean moveFile(String From,String To) {
		File oldFile=new File(From);
		File newFile=new File(To);
		
		return oldFile.renameTo(newFile);
	}
	
	
	public boolean changeSize(String path,String s) {
		return true;
	}
	
	
	public boolean changeTime(String path,long time) {
		File file=new File(path);
		try {
		if(!file.exists()) return false;
		else {
			file.setLastModified(time);
			return true;
		}
		}catch(Exception e) {
			return false;
		}
	}
	
	
	public boolean addMkdir(String path) {
		File file = new File(path);
		try {
        if(!file.exists()){
            file.mkdirs();     
            return true;
        }
        else return false;
		}catch(Exception e) {
			return false;
		}
	}
	
	
	//文件扫描方法
	public List <Snapshot> renameSearch(Snapshot snap){
		List <Snapshot> list=new ArrayList();
		Snapshot snapfirst=new Snapshot();
		int flag=0;
		File filefather=new File(snap.path()).getParentFile();
		File [] files=filefather.listFiles();
		for(File file:files) {
			if(file.isFile() && file.lastModified()==snap.time() && file.length()==snap.size()) {
				if(file.getName().equals(snap.name())) {
					snapfirst=new Snapshot (file);
					flag=1;
				}
				else list.add(new Snapshot(file));
			}
		}
		
		if(flag==1) {
			list.add(0,snapfirst);
			flag=0;
		}
		
		return list;
		
	}

	public Snapshot pathSearch(Snapshot s,String range) {
		if(findFiles(range,s.name())==null) return null;
		else{
			File file=findFiles(range,s.name());
			return new Snapshot(file);
		}
	}
	
	public Snapshot modifiedSearch(Snapshot s) {
		int i;
		String fatherPath;
		fatherPath=new File(s.path()).getParent();
		File file=new File(fatherPath);
		File [] fileCurLayer=file.listFiles();

		for(File filename: fileCurLayer) {
			if(filename.isFile()) {
				if(filename.getName().equals(s.name())) {
					return new Snapshot(filename);
				}
			}
		}
		
		return null;
	}
	
	public File findFiles(String path,String name) {
		int i;
		String tempName;
		File[] files = new File(path).listFiles(); 
		File tempFile;
		for(i =0;i<files.length;i++) {  
            tempFile = files[i];  
            if(tempFile.isDirectory()){  
                findFiles(tempFile.getAbsolutePath(),name);  
            }
            else if(tempFile.isFile()){  
                tempName = tempFile.getName();  
                if(tempName.equals(name)){  
                    return tempFile;
                }  
            }  
        }  
        return null;  
	}
	
	
	
	//目录的读取方法
	public List <Snapshot> modifiedSearchCat(List <Snapshot> list) {
		int i;
		List <Snapshot> out=new ArrayList();
		for(i=0;i<list.size();i++) {
			out.add(modifiedSearch(list.get(i)));
		}
		
		return out;
	}
	
	public List <Snapshot> pathSearchCat(List <Snapshot> list,String range) {
		int i;
		List <Snapshot> out=new ArrayList();
		for(i=0;i<list.size();i++) {
			out.add(pathSearch(list.get(i),range));
		}
		
		return out;
	}
	
	
	//recovery
	public void recovery(Snapshot snapFormmer,Snapshot snapBack,int i) {
		if(i==0) {
			String To=snapFormmer.path();
			String From=snapBack.path();
			
			renameFile(From,To);
		}
		else {
			String To=snapFormmer.path();
			String From=snapBack.path();
			
			moveFile(From,To);
		}
	}
	
	public List <Snapshot> listRename(String path){
		List <Snapshot> list=new ArrayList();
		File file=new File(new File(path).getParent());
		File [] files=file.listFiles();
		for(File filer:files) {
			if(filer.isFile()) list.add(new Snapshot(filer));
		}
		return list;
	}
	
}


