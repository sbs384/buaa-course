package FileMonitor;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

public class MonitorCat extends Thread {
	private SafeFile safefile;
	private int sort;
	private int mission;
	private int tigger;//1:rename;2:path;3:modified;4:size
	private String range;
	private List <Snapshot> snapFileFormmer=new ArrayList();
	private List <Snapshot> snapFileBack=new ArrayList();
	private List <Snapshot> updatelist=new ArrayList();
	private List <Snapshot> same=new ArrayList();
	private Snapshot snapFileBackR;
	private int excutation;//0:D;1:CY;2:CN
	
	private Summary summary;
	private Detailed detailed;
    private boolean stop=true;
	
    public MonitorCat(String name,Work w,SafeFile safefile,Summary summary,Detailed detailed) {
		super(name);
	
		this.safefile=safefile;
		this.summary=summary;
		this.detailed=detailed;
		this.sort=w.sort();
		this.mission=w.mission();
		this.tigger=w.tigger();
		
		this.range=w.path();
		findFile(w.path(),snapFileFormmer);
		
		//for(int i=0;i<snapFileFormmer.size();i++) System.out.println("path:"+snapFileFormmer.get(i).path());
		if(tigger==0) {
			for(int i=0;i<snapFileFormmer.size();i++) {
				snapFileFormmer.get(i).setList(safefile.renameSearch(snapFileFormmer.get(i)));
			}
		}
		
		else if(tigger==1) {
			for(int i=0;i<snapFileFormmer.size();i++) {
				snapFileFormmer.get(i).setList(safefile.pathSearch(snapFileFormmer.get(i)));
			}
		}
		
    }
       
    
    public void run() {
    	int i,j,k;
    	try {
    	while(stop) {
    		//根据触发器进行扫描
    		if(tigger==0) {
    			List <List <Snapshot>> list=safefile.renameSearchCat(snapFileFormmer);
				//for(i=0;i<snapFileBack.size();i++) System.out.println("path:"+snapFileBack.get(i).path());
    			
    			//对每一个进行对比
				for(i=0;i<snapFileFormmer.size();) {
					
					//对比
					Snapshot tempformmer=snapFileFormmer.get(i);
					List <Snapshot> templist=list.get(i);
					if(templist.size()==0) {
						excutation=0;
						//System.out.println("MonitorCat.95:excutation:"+excutation);
					}
					else{
						if(templist.get(0).name().equals(tempformmer.name())){
							excutation=2;
							//System.out.println("MonitorCat.61:excutation:"+excutation);
							//snapFileBack.set(i,(Snapshot)tempformmer.clone());
							for(;snapFileFormmer.get(i).Len()!=0;) snapFileFormmer.get(i).remove(0); 
							for(j=0;j<templist.size();j++)  snapFileFormmer.get(i).add(j,templist.get(j));
						}
					
						else {
							for(k=0;k<templist.size();k++) {
								Snapshot tempsnap=templist.get(k);
							    if(!snapFileFormmer.get(i).contains(tempsnap) && !same.contains(tempsnap)) {
							    	snapFileBackR=(Snapshot)tempsnap.clone();
							    	excutation=1;
							    	//System.out.println("Monitor.72:excutation:"+excutation);
							    	for(;snapFileFormmer.get(i).Len()!=0;) snapFileFormmer.get(i).remove(0); 
									for(j=0;j<templist.size();j++)  snapFileFormmer.get(i).add(j,templist.get(j));
									same.add(tempsnap);
							    	break;
							    }
							}
							if(k==templist.size()) {
								excutation=0;
							    //System.out.println("Monitor.80:excutation:"+excutation);
						     }
						}
				   }  
					
				   //执行任务
					if(excutation==0) {
						snapFileFormmer.remove(i);
						list.remove(i);
					}
					else if(excutation==2) ++i;
					else {
						if(mission==0) {
							summary.add(0); 
							snapFileFormmer.set(i,(Snapshot)snapFileBackR.clone());
							++i;
						}
						else if(mission==1) {
							detailed.print(tempformmer,snapFileBackR,0);
							snapFileFormmer.set(i,(Snapshot)snapFileBackR.clone());
							++i;
						}
						else if(mission==3) safefile.recovery(tempformmer,snapFileBackR,0);
					}
				}
				for(;same.size()!=0;) same.remove(0); 
			}
		    
    		
    		else if(tigger==1) {
    			List <List <Snapshot>> list=safefile.pathSearchCat(snapFileFormmer,range);
				//for(i=0;i<snapFileBack.size();i++) System.out.println("path:"+snapFileBack.get(i).path());
    			
    			//对每一个进行对比
				for(i=0;i<snapFileFormmer.size();) {
					
					//对比
					Snapshot tempformmer=snapFileFormmer.get(i);
					List <Snapshot> templist=list.get(i);
					if(templist.size()==0) {
						excutation=0;
						//System.out.println("MonitorCat.95:excutation:"+excutation);
					}
					else{
						if(templist.get(0).path().equals(tempformmer.path())){
							excutation=2;
							//System.out.println("MonitorCat.61:excutation:"+excutation);
							//snapFileBack.set(i,(Snapshot)tempformmer.clone());
							for(;snapFileFormmer.get(i).Len()!=0;) snapFileFormmer.get(i).remove(0); 
							for(j=0;j<templist.size();j++)  snapFileFormmer.get(i).add(j,templist.get(j));
						}
					
						else {
							for(k=0;k<templist.size();k++) {
								Snapshot tempsnap=templist.get(k);
								//if(!snapFileFormmer.get(i).contains(tempsnap)) System.out.println("hh");
							    if(!snapFileFormmer.get(i).contains(tempsnap) && !same.contains(tempsnap)) {
							    	snapFileBackR=(Snapshot)tempsnap.clone();
							    	excutation=1;
							    	//System.out.println("Monitor.72:excutation:"+excutation);
							    	for(;snapFileFormmer.get(i).Len()!=0;) snapFileFormmer.get(i).remove(0); 
									for(j=0;j<templist.size();j++)  snapFileFormmer.get(i).add(j,templist.get(j));
									same.add(tempsnap);
							    	break;
							    }
							}
							if(k==templist.size()) {
								excutation=0;
							    //System.out.println("Monitor.80:excutation:"+excutation);
						     }
						}
				   }  
					
				   //执行任务
					if(excutation==0) {
						snapFileFormmer.remove(i);
						list.remove(i);
					}
					else if(excutation==2) ++i;
					else {
						if(mission==0) {
							summary.add(1); 
							snapFileFormmer.set(i,(Snapshot)snapFileBackR.clone());
							++i;
						}
						else if(mission==1) {
							detailed.print(tempformmer,snapFileBackR,1);
							snapFileFormmer.set(i,(Snapshot)snapFileBackR.clone());
							++i;
						}
						else if(mission==3) safefile.recovery(tempformmer,snapFileBackR,1);
					}
				}
				for(;same.size()!=0;) same.remove(0); 
			}
			
			
			
			else if(tigger==2) {
				snapFileBack=safefile.modifiedSearchCat(snapFileFormmer);
				//for(i=0;i<snapFileBack.size();i++) System.out.println("path:"+snapFileBack.get(i).path());
				for(i=0;i<snapFileFormmer.size();) {
					Snapshot tempformmer=snapFileFormmer.get(i);
					Snapshot tempback=snapFileBack.get(i);
					if(tempback==null) {
						excutation=0;
						//System.out.println("MonitorCat.95:excutation:"+excutation);
					}
					else {
						if(tempback.size()==tempformmer.size()) {
							if(tempback.time()!=tempformmer.time()) {
								excutation=1;
								//System.out.println("MonitorCat.95:excutation:"+excutation);
							}
							else{
								excutation=2;
								//System.out.println("MonitorCat.95:excutation:"+excutation);
							}
						}
						else{
							excutation=0;
							//System.out.println("MonitorCat.95:excutation:"+excutation);
						}
					}
					
					//任务执行
					if(excutation==0) {
						snapFileFormmer.remove(i);
						snapFileBack.remove(i);
					}
					else if(excutation==2) ++i;
					else {
						if(mission==0) {
							summary.add(2); 
							snapFileFormmer.set(i,(Snapshot)tempback.clone());
							++i;
						}
						else if(mission==1) {
							detailed.print(tempformmer,tempback,2);
							snapFileFormmer.set(i,(Snapshot)tempback.clone());
							++i;
						}
					}
				}
			}
		
			else {
				snapFileBack=safefile.modifiedSearchCat(snapFileFormmer);
				for(i=0;i<snapFileFormmer.size();) {
					Snapshot tempformmer=snapFileFormmer.get(i);
					Snapshot tempback=snapFileBack.get(i);
					if(tempback==null) excutation=0;
					else {
						if(tempback.time()!=tempformmer.time() && tempback.size()!=tempformmer.size()) {
							excutation=1;
							//System.out.println("back:"+snapFileBack.get(i).size());
							//System.out.println("formmer:"+snapFileFormmer.get(i).size());
						}
						else excutation=2;
					}
					
					//任务执行
					if(excutation==0) {
						snapFileFormmer.remove(i);
						snapFileBack.remove(i);
					}
					else if(excutation==2) {
						snapFileFormmer.set(i,(Snapshot)tempback.clone());
						++i;
					}
					else {
						if(mission==0) {
							summary.add(3); 
							snapFileFormmer.set(i,(Snapshot)tempback.clone());
							//System.out.println(snapFileFormmer.get(i).size());
							++i;
						}
						else if(mission==1) {
							detailed.print(tempformmer,tempback,3);
							snapFileFormmer.set(i,(Snapshot)tempback.clone());
							++i;
							//System.out.println(snapFileFormmer.size());
						}
					}
				}
				//System.out.println(i);
				//System.out.println(snapFileFormmer.get(i-1).size());
			}
    		
    		//更新list
    		//for(i=0;i<snapFileFormmer.size();i++) System.out.println("path:"+snapFileFormmer.get(i).path());
    		updatelist=safefile.update(range, updatelist,snapFileFormmer);
    		//for(i=0;i<updatelist.size();i++) System.out.println("MonitorCat.287:path:"+updatelist.get(i).path());
    		//if(excutation==1) System.out.println(snapFileFormmer.get(0).size());  
    		
    		
    		if(tigger==0) {
    			for(i=0;i<updatelist.size();i++) {
    				updatelist.get(i).setList(safefile.renameSearch(updatelist.get(i)));
    			}
    		}
		
    		else if(tigger==1) {
    			for(i=0;i<updatelist.size();i++) {
    				updatelist.get(i).setList(safefile.pathSearch(updatelist.get(i)));
    			}
    		}
		
    		
    		for(;updatelist.size()!=0;) {
    			snapFileFormmer.add(updatelist.get(0));
    			updatelist.remove(0);
    		}
			    
		} 	
    	}catch(Exception e) {}
    	yield();
    	
    }
    
    public void findFile(String path,List <Snapshot> list) {
    	int i;
		File[] files = new File(path).listFiles(); 
		File tempFile;
		
		for(i =0;i<files.length;i++) {  
	           tempFile = files[i];  
	           if(tempFile.isDirectory()){  
	                findFile(tempFile.getAbsolutePath(),list);  
	            }
	            else if(tempFile.isFile()){  
	            	list.add(new Snapshot(tempFile));
	            }  
	     }
		
		
    }
    
   
}
