package FileMonitor;

import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

	public class MonitorFile extends Thread {
		private List <Snapshot> listRename=new ArrayList();
		private List <Snapshot> listPath=new ArrayList();
		private SafeFile safefile;
		private int sort;
		private int mission;
		private int tigger;//1:rename;2:path;3:modified;4:size
		private String range;
		private Snapshot snapFileFormmer;//name;time;size;
		private Snapshot snapFileBack =new Snapshot();
		private int excutation;//0:D;1:CY;2:CN
		
		private Summary summary;
		private Detailed detailed;
	    private boolean stop=true;
	     
		public MonitorFile(String name,Work w,SafeFile safefile,Summary summary,Detailed detailed) {
			super(name);
		
			this.safefile=safefile;
			this.summary=summary;
			this.detailed=detailed;
			
			this.sort=w.sort();
			this.mission=w.mission();
			this.tigger=w.tigger();
			
			File file=new File(w.path());
			this.range=file.getParent();
			this.snapFileFormmer=new Snapshot(file);	 
			
			if(w.tigger()==0) {
				listRename=safefile.renameSearch(snapFileFormmer);
			}
			
			else if(w.tigger()==1) {
				int i;
				listPath=safefile.pathSearch(snapFileFormmer);
				//for(i=0;i<listPath.size();i++) System.out.println(listPath.get(i).path());
			}
			//System.out.println("MonitorFile.41:"+"sort:"+sort+" mission:"+mission+" range:"+range+" tigger:"+tigger);
			//System.out.println("MonitorFile.42:name:"+snapFileFormmer.name()+" path:"+snapFileFormmer.path()+" size:"+snapFileFormmer.size()+" time:"+snapFileFormmer.time());
		}
		
		public void run() {
			int i,j;
			try {
			while(stop) {
				//根据触发器进行扫描并进行结果比对
				if(tigger==0) {
					List <Snapshot> list=safefile.renameSearch(snapFileFormmer);
					
					if(list.size()!=0) {
						if(list.get(0).name().equals(snapFileFormmer.name())){
								excutation=2;
								//System.out.println("Monitor.60:excutation:"+excutation);
								snapFileBack=(Snapshot)snapFileFormmer.clone();
								for(;listRename.size()!=0;) listRename.remove(0); 
								for(j=0;j<list.size();j++)  listRename.add(j,list.get(j));
						}
						
						else {
							for(i=0;i<list.size();i++) {
								Snapshot tempsnap=list.get(i);
							    if(!listRename.contains(tempsnap)) {
							    	snapFileBack=(Snapshot)tempsnap.clone();
							    	excutation=1;
							    	//System.out.println("Monitor.72:excutation:"+excutation);
							    	for(;listRename.size()!=0;) listRename.remove(0); 
									for(j=0;j<list.size();j++) listRename.add(j,list.get(j));
							    	break;
							    }
							}
							if(i==list.size())
								excutation=0;
							    //System.out.println("Monitor.80:excutation:"+excutation);
						     }
				    }
					
					else{
						excutation=0;
						//System.out.println("Monitor.86:excutation:"+excutation);
					}
				}
			
				else if(tigger==1) {
					List <Snapshot> list=safefile.pathSearch(snapFileFormmer);
					
					
					if(list.size()==0) {
						excutation=0;
						//System.out.println("MonitorFile.95:excutation:"+excutation);
					}
					else {
						if(list.get(0).path().equals(snapFileFormmer.path())) {
							excutation=2;
							//System.out.println("MonitorFile.100:excutation:"+excutation);
							snapFileBack=(Snapshot)snapFileFormmer.clone();
							for(;listPath.size()!=0;) listPath.remove(0); 
							for(j=0;j<list.size();j++) listPath.add(j,list.get(j));
						}
						
						else {
							//for(i=0;i<listPath.size();i++) System.out.println(listPath.get(i).path());
							for(i=0;i<list.size();i++) {
								Snapshot tempsnap=list.get(i);
							    if(!listPath.contains(tempsnap)) {
							    	//for(i=0;i<listPath.size();i++) System.out.println(listPath.get(i).path());
							    	snapFileBack=(Snapshot)tempsnap.clone();
							    	excutation=1;
							    	//System.out.println("Monitor.112:excutation:"+excutation);
							    	//System.out.println(tempsnap.path());
							    	for(;listPath.size()!=0;) listPath.remove(0); 
									for(j=0;j<list.size();j++) listPath.add(j,list.get(j));
									range=snapFileBack.path();
							    	break;
							    }
							}
							if(i==list.size()) {
								excutation=0;
								//System.out.println("MonitorFile.125:excutation:"+excutation);
							}
						}
					}
				}
			
				else if(tigger==2) {
					snapFileBack=safefile.modifiedSearch(snapFileFormmer);
					//if(snapFileBack!=null && snapFileBack.time()!=snapFileFormmer.time())
					//{System.out.println("MonitorFile.98:name:"+snapFileBack.name()+" path:"+snapFileBack.path()+" size:"+snapFileBack.size()+" time:"+snapFileBack.time());}
					//对比snap
					if(snapFileBack==null) {
						excutation=0;
						//System.out.println("Monitor.101:excutation:"+excutation);
					}
					else {
						
						if(snapFileBack.time()!=snapFileFormmer.time()) {
							excutation=1;
							//System.out.println("Monitor.104:excutation:"+excutation);
						}
						else excutation=2;
						
					}
				}
			
				else {
					snapFileBack=safefile.modifiedSearch(snapFileFormmer);
					//对比snap
					if(snapFileBack==null) excutation=0;
					else {
						if(snapFileBack.time()!=snapFileFormmer.time() && snapFileBack.size()!=snapFileFormmer.size()) excutation=1;
						else excutation=2;
					}
					
				}
				
		
				//执行任务
				if(excutation==0)  stopMe();
				else if(excutation==1) {
					if(mission==0) {
						if(tigger==0 ) summary.add(0);
						else if(tigger==1) summary.add(1);
						else if(tigger==2) summary.add(2);
						else summary.add(3);
						
						snapFileFormmer=(Snapshot)snapFileBack.clone();
					}
				
					else if(mission==1) {
						if(tigger==0) detailed.print(snapFileFormmer,snapFileBack,0);
						else if(tigger==1) detailed.print(snapFileFormmer,snapFileBack,1);
						else if(tigger==2) detailed.print(snapFileFormmer,snapFileBack,2);
						else detailed.print(snapFileFormmer,snapFileBack,3);
						snapFileFormmer=(Snapshot)snapFileBack.clone();
					}
				
					else {
						if(tigger==0) safefile.recovery(snapFileFormmer,snapFileBack,0);
						else if(tigger==1) safefile.recovery(snapFileFormmer,snapFileBack,1);
					}
					
			    }
				
				else snapFileFormmer=(Snapshot)snapFileBack.clone();    
			}
			}catch(Exception e) {}
		
			//System.out.println("#END");
			yield();
		}
		
		private void stopMe() {
			stop=false;  
		}

	
	}
	
	


