package FileMonitor;

public class Test extends Thread {
	private SafeFile safefile;
	
	public Test(String name,SafeFile safefile) {
		super(name);
		this.safefile=safefile;
	}
	
	public void rename(String From,String To) {
		safefile.renameFile(From, To);
	}
	
	public void changeTime(String path,long i) {
		safefile.changeTime(path, i);
	}
	
	public void addFile(String path) {
		safefile.addFile(path);
	}
	
	public void deleteFile(String path) {
		safefile.deleteFile(path);
	}
	
	public void moveFile(String From,String To) {
		safefile.moveFile(From, To);
	}
	
	public void changeSize(String path,String s) {
		safefile.changeSize(path, s);
	}
	
	public void addMkdir(String path) {
		safefile.addMkdir(path);
	}
	
	public void testcase() {
		//changeTime("C:\\Users\\lenovo\\Desktop\\test\\d.txt",System.currentTimeMillis());
				//rename("C:\\Users\\lenovo\\Desktop\\test\\d.txt","C:\\Users\\lenovo\\Desktop\\test\\a.txt");
				//changeTime("C:\\Users\\lenovo\\Desktop\\test\\a.txt",System.currentTimeMillis());
				//changeTime("C:\\Users\\lenovo\\Desktop\\test\\test_1\\f.txt",System.currentTimeMillis());
				//changeTime("C:\\Users\\lenovo\\Desktop\\test\\a.txt",System.currentTimeMillis());
				//changeTime("C:\\Users\\lenovo\\Desktop\\test\\a.txt",1);
				//rename("C:\\Users\\lenovo\\Desktop\\test\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\b.txt");
				//rename("C:\\Users\\lenovo\\Desktop\\test\\b.txt","C:\\Users\\lenovo\\Desktop\\test\\c.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\a.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\test_1\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\a.txt");
				//deleteFile("C:\\Users\\lenovo\\Desktop\\test\\test_1\\d.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\d.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\d.txt");
				//rename("C:\\Users\\lenovo\\Desktop\\test\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\1.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\a.txt");
				//rename("C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\b.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\test_1\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\a.txt");
				//rename("C:\\Users\\lenovo\\Desktop\\test\\test_1\\e.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\f.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\test_1\\f.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\h.txt");
				//rename("C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\d.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\f.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\a.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\a.txt");
				//addFile("C:\\Users\\lenovo\\Desktop\\test\\b.txt");
				//changeSize("C:\\Users\\lenovo\\Desktop\\test\\a.txt","hhhhhhhhhhhhhhh");
				//changeSize("C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\a.txt","kkkkkkkkkkkkkk");
				//addFile("C:\\Users\\lenovo\\Desktop\\test\\c.txt");
				//changeSize("C:\\Users\\lenovo\\Desktop\\test\\c.txt","kkkkkkkkkk");
				//changeSize("C:\\Users\\lenovo\\Desktop\\test\\test_2\\b.txt","llllllllllhhhhhhhhhhhhhhhhhhh  ");
				//deleteFile("C:\\Users\\lenovo\\Desktop\\test\\a.txt");
				//deleteFile("C:\\Users\\lenovo\\Desktop\\test\\b.txt");
				//addFile("C:\\Users\\lenovo\\Desktop\\test\\c.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\test_2\\d.txt","C:\\Users\\lenovo\\Desktop\\test\\test_1\\d.txt");
				//moveFile("C:\\Users\\lenovo\\Desktop\\test\\test_1\\d.txt","C:\\Users\\lenovo\\Desktop\\test\\d.txt");
				//IF C:\Users\lenovo\Desktop\test renamed THEN record-detailchangeSize("C:\\Users\\lenovo\\Desktop\\test\\test_1\\sample1\\f.txt","kkkkkkkkkkkkkkkkkkkkkkk ");
				//changeSize("C:\\Users\\lenovo\\Desktop\\test\\a.txt","hhhhh ");
				
				/*rename("C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x4.txt","C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x40.txt");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				changeSize("C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x0.txt","helloworldddddd");*/
		        
		        //rename("C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x2.txt","C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x20.txt");
		        moveFile("C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_x0.txt","C:\\Users\\lenovo\\Desktop\\test\\TextFile\\a\\a_a\\a_b\\a_x0.txt");


	}
	
	public void run(){
		testcase();
	}
	
}
