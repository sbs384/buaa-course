package FileMonitor;

import java.util.List;
import java.util.ArrayList;
import java.io.File;

public class QueueWork {
	private List <Work> queue=new ArrayList <Work>();
	private List <String> object=new ArrayList <String>();

	public void Check(Work w) {
		if(w.sort()!=-1) { 
			if(w.mission()==2 && !(w.tigger()==0 || w.tigger()==1)) {
				System.out.println("#ERROR!The tigger doesn't match mission \"recove\"!");
			}
			else {
				if(queue.contains(w)) {
					System.out.println("#ERROR!The monitoring work has been existed!");
				}
				else {
					if(object.size()==10 && !object.contains(w.path())) {
						System.out.println("#ERROR!The number of object is more than 10!");
					}
					queue.add(w);
					object.add(w.path());
				}
			}
		}
	}
	
	public int Len() {
		return queue.size();
	}	
	
	public Work curWork(int i) {
		return queue.get(i);
	}
}
