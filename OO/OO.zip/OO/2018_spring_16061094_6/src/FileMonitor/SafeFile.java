package FileMonitor;

import java.io.*;
import java.util.List;
import java.util.ArrayList;

public class SafeFile{
	
	//文件写操作
	public void addFile(String path) {
		synchronized(this){
        File file = new File(path);
        if(!file.exists()){
            file.getParentFile().mkdirs();  
        	try {
            	file.createNewFile();
            } catch (IOException e) {
            	e.printStackTrace();
            }
            //return true;
        }
        //else return false;
        try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
	}
	
	
	public void renameFile(String From,String To) {
		synchronized(this) {
		File oldFile=new File(From);
		File newFile=new File(To);
		
		try {
		if(!oldFile.getParent().equals(newFile.getParent())) {}//return false;
		else {
			oldFile.renameTo(newFile);
			//return true;
		}
		}catch(Exception e) {
			//return false;
		}
		
		try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	
	public void deleteFile(String path) {
		synchronized(this) {
		File file=new File(path);
		try {
		if(file.exists() && file.isFile()) {
			file.delete();
			//return true;
		}
		else {}//return false;
		}catch(Exception e) {
			//return false;
		}
		
		try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	
	public void moveFile(String From,String To) {
		synchronized(this) {
		try {
		File oldFile=new File(From);
		File newFile=new File(To);
		
		oldFile.renameTo(newFile);
		}catch(Exception e) {
		}
		
		try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	
	public void changeSize(String path,String s) {
		synchronized(this){
			BufferedWriter bw = null;  
			try {  
		        FileWriter fw = new FileWriter(new File(path).getAbsoluteFile());  
		        bw = new BufferedWriter(fw);  
		        bw.write(s);  
		        bw.close();  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }  
			
			try {
				wait(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
    
	
	
	public void changeTime(String path,long time) {
		synchronized(this) {
		File file=new File(path);
		try {
		if(!file.exists()) {}//return false;
		else {
			file.setLastModified(time);
			//return true;
		}
		}catch(Exception e) {
			//return false;
		}
		
		try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
	
	
	public void addMkdir(String path) {
		synchronized(this) {
		File file = new File(path);
		try {
        if(!file.exists()){
            file.mkdirs();     
            //return true;
        }
        else {}//return false;
		}catch(Exception e) {
			//return false;
		}
		
		try {
			wait(20);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
	
	
	//文件扫描方法
	public List <Snapshot> renameSearch(Snapshot snap){
		synchronized(this) {
		List <Snapshot> list=new ArrayList();
		int flag=0;
		File filefather=new File(snap.path()).getParentFile();
		File [] files=filefather.listFiles();
		for(File file:files) {
			if(file.isFile() && file.lastModified()==snap.time() && file.length()==snap.size()) {
				if(file.getName().equals(snap.name())) flag=1;
				else list.add(new Snapshot(file));
			}
		}
		
		if(flag==1) {
			list.add(0,snap);
			flag=0;
		}
		
		return list;
		}
		
	}

	public List <Snapshot> pathSearch(Snapshot s) {
		synchronized(this) {
		String range=new File(s.path()).getParent();
		List <Snapshot> list=new ArrayList();
		return(findFiles(range,s,list));
		//return list;
		}
	}
	
	public List <Snapshot> pathSearch1(Snapshot s,String range) {
		synchronized(this) {
		List <Snapshot> list=new ArrayList();
		return(findFiles(range,s,list));
		//return list;
		}
	}
	
	public Snapshot modifiedSearch(Snapshot s) {
		synchronized(this) {
		String fatherPath;
		fatherPath=new File(s.path()).getParent();
		File file=new File(fatherPath);
		File [] fileCurLayer=file.listFiles();

		for(File filename: fileCurLayer) {
			if(filename.isFile()) {
				if(filename.getName().equals(s.name())) {
					return new Snapshot(filename);
				}
			}
		}
		
		return null;
		}
	}
	
	public List <Snapshot> findFiles(String path,Snapshot s,List <Snapshot> list) {
		synchronized(this) {
		int i,flag=0;
		File[] files = new File(path).listFiles(); 
		File tempFile;
		for(File file:files) {  
            if(file.isDirectory()){  
                findFiles(file.getAbsolutePath(),s,list);  
            }
            else if(file.isFile()){  
                if(file.getName().equals(s.name()) && file.length()==s.size() && file.lastModified()==s.time()){ 
                    if(file.getAbsolutePath().equals(s.path())) flag=1;
                    else list.add(new Snapshot(file));
                }  
            }  
        }  
        
		if(flag==1) {
			list.add(0,s);
			flag=0;
		}
		return list;
		}
		
	}
	
	
	
	//目录扫描方法
	public List <Snapshot> modifiedSearchCat(List <Snapshot> list) {
		synchronized(this) {
		int i;
		List <Snapshot> out=new ArrayList();
		for(i=0;i<list.size();i++) {
			out.add(modifiedSearch(list.get(i)));
		}
		
		return out;
		}
	}
	
	public List <List <Snapshot>> renameSearchCat(List <Snapshot> list) {
		synchronized(this) {
		int i;
		List <List <Snapshot>> out=new ArrayList();	
		for(i=0;i<list.size();i++) {
			out.add(renameSearch(list.get(i)));
		}
		return out;
		}
	}
	
	public List <List <Snapshot>> pathSearchCat(List <Snapshot> list,String range) {
		synchronized(this) {
		int i;
		List <List <Snapshot>> out=new ArrayList();
		for(i=0;i<list.size();i++) {
			out.add(pathSearch1(list.get(i),range));
		}
		return out;
		}
	}	
	
	//recovery
	public void recovery(Snapshot snapFormmer,Snapshot snapBack,int i) {
		synchronized(this) {
		if(i==0) {
			String To=snapFormmer.path();
			String From=snapBack.path();
			
			renameFile(From,To);
		}
		else {
			String To=snapFormmer.path();
			String From=snapBack.path();
			
			moveFile(From,To);
		}
		}
	}
	
	//findfiles
	 public List <Snapshot> update(String path,List <Snapshot> list,List <Snapshot> oldlist) {
		    //for(int i=0;i<oldlist.size();i++) System.out.println("path:"+oldlist.get(i).path());
		 	synchronized(this) {
	    	int i;
			File[] files = new File(path).listFiles(); 
			File tempFile;
			
			for(i =0;i<files.length;i++) {  
		           tempFile = files[i];  
		           if(tempFile.isDirectory()){  
		                update(tempFile.getAbsolutePath(),list,oldlist);  
		            }
		            else if(tempFile.isFile()) {
		            	//System.out.println("safeFile.319:isFile:"+new Snapshot(tempFile).path());
		            	if(!oldlist.contains(new Snapshot(tempFile))){
		            	  list.add(new Snapshot(tempFile));
		            	 //System.out.println("safeFile.321:contains:"+new Snapshot(tempFile).path());
		            	}
		            }  
		     }
			
			return list;
		 	}
	    }
	
}


