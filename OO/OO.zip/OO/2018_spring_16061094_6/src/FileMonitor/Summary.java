package FileMonitor;

import java.io.*;
import java.util.concurrent.atomic.AtomicInteger; 

public class Summary {
	private final AtomicInteger count_0 = new AtomicInteger(0);  
	private final AtomicInteger count_1 = new AtomicInteger(0);  
	private final AtomicInteger count_2 = new AtomicInteger(0);  
	private final AtomicInteger count_3 = new AtomicInteger(0);
	private PrintWriter out;
	
	public Summary(PrintWriter out) {
		this.out=out;
	}
	
	public void add(int i) {
		if(i==0) {
			count_0.addAndGet(1);
			out.println("renamed:"+count_0);
			out.flush();
		}
		else if(i==1) {
			count_1.addAndGet(1);
			out.println("path-changed:"+count_1);
			out.flush();
		}
		else if(i==2) {
			count_2.addAndGet(1);
			out.println("modified:"+count_1);
			out.flush();
		}
		else{
			count_3.addAndGet(1);
			out.println("size-changed:"+count_3);
			out.flush();
		}
	}
}
