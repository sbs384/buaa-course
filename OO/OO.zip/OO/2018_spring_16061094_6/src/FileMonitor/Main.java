package FileMonitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		File file=new File("summary.txt"); 
		PrintWriter out =new PrintWriter(file);
		
		
		File file1=new File("detail.txt"); 
		PrintWriter out1 =new PrintWriter(file1);
		
		
		int i;
		QueueWork queueWork=new QueueWork();
		SafeFile safefile=new SafeFile();
		Summary summary=new Summary(out);
		Detailed detailed=new Detailed(out1);
		
		Scanner keyboard=new Scanner(System.in);
		String input=keyboard.nextLine();
		
		if(input.equals("END")) {
			System.out.println("#END!There is no monitoring work!");
			System.exit(1);
		}
		
		//input
		while(!input.equals("END")) {		
			Work work=new Work(input);
			queueWork.Check(work);
			input=keyboard.nextLine();
		}
		
		//满足要求则测试开始
		//System.out.println("Main.49:queueWorkLen:"+queueWork.Len());
		if(queueWork.Len()!=0) {
			for(i=0;i<queueWork.Len();i++) {
				Work w=queueWork.curWork(i);
				//System.out.println("Main.53:work"+i+":"+"sort:"+w.sort()+" mission:"+w.mission()+" path:"+w.path()+" tigger:"+w.tigger());
				if(queueWork.curWork(i).sort()==0) new MonitorFile("Thread"+i,queueWork.curWork(i),safefile,summary,detailed).start();
				else new MonitorCat("Thread"+i,queueWork.curWork(i),safefile,summary,detailed).start();
			}
			
			
			
			Test test=new Test("Test",safefile);
			try {
				test.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//在这!!!在这测试!!!
			test.start();
		}
		
		
		
		else{
			System.out.println("#END!There is no legal monitoring work!");
			System.exit(0);
		}
	}
}

