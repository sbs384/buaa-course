package FileMonitor;

import java.io.PrintWriter;

public class Detailed {
	private PrintWriter out;
	
	public Detailed(PrintWriter out) {
		this.out=out;
	}
	
	public void print(Snapshot snapformmer,Snapshot snapback,int i) {
		synchronized(this) {
			if(i==0) out.println("renamed:");
			else if(i==1) out.println("path-changed:");
			else if(i==2) out.println("modified:");
			else  out.println("size-changed:");
			out.flush();
		
			out.println("size:"+snapformmer.size()+";"+snapback.size());
			out.flush();
			out.println("name:"+snapformmer.name()+";"+snapback.name());
			out.flush();
			out.println("path:"+snapformmer.path()+";"+snapback.path());
			out.flush();
			out.println("time:"+snapformmer.time()+";"+snapback.time());
			out.flush();
			out.println(" ");
		}
	}

}
