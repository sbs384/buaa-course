package taxi;

import java.util.Random;
import java.awt.Point;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;


public class Taxi implements Runnable {
	/* @Overview:Taxi类模拟出租车行驶状况，包括停止状态，服务状态，接单状态以及等待服务状态 */
	
	private int ID;
	private int curx;
	private int cury;
	private int state;
	private int credit=0;
	private long waitStartTime;
	private int depax;
	private int depay;
	private int destx;
	private int desty;
	private TaxiGUI gui;
	private int orderflag=0;
	private int serveflag=0;
	private long curTime;
	private Map map;
	private boolean stopMe=true;
	private Request request;
	private int mapState=0;
	private Point p;
	private int ghost=0;
	private LightMap lightmap;
	private List <String> Record=new ArrayList <String> ();
	
	private int dist_2[][]=new int [82][82];
	private boolean visit_2 [][]=new boolean [82][82];
	private Queue <Point> distqueue_2=new LinkedList <Point> ();
	private int flow_2[][]=new int [82][82];
	private Point [][] ahead=new Point [82][82];
	
	public final static int stop=0;
	public final static int orderTaking=1;
	public final static int wait=2;
	public final static int serve=3;
	public final static int right=0;
	public final static int left=1;
	public final static int up=2;
	public final static int down=3;
	public final static int green=1;
	public final static int red=2;
	public final static int empty=0;
	public final static int rightr=1;
	public final static int leftr=2;
	public final static int straightr=0;
	public final static int allr=-1;
	public final static int infinite=40000000;
	

	public boolean repOK() {
        /** @REQUIRES:
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==!(map==null || p==null || lightmap==null || request==null ||dist_2==null || visit_2==null || distqueue_2==null || flow_2==null || ahead==null || gui==null) &&
        *      !(state!=0 && state!=1 && state!=2 && state!=3)&&
        *      !(curx<0 || curx>79 || cury<0 || cury>79 || depax<0 || depax>79 || depay<0 || depay>79 || destx<0 || destx>79 || desty<0 || desty>79)&&
        *      !(ID<0 || ID>=100 || credit<0 || waitstartTime<0);
        *      
        */ 
      if(map==null || p==null || lightmap==null || request==null ||dist_2==null || visit_2==null || distqueue_2==null || flow_2==null || ahead==null || gui==null) return false;
      if(state!=0 && state!=1 && state!=2 && state!=3) return false;
      if(curx<0 || curx>79 || cury<0 || cury>79 || depax<0 || depax>79 || depay<0 || depay>79 || destx<0 || destx>79 || desty<0 || desty>79) return false;
      if(ID<0 || ID>=100 || credit<0 || waitStartTime<0) return false;
      
      return true;
            
   }
	
	
	public Taxi(String name,int ID,TaxiGUI gui,Map map,LightMap lightmap) {
		/**@REQUIRES:name!=null && ID>=0 && ID<100 && gui!=null && map!=null && lightmap!=null;
        @MODIFIES:
      			\this.ID;
      			\this.curx;
      			\this.cury;
      			\this.state;
      			\this.gui;
      			\this.waitStartTime;
      			\this.map;
      			\this.lightmap;
        @EFFECTS:
      			\this.ID==ID;
      			\this.curx==curx;
      			\this.cury==cury;
      			\this.state==state;
      			\this.gui==gui;
      			\this.waitStartTime==waitStartTime;
      			\this.map==map;
      			\this.lightmap==lightmap;	
        */
		
		this.ID=ID;
		initialCoordinate();
		state=wait;
		this.gui=gui;
		this.map=map;
		this.waitStartTime=System.currentTimeMillis();
		
		gui.SetTaxiType(ID,0);
		gui.SetTaxiStatus(ID,new Point(curx,cury),state);
		
		this.lightmap=lightmap;
	}
	
	public Taxi(String name,int ID,TaxiGUI gui,Map map,int statein,Point point,int credit,LightMap lightmap){
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.ID;
      	*		\this.curx;
      	*		\this.cury;
      	*		\this.state;
      	*		\this.gui;
      	*		\this.waitStartTime;
      	*		\this.map;
      	*		\this.ghost;
      	*		\this.credit;
      	*		\this.lightmap;
        *@EFFECTS:
      	*		\this.ID==ID;
      	*		\this.curx==curx;
      	*		\this.cury==cury;
      	*		\this.state==state;
      	*		\this.gui==gui;
      	*		\this.waitStartTime==waitStartTime;
      	*		\this.map==map;
      	*		\this.ghost==1;
      	*		\this.credit==credit;
      	*		\this.lightmap==lightmap;	
        */
		
		this.ID=ID;
		this.state=statein;
		this.gui=gui;
		this.map=map;
		this.credit=credit;
		this.lightmap=lightmap;
		
		if(state==stop) {
			setCoordinate(point);
			gui.SetTaxiType(ID,0);
			gui.SetTaxiStatus(ID,new Point(curx,cury),state);
		}
		else if(state==wait) {
			setCoordinate(point);  
			this.waitStartTime=System.currentTimeMillis();
			gui.SetTaxiType(ID,0);
			gui.SetTaxiStatus(ID,new Point(curx,cury),state);
		}
		else if(state==orderTaking){
			initialCoordinate();
			try {
				setOrder(new Request(),new Point(curx(),cury()),point);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(state==serve) {
			ghost=1;
			initialCoordinate();
			try {
				setServe(new Request(),(int)(point.getX()),(int)(point.getY()));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		//gui.SetTaxiStatus(ID,new Point(curx,cury),state);		
	}
	
	public void run() {
		int dirbef=allr,dir,routine,n=0;
		boolean pass=false;;
		long time,sumtime=0;
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.state;
      	*		\this.curx;
      	*		\this.cury;
      	*		\this.curTime;
        *@EFFECTS:
       	*		根据出租车状态对出租车进行调度
      	*		若处于stop状态，则休眠1s钟后变为wait状态
        *       若处于wait状态，若wait时间小于20s,则根据路径选择规则运行；若wait时间超过20s,则休眠1s后再变为wait状态
        *       若处于serve状态，则根据最短路径运行至乘客终点
        *       若处于orderTaking状态，则根据最短路径运行至乘客起点		
        */
		
		while(stopMe) {
			int curState=state();
		
			//orderTaking状态
			if(curState==orderTaking) {
				if(orderflag==0) {
					curTime=System.currentTimeMillis();
					orderflag=1;
					
					request.out().println("-----------------------------------pathOrder-----------------------------------");
					request.out().flush();
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
				}
				if(curx==depax && cury==depay) {
					//System.out.println("到达乘客位置的时刻:"+curTime);
					//System.out.println("到达乘客位置坐标:("+curx()+","+cury()+")");
					request.out().println("OrderDestTime:"+curTime+"  OrderDestCoordinate:("+curx()+","+cury()+")");
					request.out().flush();
	
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),stop);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					setServe(request,destx,desty);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
					curTime+=1000;
					orderflag=0;
				}
				
				else {
					do {
						while(map.state()!=mapState) {
							SPFA_2(depax,depay);
							mapState=map.state();
						}
						
						p=ahead[curx()][cury()];
						time=System.currentTimeMillis();
						do {
							dir=direction(p,curx(),cury());
							routine=routine(dirbef,dir);
							
							if(routine==rightr) pass=true;
							else if(routine==leftr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
							else if(routine==straightr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
						}while(!pass);
						time=System.currentTimeMillis()-time;
						
						
					}while(map.state()!=mapState || !pass);
					
					//System.out.println(p.getX()+";"+p.getY());
					
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					
					//System.out.println("order:"+curx+";"+cury);
					curTime=curTime+500+time;
					map.addflow(new Point(curx(),cury()),p);
					setCoordinate(p);
					dirbef=dir;
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
					
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();

					
				}
			}
			
			//wait状态
			else if(curState==wait) {
				if(waitStartTime+20000+sumtime<=System.currentTimeMillis()) {
					sumtime=0;
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					if(state()!=orderTaking) {
					setState(wait);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					waitStartTime=System.currentTimeMillis();
					}
				}
				
				else {
					do {
						do{
							//p=(right(curx(),cury(),dirbef));
							p=randomCoordinate(curx(),cury());
						}while(!waitpass(p,curx(),cury()));
						
						time=System.currentTimeMillis();
						do {
							dir=direction(p,curx(),cury());
							routine=routine(dirbef,dir);
							
							if(routine==rightr) {
								pass=true;
								//System.out.println(dirbef+","+dir);
							}
							else if(routine==leftr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
							else if(routine==straightr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
						}while(!pass);
						time=System.currentTimeMillis()-time;
						sumtime=sumtime+time;
						
					}while(!waitpass(p,curx(),cury()) || !pass);
					
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					
					map.addflow(new Point(curx(),cury()),p);
					setCoordinate(p);
					//if(ID==1) System.out.println(dir);
					dirbef=dir;
					gui.SetTaxiStatus(ID,new Point(curx(),cury()),state());
				}
			}
			
			//serve状态
			else if(curState==serve) {			
				if(serveflag==0) {
					if(ghost==1) curTime=System.currentTimeMillis();
					request.out().println("-----------------------------------pathServe-----------------------------------");
					request.out().flush();
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
					serveflag=1;
				}
				if(curx==destx &&cury==desty) {
					//System.out.println("服务成功啦:"+curx+";"+cury);
					request.out().print("\n");
					request.out().flush();
					request.out().println("ServeDestTime:"+curTime+"  ServeDestCoordinate:("+curx()+","+cury()+")");
					request.out().flush();
					request.out().println("The request is ended successfully!");
					request.out().flush();
					
					if(ID>=0 && ID<=29) Record.add(request.path());
					
					if(ghost==1) ghost=0;
					creditAdd(3);
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					serveflag=0;
					setState(wait);
					waitStartTime=System.currentTimeMillis();
					sumtime=0;
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
				}
				
				else{
					do {
						while(map.state()!=mapState) {
							SPFA_2(destx,desty);
							mapState=map.state();
						}
						
						p=ahead[curx()][cury()];
						time=System.currentTimeMillis();
						do {
							dir=direction(p,curx(),cury());
							routine=routine(dirbef,dir);
							
							if(routine==rightr) pass=true;
							else if(routine==leftr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
							else if(routine==straightr) {
								if(dirbef==right || dirbef==left) {
									if(lightmap.getLight(curx(),cury())==green || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
								else {
									if(lightmap.getLight(curx(),cury())==red || lightmap.getLight(curx(),cury())==empty) pass=true;
									else pass=false;
								}
							}
						}while(!pass);
						time=System.currentTimeMillis()-time;
						
						
					}while(map.state()!=mapState || !pass);
					
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
					
					//System.out.println("serve:"+curx+";"+cury);
					map.addflow(new Point(curx(),cury()),p);
					setCoordinate(p);
					dirbef=dir;
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					curTime+=500+time;

					//System.out.println("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
				}
					
			}
			
			else if(curState==stop) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					System.out.println("Crash error!");
					e.printStackTrace();
				}
				setState(wait);
				waitStartTime=System.currentTimeMillis();
				gui.SetTaxiStatus(ID,new Point(curx,cury),state);	
			}
		}
			
}
	
	
	public void initialCoordinate() {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.curx;
       	*		\this.cury;
        *@EFFECTS:
       	*		curx==rand.nextInt(80);
		*	    cury==rand.nextInt(80);			
        */
		
		Random rand=new Random();
		curx=rand.nextInt(80);
		cury=rand.nextInt(80);
	}

	
	public synchronized Point randomCoordinate(int x,int y) {
		/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:
       	*		\this.curx;
      	*		\this.cury;
        *@EFFECTS:
       	*		对处于wait状态的出租车行驶方向进行选择
      	*		在所有连街边中选择流量最小的进行选择
       	*		若有多个流量最小的边，则随机选择	
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		int randindex,minflow=40000000,tempflow;
		int [][] mapCoord=map.getMap();
		List <Integer> existDirection=new ArrayList <Integer>();
		if(mapCoord[x][y]==1 || mapCoord[x][y]==3) {//right
			tempflow=map.getflow(x,y,x,y+1);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.add(0);
			}
		}
		if(y-1>=0 && (mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3)) {//left
			tempflow=map.getflow(x,y,x,y-1);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(1);
			}
			else if(tempflow==minflow) existDirection.add(1);
		}
		if(x-1>=0 && (mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3)) {//up
			tempflow=map.getflow(x,y,x-1,y);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(2);
			}
			else if(tempflow==minflow) existDirection.add(2);
		}
		if((mapCoord[x][y]==2 || mapCoord[x][y]==3)) {//down
			tempflow=map.getflow(x,y,x+1,y);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(3);
			}
			else if(tempflow==minflow) existDirection.add(3);
		}
		
		Random rand=new Random();
		randindex=existDirection.get(rand.nextInt(existDirection.size()));
		existDirection.clear();
		
		if(randindex==0) return new Point(x,y+1);
		else if(randindex==1) return new Point(x,y-1);
		else if(randindex==2) return new Point(x-1,y);
		else return new Point(x+1,y);
	}
	
	
	
	public synchronized int state() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*	   \result==state;	
      	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		return state;
	}	
	
	
	public synchronized void setState(int i) {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.state;
        *@EFFECTS:
      	*	   state==i;
      	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();	
        */
		
		state=i;
	}
	
	public synchronized int credit() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*	   \result==credit;	
      	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		return credit;
	}	
	
	
	public synchronized void creditAdd(int i) {
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.credit;
        *@EFFECTS:
       	*	   (i==1)==>credit+1;
        *       (i==3)==>credit+3;
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		if(i==1) credit+=1;
		else  credit+=3;
	}
	
	public synchronized void setOrder(Request r,Point depa,Point dest) {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.state;
       	*		\this.depax;
       	*		\this.depay;
      	*		\this.destx;
       	*		\this.desty;
       	*		\this.ahead;
        *       \this.request;
        *@EFFECTS:
       	*	   \this.state==state;
       	*	   \this.depax==(int)(depa.getX());
     	*	   \this.depay==(int)(depa.getY());
		*       \this.request==r;
     	*	   \this.destx==(int)(dest.getX());
		*	   \this.desty==(int)(dest.getY());
	    *       \this.request==r;
		*	   ahead记录各个点到源点最短路径
		* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		state=orderTaking;
		if(ID>=0 && ID<=29) gui.SetTaxiType(ID,1);
		else gui.SetTaxiType(ID,0);
		gui.SetTaxiStatus(ID,new Point(curx,cury),state);
		
		depax=(int)(depa.getX());
		depay=(int)(depa.getY());
		//System.out.println("depa:"+depax+";"+depay);
		SPFA_2((int)(depa.getX()),(int)(depa.getY()));
		request=r;
		destx=(int)(dest.getX());
		desty=(int)(dest.getY());
	}
	
	public synchronized void setServe(Request r,int x,int y) {
		/**@REQUIRES:
       	*@MODIFIES:
       	*		\this.state;
       	*		\this.destx;
       	*		\this.desty;
       	*		\this.ahead;
        *        \this.request;
        *@EFFECTS:
      	*	   \this.state==state;
		*       \this.request==r;
		*	   \this.destx==x;
		*       \this.desty==y;
		*	   ahead记录各个点到源点最短路径
		* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		this.request=r;
		state=serve;
		
		if(ID>=0 && ID<=29) gui.SetTaxiType(ID,1);
		else gui.SetTaxiType(ID,0);
		gui.SetTaxiStatus(ID,new Point(curx,cury),state);
		
		SPFA_2(x,y);
		destx=x;
		desty=y;
	}
	
	public synchronized int curx() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*	   \result==curx;
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();	
        */
		
		return curx;
	}
	
	public synchronized int cury() {
		/**@REQUIRES:
        *MODIFIES:None;
        *@EFFECTS:
       	*	   \result==cury;
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();	
        */
		
		return cury;
	}
	
	
	public synchronized int ID() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*	   \result==ID;
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();	
        */
		
		return ID;
	}

    
    public void setCoordinate(Point point) {
    	/**@REQUIRES:
        *@MODIFIES:
       	*		\this.curx;
       	*		\this.cury;
        *@EFFECTS:
       	*	    curx==(int)(point.getX());
      	*		cury==(int)(point.getY());	
        */
    	
    	curx=(int)(point.getX());
        cury=(int)(point.getY());
    }
	
    
    public  void SPFA_2(int x,int y) {
    	/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:None;
        *@EFFECTS:
        *    find the shortest path of every node in map to (x,y);
        *    record the shortest path in ahead[][];
        */
    	
    	int [][] mapCoord=map.getMap();
    	
		distqueue_2.clear();
		for(int i=0;i<82;i++) {
			for(int j=0;j<82;j++) {
				dist_2[i][j]=infinite;
				visit_2[i][j]=false;
				flow_2[i][j]=infinite;
				ahead[i][j]=null;
			}
		}
		
		dist_2[x][y] = 0;
		ahead[x][y]=new Point(x,y);
		visit_2[x][y]=true;
		flow_2[x][y]=0;
		distqueue_2.offer(new Point(x,y));
		
		while (!distqueue_2.isEmpty()){
			int x1= (int)(distqueue_2.peek().getX());
			int y1= (int)(distqueue_2.poll().getY());
			visit_2[x1][y1]=false;
			
			if(mapCoord[x1][y1]==1 || mapCoord[x1][y1]==3) {//right
				lax_2(x1,y1,x1,y1+1);
			}
			if(y1-1>=0 && (mapCoord[x1][y1-1]==1 || mapCoord[x1][y1-1]==3)) {//left
				lax_2(x1,y1,x1,y1-1);
			}
			if(x1-1>=0 && (mapCoord[x1-1][y1]==2 || mapCoord[x1-1][y1]==3)) {//up
				lax_2(x1,y1,x1-1,y1);
			}
			if((mapCoord[x1][y1]==2 || mapCoord[x1][y1]==3)) {//down
				lax_2(x1,y1,x1+1,y1);
			}
		}
	}
	
    public void lax_2(int x,int y,int xnew,int ynew) {
    	/**@REQUIRES:0<=x<=79 && 0<=y<=79 && 0<=xnew<=79 && 0<=ynew<=79;
        *@MODIFIES:None;
        *@EFFECTS:
       	*		slax the edge between (x,y) and (xnew,ynew);
        */
    	
    	int sumflow;
    	//System.out.println("x:"+x+" y:"+y+" xnew:"+xnew+" ynew:"+ynew);
    	sumflow=map.getflow(x,y,xnew,ynew)+flow_2[x][y];
    
    	if(dist_2[xnew][ynew]>dist_2[x][y]+1 || dist_2[xnew][ynew]==dist_2[x][y]+1 && flow_2[xnew][ynew]>sumflow) {
    		/*if(xnew==1 && ynew==0) {
    			System.out.println("x:"+x+" y:"+y);
    			System.out.println("dist_2[xnew][ynew]:"+dist_2[xnew][ynew]);
    			System.out.println("dist_2[x][y]+1:"+(dist_2[x][y]+1));
    			System.out.println("flow_2[x][y]:"+flow_2[x][y]);
    			System.out.println("map.getflow(x,y,xnew,ynew):"+map.getflow(x, y, xnew, ynew));
    		}*/
    	   		
    		
    		dist_2[xnew][ynew]=dist_2[x][y]+1;
    		ahead[xnew][ynew]=new Point(x,y);
    		flow_2[xnew][ynew]=sumflow;
    		if(!visit_2[xnew][ynew]) {
    			distqueue_2.offer(new Point(xnew,ynew));
    			visit_2[xnew][ynew]=true;
    		}
    	}
    }
    
    public int demens(int x,int y) {
    	/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *MODIFIES:None;
        *@EFFECTS:
       	*	   \result==x*80+y;
        */
    	
    	return x*80+y;
    }
    
    public int direction(Point p,int x,int y) {
    	/**@REQUIRES:p!=null && 0<=x<=79 && 0<=y<=79;
  	    *@MODIFIES:None;
  	    *@EFFECTS:
  	    *	(x==x1 && y<y1)==> \result== right;
    	*	(x==x1 && y>y1)==> \result== left;
    	*	(x<x1 && y==y1)==> \result== down;
    	*	(x>x1 && y==y1)==> \result== up;
    	*	!((x==x1 && y<y1) || (x==x1 && y>y1) || (x<x1 && y==y1) || (x>x1 && y==y1))==>\result==-1; 
  	    *      	
  	    */
    	
    	int x1=(int)(p.getX()),y1=(int)(p.getY());
    	
    	if(x==x1 && y<y1) return right;
    	else if(x==x1 && y>y1) return left;
    	else if(x<x1 && y==y1) return down;
    	else if(x>x1 && y==y1) return up;
    	else return -1;
    }
    
    public boolean waitpass(Point p,int x,int y) {
    	/**@REQUIRES:p!=null && 0<=x<=79 && 0<=y<=79;
   	    *@MODIFIES:None;
   	    *@EFFECTS:
   	    *	\result==((x==x1 && y<y1) && (mapCoord[x][y]==1 || mapCoord[x][y]==3))||
    	*	((x==x1 && y>y1) && (mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3))||
    	*	((x<x1 && y==y1) && (mapCoord[x][y]==2 || mapCoord[x][y]==3))||
    	*	((x>x1 && y==y1) && (mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3));
   	    */
    	
    	int x1=(int)(p.getX()),y1=(int)(p.getY());
    	int [][]mapCoord=map.getMap();
    	
    	if(x==x1 && y<y1) {
    		if(mapCoord[x][y]==1 || mapCoord[x][y]==3) return true;
    		else return false;
    	}
    	else if(x==x1 && y>y1) {
    		if(mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3) return true;
    		else return false;
    	}
    	else if(x<x1 && y==y1) {
    		if(mapCoord[x][y]==2 || mapCoord[x][y]==3) return true;
    		else return false;
    	}
    	else {
    		if(mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3) return true;
    		else return false;
    	}
   
    }
    
    public int routine(int dirbef,int dir) {
    	/**@REQUIRES:
         *@MODIFIES:None;
         *@EFFECTS:
       	*	   \result==direction;	
         */
    	
    	if(dirbef==right) {
    		if(dir==down) return rightr;
    		else if(dir==up) return leftr;
    		else return straightr;
    	}
    	else if(dirbef==left) {
    		if(dir==up) return rightr;
    		else if(dir==down) return leftr;
    		else return straightr;
    	}
    	else if(dirbef==up) {
    		if(dir==right) return rightr;
    		else if(dir==left) return leftr;
    		else return straightr;
    	}
    	else if(dirbef==down) {
    		if(dir==left) return rightr;
    		else if(dir==right) return leftr;
    		else return straightr;
    	}
    	else return straightr;
    }
    
    public void check() {
    	
    }
    
    public int getIDSon() {
    	/**@REQUIRES:
 	    *@MODIFIES:None;
 	    *@EFFECTS:
 	    *       \result==ID;	
 	    */
 	    	
    	
    	return ID;
    }
    
    public Map getMapSon() {
    	/**@REQUIRES:
  	    *@MODIFIES:None;
  	    *@EFFECTS:
  	    *       \result==map;	
  	    */
    	
    	return map;
    }
    
    public int[][] getDist_2() {
    	/**@REQUIRES:
  	    *@MODIFIES:None;
  	    *@EFFECTS:
  	    *       \result==dist_2;	
  	    */
    	
		return dist_2;
	}

	public boolean[][] getVisit_2() {
		/**@REQUIRES:
	 	*@MODIFIES:None;
	 	*@EFFECTS:
	 	*       \result==visit_2;	
	 	*/
		
		return visit_2;
	}

	public Queue<Point> getDistqueue_2() {
		/**@REQUIRES:
	 	*@MODIFIES:None;
	 	*@EFFECTS:
	 	*       \result==distqueue_2;	
	 	*/
		
		return distqueue_2;
	}
    
    public int[][] getFlow_2() {
    	/**@REQUIRES:
  	    *@MODIFIES:None;
  	    *@EFFECTS:
  	    *       \result==flow_2;	
  	    */
    	
		return flow_2;
	}

	public Point[][] getAhead() {
		/**@REQUIRES:
	 	*@MODIFIES:None;
	 	*@EFFECTS:
	    *       \result==ahead;	
	 	*/
		
		return ahead;
	}
	
	public List <String> getRecord(){
		/**@REQUIRES:
	    *@MODIFIES:None;
	    *@EFFECTS:
	    *		\result==Record;
	    */
		
		return Record;
	}
	
	public void checkForward() throws IOException{
		
	}
	
	public void checkBackward() throws IOException{
		
	}

	
	//接口函数
    //指定id出租车的相关信息
    public  int checkstate() {
    	/**@REQUIRES:
        *MODIFIES:None;
        *@EFFECTS:
       	*	   \result==state();	
        */
    	
    	return  state();
    }
    
    public  Point checkcoorDinate() {
    	/**@REQUIRES:
        *MODIFIES:None;
        *@EFFECTS:
       	*	   \result==Point(curx(),cury());
        */
    	
    	return new Point(curx(),cury());
    }
   

	public long checktime() {
    	/**@REQUIRES:
        *MODIFIES:None;
        *@EFFECTS:
       	*	   \result==System.currentTimeMillis();
        */
    	
    	return System.currentTimeMillis();
    }
    
}

