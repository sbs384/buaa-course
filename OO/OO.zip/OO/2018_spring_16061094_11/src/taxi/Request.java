package taxi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;
import java.util.ArrayList;


public class Request {
	/* @Overview:Request类构造请求对象 */
	
	private int depax;
	private int depay;
	private int destx;
	private int desty;
	private long time;
	private int reqID;
	private String path;
	private PrintWriter out;
	private List <Integer> carReady=new ArrayList <Integer> ();
	private static int num=-1;
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==!(out!=null || carReady==null)&&
        *      !(\all int i,j;0<=i<carReady.size();queue.get(i)==null)&&
        *      !(reqID<0 || depax<0 || depax>79 || depay<0 || depay>79 || destx<0 || destx>79 || desty<0 || desty>79 || time<0);
        */ 
	  if(out==null || carReady==null) return false;
	  for(int i=0;i<carReady.size();i++) {
		 if(carReady.get(i)==null) return false;
	  }
	 
	  if(reqID<0 || depax<0 || depax>79 || depay<0 || depay>79 || destx<0 || destx>79 || desty<0 || desty>79 || time<0) return false;
	  
	  return true;        
   }
	
    public Request () throws FileNotFoundException {
    	/**@REQUIRES:
        *@MODIFIES:
      	*		\this.out;
        *@EFFECTS:
      	*		\this.out==PrintWriter(new File(path));	
        */
    	
    	out=new PrintWriter(new File("log"+(num--)+".txt"));
    	path="log"+(num+1)+".txt";
    }
	
    public Request(String s,long time) {
    	/**@REQUIRES:
         *@MODIFIES:
       	*		\this.out;
       	*		\this.depax;
       	*		\this.depay;
       	*       \this.destx;
       	*       \this.desty;
       	*       \this.time;
        *@EFFECTS:
       	*		\this.out==PrintWriter(new File(path));	
       	*		\this.depax==depax;
       	*		\this.depay==depay;
       	*       \this.destx==destx;
       	*       \this.desty==desty;
       	*       \this.time==time;
        */
    	
    	try {
		String [] str=s.split(",");
		
		depax=Integer.parseInt(str[1].replaceAll("\\(",""));
		depay=Integer.parseInt(str[2].replaceAll("\\)",""));
		destx=Integer.parseInt(str[3].replaceAll("\\(",""));
		str[4]=str[4].replaceAll("\\)","");
		desty=Integer.parseInt(str[4].replaceAll("\\]",""));
		
		this.time=time;
    	}catch(Exception e) {
    		System.out.println("Crash error!");
    		e.printStackTrace();
    	}
	}
	
	public void listAdd(int j) {
		/**@REQUIRES:0<=j<=carReady.Len();
        *@MODIFIES:
      	*		this.carReday;
        *@EFFECTS:
       	*		carReady.add(j);				
        */
		
		carReady.add(j);
	}
	
	public long time() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==time;				
        */
		
		return time;
	}
	
	public int depax() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==depax;				
        */
		
		return depax;
	}
	
	public int depay() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==depay;				
        */
		
		return depay;
	}
	
	public int destx() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==destx;				
        */
		
		return destx;
	}
	
	public int desty() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==desty;				
        */
		
		return desty;
	}
	
	public List <Integer> list() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		\result==carReady;				
        */
		
		return carReady;
	}
	
	public void setID(int reqID) {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.reqID;
        *@EFFECTS:
      	*		\this.reqID==reqID;			
        */
		
		this.reqID=reqID;
	}
	
	public int reqID() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==reqID;				
        */
		
		return reqID;
	}
	
	public void setOut(File file) throws FileNotFoundException{
		/**@REQUIRES:file.exits && file.isFile;
        *@MODIFIES:
       	*		\this.out;
        *@EFFECTS:
      	*		\this.out==PrintWrier(file);				
        */
		
		this.out=new PrintWriter(file);
	}
	
	public PrintWriter out() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==out;				
        */
		
		return out;
	}
	
	public void setPath(String path) {
		this.path=path;
	}
	
	public String path() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==path;				
        */
		
		return path;
	}
	
	
	//重写方法
	   @Override
		public boolean equals(Object obj) {
		   /**@REQUIRES:
	       *@MODIFIES:None;
	       *@EFFECTS:
	   	   *		this.equals(obj)==>result=true;
	  	   *	!this.equals(obj)==>result=false;		
	       */
		   
			if(this==obj) return true;
			if(obj==null) return false;
			if(!(obj instanceof Request)) return false;
			Request request=(Request)obj;
			if(this.depax==request.depax && this.depay==request.depay && this.destx==request.destx && this.desty==request.desty && this.time==request.time) {
				return true;
			}
			else return false;
	   }
}
