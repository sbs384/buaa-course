package taxi;

public class ExceptionHandler implements Thread.UncaughtExceptionHandler{
	/* @Overview:线程异常处理类，防止线程crash  */
	
	public boolean repOK() {
        /** @REQUIRES:
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==true;
        */ 
 
      return true;
            
   }
	
	public void uncaughtException(Thread t, Throwable e) {  
		/** @REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
   		*	exceptional_behavior(Exception);
        */		
		System.out.println("Crash error!");
		e.printStackTrace();
    } 
}
