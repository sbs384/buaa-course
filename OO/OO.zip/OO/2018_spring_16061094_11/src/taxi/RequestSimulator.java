package taxi;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class RequestSimulator extends Thread{
	   /* @Overview:请求输入模拟器类，包括出租车请求以及开关道路请求 */
	
		private ReqQueue reqQueue;
		private Map map;
		private Taxi [] taxiList;
	
		public boolean repOK() {
			/** @REQUIRES:
			 * @MODIFIES:None;
			 * @EFFECTS:
			 *      \result==!(map!=null || reqQueue==null || taxiList==null)&&
			 *      !(\all int i,j;0<=i<reqQueue.Len();queue.get(i)==null);
			 */ 
			if(map==null || reqQueue==null || taxiList==null) return false;
			for(int i=0;i<reqQueue.Len();i++) {
				if(reqQueue.get(i)==null) return false;
			}
	  
			return true;        
		}
	
		
		public RequestSimulator(String name,ReqQueue reqQueue,Map map,Taxi [] taxiList) {
			/**@REQUIRES:name!=null &&  reqQueue!=null && map!=null && taxiList!=null;
	        *@MODIFIES:
	       	*		\this.name;
	       	*		\this.reqQueue;
	       	*		\this.map=map;
	       	*		\this.taxiList;
	        *@EFFECTS:
	      	*		\this.name==name;
	      	*		\this.reqQueue==reqQueue;
	      	*		\this.map==map;
	      	*		\this.taxiList==taxiList;
	        */
			
			super(name);
			this.reqQueue=reqQueue;
			this.map=map;
			this.taxiList=taxiList;
		}
		
		public void run() {
			/**@REQUIRES:
	        *@MODIFIES:
	       	*		\this.reQueue;
	       	*		\this.map;
	        *@EFFECTS:
	      	*		add the request in requestQueue;
	      	*		open the according road;
	        *       close the according road;
	        */
			
			long time;
			Scanner keyboard=new Scanner(System.in);
			String input=keyboard.nextLine();
			time=(System.currentTimeMillis()/100)*100;
			
			if(input.equals("END")) {
				System.out.println("#ERROR!No request!Please run again!");
				System.exit(1);
			}
			
			while(!input.equals("END")) {
			 	input=input.replaceAll("\\s+","");
				
				if(judgeInput(input)==0)
					try {
						reqQueue.add(new Request(input,time));
					} catch (FileNotFoundException e) {
						System.out.println("Crash error!");
						e.printStackTrace();
					}
				
				else if(judgeInput(input)==1) map.open(input);
				else if(judgeInput(input)==2) map.close(input);
				else if(judgeInput(input)==3) {
					String [] str=input.split(",");
					int id=Integer.parseInt(str[1]);
					if(id>29) System.out.println("#ERROR!Invalid request!");
					else {
						if(str[2].charAt(0)=='F')
							try {
								taxiList[id].checkForward();
							} catch (IOException e) {
								e.printStackTrace();
							}
						else
							try {
								taxiList[id].checkBackward();
							} catch (IOException e) {
								e.printStackTrace();
							}
					}
				}
				else System.out.println("#ERROR!Invalid request!");
				
				input=keyboard.nextLine();
				time=(System.currentTimeMillis()/100)*100;
			}
			
			keyboard.close();
			yield();
		}
		
		//格式匹配
		public int judgeInput(String s) {
			/**@REQUIRES:
	        *@MODIFIES:None;
	        *@EFFECTS:
	       	*		s.matches(regex1)==>\result=0;
	       	*		s.matches(regex2)==>\result=1;
	      	*		s.matches(regex3)==>\result=2;
	      	*		!s.matches(regex1) && !s.matches(regex2) && !s.matches(regex3)==>\result=-1;
	        */
			
			String regex1="^\\[CR,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			String regex2="^\\[OP,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			String regex3="^\\[CP,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			String regex4="^\\[TRACE,([0-9]|[1-9][0-9]),(F|B)\\]$";
			
			if(s.matches(regex1)) return 0;
			else if(s.matches(regex2)) return 1;
			else if(s.matches(regex3)) return 2;
			else if(s.matches(regex4)) return 3;
			else return -1;	
		} 
		
	}



