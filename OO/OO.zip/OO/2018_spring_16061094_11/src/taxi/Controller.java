package taxi;

import java.awt.Point;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
 
public class Controller extends Thread{
	/* @Overview:调度器类根据出租车状况对请求进行响应 */
	
    private Map map;
    private int mapState=0;
	private ReqQueue queue;
	private int chosen;
	private Taxi [] taxiList=new Taxi [100];
	private boolean stopMe=true;
	private int dist[][]=new int [82][82];
	private int distTrace[][]=new int [82][82];
	
	private final static int stop=0;
	private final static int orderTaking=1;
	private final static int wait=2;
	private final static int serve=3;
	
	public boolean repOK() {
        /** @REQUIRES:
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==!(dist==null || map==null || queue==null || taxiList==null || distTrace==null)&&
        *      !(\all int i;0<=i<100;taxiList[i]==null)&&
        *      !(mapState<0);
        */ 
	  if(dist==null || map==null || queue==null || taxiList==null || distTrace==null) return false;
	  for(int i=0;i<80;i++) {
		  for(int j=0;i<100;j++) {
			  if(taxiList[i]==null) return false; 
		  }
	  }
	 
	  if(mapState<0) return false;
	  
	  return true;        
   }

	public Controller(String name,Map map,ReqQueue queue,Taxi [] taxiList) {
		/** @REQUIRES:name!=null && map!=null && queue!=null && taxiList!=null;
        *@MODIFIES:
        *	\this.map;
        *	\this.queue;
        *	\this.taxiList;
        *	\this.name;
        *@EFFECTS:
   		*	\this.map==map;
		*	\this.queue==queue;
		*	\this.taxiList==taxiList;
		*	\this.name==name;		
        */
		
		super(name);
		this.map=map;
		this.queue=queue;
		this.taxiList=taxiList;
	}
 
	public void run() {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.queue;
       	*		\this.taxiList;
        *@EFFECTS:
       	*		对请求队列中的请求进行调度
      	*		在窗口期内，则对处于4*4网格内且状态为wait的出租车进行记录
      	*		超过窗口期对处于wait状态且路径最短的出租车进行派单，同时将该请求出队
        */
		
		int i,flag=0,distMin=0,distTemp;
		long curTime;
		try {
		while(stopMe) {
			curTime=System.currentTimeMillis();
			
			//当前时间是否在窗口期内
			while(queue.Len()!=0 && curTime>=queue.time(0)+7500) {
				dist=map.SPFA(queue.depax(0),queue.depay(0));
				distTrace=map.SPFATrace(queue.depax(0),queue.depay(0));
				
				//对已抢单出租车进行比较
				for(int k: queue.list(0)) {
					queue.out(0).println("*Taxi"+taxiList[k].ID()+" take:CurCoordinate：("+taxiList[k].curx()+","+taxiList[k].cury()+")"+"; CurState:"+taxiList[k].state()+"; credit:"+taxiList[k].credit());
					queue.out(0).flush();
					
					if(taxiList[k].state()==wait) {
						if(flag==0) {
							while(map.state()!=mapState && k>29) {
								dist=map.SPFA(queue.depax(0),queue.depay(0));
								mapState=map.state();
							}
					
							if(k>=0 && k<=29) distMin=distTrace[taxiList[k].curx()][taxiList[k].cury()];
							else distMin=dist[taxiList[k].curx()][taxiList[k].cury()];
							
							//System.out.println(distMin+";"+taxiList[k].curx()+","+taxiList[k].cury());
							
							chosen=k;
							flag=1;
						}
						else {
							while(map.state()!=mapState && k>29) {
								dist=map.SPFA(queue.depax(0),queue.depay(0));
								mapState=map.state();
							}
							
							if(k>=0 && k<=29) distTemp=distTrace[taxiList[k].curx()][taxiList[k].cury()];
							else distTemp=dist[taxiList[k].curx()][taxiList[k].cury()];
							
							//System.out.println(distTemp+";"+taxiList[k].curx()+","+taxiList[k].cury());
							
							if(taxiList[k].credit()>taxiList[chosen].credit()) {
								distMin=distTemp;
								chosen=k;
							}
							else if (taxiList[k].credit()==taxiList[chosen].credit()) {
								if(distTemp<distMin) {
									distMin=distTemp;
									chosen=k;
								}
							}
						}
					}
				}
				
				
						//对被选中的出租车进行分单
						if(flag==0) {
							//System.out.println("Request"+queue.reqID(0)+" failed!");
							queue.out(0).print("Request"+queue.reqID(0)+" failed!");
							queue.out(0).flush();
							queue.delete(0);
						}
						else {
							//System.out.print("#出租车"+taxiList[chosen].ID()+"被派单:");
							//System.out.println("被派单时坐标:("+taxiList[chosen].curx()+","+taxiList[chosen].curx()+"); 被派单时刻:"+(queue.time(0)+3000));
							if(taxiList[chosen].state()==2) {
								taxiList[chosen].setOrder(queue.get(0),new Point(queue.depax(0),queue.depay(0)),new Point(queue.destx(0),queue.desty(0)));
								queue.out(0).print("#Taxi"+taxiList[chosen].ID()+" ordered:");
								queue.out(0).flush();
								queue.out(0).println("CurCoordinate:("+taxiList[chosen].curx()+","+taxiList[chosen].cury()+"); curTime:"+System.currentTimeMillis());
								queue.out(0).flush();
								queue.delete(0);
								flag=0;
							}
							else {
								queue.out(0).print("Request"+queue.reqID(0)+" failed!");
								queue.out(0).flush();
								queue.delete(0);
								flag=0;
							}
						}
				
			}
			
			//if(queue.Len()!=0) System.out.println(queue.depax(0));
			//否则进行扫描
			for(i=0;i<queue.Len();i++) {
				//对100辆出租进行扫描
				for(int j=0;j<100;j++) {
					//System.out.println(taxiList[j].curx()+";"+j);
					if(Math.abs(taxiList[j].curx()-queue.depax(i))<=2 && Math.abs(taxiList[j].cury()-queue.depay(i))<=2 && taxiList[j].state()==wait) {
						if(!queue.list(i).contains(j)) {
							queue.listAdd(i,j);
							taxiList[j].creditAdd(1);
							//System.out.println("请求"+queue.reqID(i)+":");
							//System.out.println("抢单的出租车：车号:"+taxiList[j].ID()+"; 当前位置：("+taxiList[j].curx()+","+taxiList[j].cury()+")"+"; 当前状态:"+taxiList[j].state()+"; 信用信息:"+taxiList[j].credit());
							//queue.out(i).println("#请求"+queue.reqID(i)+":");
						}
					}
				}	
			}
		}
		}catch(Exception e) {
			System.out.println("Crash error!");
			e.printStackTrace();
		}
		
	}
	
	
    public int decsendDemension(int x,int y) {
    	/** @REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:None;
        *@EFFECTS:
   		*	\result==x*80+y;		
        */
    	
    	return x*80+y;
    }
    
}
