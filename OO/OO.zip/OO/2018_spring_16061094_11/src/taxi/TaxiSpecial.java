package taxi;

import java.awt.Point;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class TaxiSpecial extends Taxi{
	
	private List <String> Record=new ArrayList <String> ();
	private PrintWriter out;
	
	public boolean repOK() {
        /** @REQUIRES:
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==super.repOK() && !(Record==null) && !(out==null);
        */ 
      
      return super.repOK() && !(Record==null) && !(out==null);
            
   }
	
	public TaxiSpecial(String name,int ID,TaxiGUI gui,Map map,LightMap lightmap) {
		/**@REQUIRES:name!=null && ID>=0 && ID<100 && gui!=null && map!=null && lightmap!=null;
        *@MODIFIES:
      	*		\this.ID;
      	*		\this.curx;
      	*		\this.cury;
      	*		\this.state;
      	*		\this.gui;
      	*		\this.waitStartTime;
      	*		\this.map;
      	*		\this.lightmap;
        *@EFFECTS:
      	*		\this.ID==ID;
      	*		\this.curx==curx;
      	*		\this.cury==cury;
      	*		\this.state==state;
      	*		\this.gui==gui;
      	*		\this.waitStartTime==waitStartTime;
      	*		\this.map==map;	
      	*		\this.lightmap==lightmap;
        */
		
		super(name,ID,gui,map,lightmap);
		if(ID>=0 && ID<=29) gui.SetTaxiType(ID,1);
		else gui.SetTaxiType(ID,0);
	}
	
	public TaxiSpecial(String name,int ID,TaxiGUI gui,Map map,int statein,Point point,int credit,LightMap lightmap){
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.ID;
      	*		\this.curx;
      	*		\this.cury;
      	*		\this.state;
      	*		\this.gui;
      	*		\this.waitStartTime;
      	*		\this.map;
      	*		\this.ghost;
      	*		\this.credit;
      	*		\this.lightmap;
        *@EFFECTS:
      	*		\this.ID==ID;
      	*		\this.curx==curx;
      	*		\this.cury==cury;
      	*		\this.state==state;
      	*		\this.gui==gui;
      	*		\this.waitStartTime==waitStartTime;
      	*		\this.map==map;
      	*		\this.credit==credit;
      	*		\this.lightmap==lightmap;
      	*		\this.ghost==1;
        */
		
	    super(name,ID,gui,map,statein,point,credit,lightmap);
	    if(ID>=0 && ID<=29) gui.SetTaxiType(ID,1);
		else gui.SetTaxiType(ID,0);
	}
	
	public synchronized Point randomCoordinate(int x,int y) {
		/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:
       	*		\this.curx;
      	*		\this.cury;
        *@EFFECTS:
       	*		对处于wait状态的出租车行驶方向进行选择
      	*		在所有连街边中选择流量最小的进行选择
       	*		若有多个流量最小的边，则随机选择	
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		int randindex,minflow=40000000,tempflow;
		int [][]mapCoord;
    	
    	if(getIDSon()>=0 && getIDSon()<=29) mapCoord=getMapSon().getMapInit();
    	else mapCoord=getMapSon().getMap();
		List <Integer> existDirection=new ArrayList <Integer>();
		if(mapCoord[x][y]==1 || mapCoord[x][y]==3) {//right
			tempflow=getMapSon().getflow(x,y,x,y+1);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.add(0);
			}
		}
		if(y-1>=0 && (mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3)) {//left
			tempflow=getMapSon().getflow(x,y,x,y-1);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(1);
			}
			else if(tempflow==minflow) existDirection.add(1);
		}
		if(x-1>=0 && (mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3)) {//up
			tempflow=getMapSon().getflow(x,y,x-1,y);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(2);
			}
			else if(tempflow==minflow) existDirection.add(2);
		}
		if((mapCoord[x][y]==2 || mapCoord[x][y]==3)) {//down
			tempflow=getMapSon().getflow(x,y,x+1,y);
			if(tempflow<minflow) {
				minflow=tempflow;
				existDirection.clear();
				existDirection.add(3);
			}
			else if(tempflow==minflow) existDirection.add(3);
		}
		
		Random rand=new Random();
		randindex=existDirection.get(rand.nextInt(existDirection.size()));
		existDirection.clear();
		
		if(randindex==0) return new Point(x,y+1);
		else if(randindex==1) return new Point(x,y-1);
		else if(randindex==2) return new Point(x-1,y);
		else return new Point(x+1,y);
	}

    
    public  void SPFA_2(int x,int y) {
    	/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:None;
        *@EFFECTS:
        *    find the shortest path of every node in map to (x,y);
        *    record the shortest path in ahead[][];
        */
    	
    	int [][] mapCoord;    	
    	if(getIDSon()>=0 && getIDSon()<=29) mapCoord=getMapSon().getMapInit();
    	else mapCoord=getMapSon().getMap();
    	
		getDistqueue_2().clear();
		for(int i=0;i<82;i++) {
			for(int j=0;j<82;j++) {
				getDist_2()[i][j]=infinite;
				getVisit_2()[i][j]=false;
				getFlow_2()[i][j]=infinite;
				getAhead()[i][j]=null;
			}
		}
		
		getDist_2()[x][y] = 0;
		getAhead()[x][y]=new Point(x,y);
		getVisit_2()[x][y]=true;
		getFlow_2()[x][y]=0;
		getDistqueue_2().offer(new Point(x,y));
		
		while (!getDistqueue_2().isEmpty()){
			int x1= (int)(getDistqueue_2().peek().getX());
			int y1= (int)(getDistqueue_2().poll().getY());
			getVisit_2()[x1][y1]=false;
			
			if(mapCoord[x1][y1]==1 || mapCoord[x1][y1]==3) {//right
				lax_2(x1,y1,x1,y1+1);
			}
			if(y1-1>=0 && (mapCoord[x1][y1-1]==1 || mapCoord[x1][y1-1]==3)) {//left
				lax_2(x1,y1,x1,y1-1);
			}
			if(x1-1>=0 && (mapCoord[x1-1][y1]==2 || mapCoord[x1-1][y1]==3)) {//up
				lax_2(x1,y1,x1-1,y1);
			}
			if((mapCoord[x1][y1]==2 || mapCoord[x1][y1]==3)) {//down
				lax_2(x1,y1,x1+1,y1);
			}
		}
    }
    
    
    public boolean waitpass(Point p,int x,int y) {
    	/**@REQUIRES:p!=null && 0<=x<=79 && 0<=y<=79;
    	*@MODIFIES:None;
    	*@EFFECTS:
    	*	\result==((x==x1 && y<y1) && (mapCoord[x][y]==1 || mapCoord[x][y]==3))||
     	*	((x==x1 && y>y1) && (mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3))||
     	*	((x<x1 && y==y1) && (mapCoord[x][y]==2 || mapCoord[x][y]==3))||
     	*	((x>x1 && y==y1) && (mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3));
    	*/
    	
    	int x1=(int)(p.getX()),y1=(int)(p.getY());
    	int [][]mapCoord;
    	
    	if(getIDSon()>=0 && getIDSon()<=29) mapCoord=getMapSon().getMapInit();
    	else mapCoord=getMapSon().getMap();
    	
    	if(getIDSon()>=0 && getIDSon()<=29) mapCoord=getMapSon().getMapInit();
    	else mapCoord=getMapSon().getMap();
    	
    	if(x==x1 && y<y1) {
    		if(mapCoord[x][y]==1 || mapCoord[x][y]==3) return true;
    		else return false;
    	}
    	else if(x==x1 && y>y1) {
    		if(mapCoord[x][y-1]==1 || mapCoord[x][y-1]==3) return true;
    		else return false;
    	}
    	else if(x<x1 && y==y1) {
    		if(mapCoord[x][y]==2 || mapCoord[x][y]==3) return true;
    		else return false;
    	}
    	else {
    		if(mapCoord[x-1][y]==2 || mapCoord[x-1][y]==3) return true;
    		else return false;
    	}
   
    }
    
    public void checkForward() throws IOException {
    	/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		顺序访问迭代器并输出信息;
        */
     	
    	
    	myIterator iter=getIterator();
    	try {
			this.out=new PrintWriter(new File("Car"+getIDSon()+".txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
   
    	while(iter.hasnext()) {
    		String str=iter.next();
    		print(str);
    	}
    	
    	System.out.println("The trace file is accomplished!");
    }
    
    public void checkBackward() throws IOException {
    	/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		逆序访问迭代器并输出信息;	
        */
     	
    	
    	myIterator iter=getIterator();
    	try {
			this.out=new PrintWriter(new File("Car"+getIDSon()+".txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	
    	
    	while(iter.hasprevious()) {
    		String str=iter.previous();
    		print(str);
    	}
    	
    	System.out.println("The trace file is accomplished!");
    }
    
    public myIterator getIterator() {
    	/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		\result==myIterator(this);	
        */
     	
    	
    	return new myIterator(this);
    }
    
    public void print(String path){
    	/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		print the history information of the car that is checked;	
        */
     	
    	
    	InputStream input;
    	String readstr;
    	 
		try {
			input = new FileInputStream(new File(path));
			InputStreamReader reader = new InputStreamReader(input);
			BufferedReader buff = new BufferedReader(reader);
	        
	        try {
				while((readstr=buff.readLine())!=null) {
					if(readstr.charAt(0)!='*') {
				    	out.println(readstr); 
						out.flush();
					}
				}
			} catch (IOException e) {
				System.out.println("Crash error!");
				e.printStackTrace();
			}
        
		} catch (FileNotFoundException e) {
			System.out.println("Crash error!");
			e.printStackTrace();
		}
        
        out.println("///////////////////////////////////////////////////////////");
        out.println("");
	    out.flush(); 
    }
    
    private static class myIterator implements Iterator{
    	/*Overview:迭代器类，提供可追踪出租车历史状态查询*/
    	
    	private List <String> RecordNow=new ArrayList <String> ();
    	private int n,m;
    	
    	public boolean repOK() {
            /** @REQUIRES:
            * @MODIFIES:None;
            * @EFFECTS:
            *      \result==!(RecordNow==null)&&
            *      !(n<0 || m>RecordNow.size() || m<0);
            */ 
          if(RecordNow==null) return false;
          if(n<0 || m>=RecordNow.size() || m<0) return false;
          
          return true;
                
       }
    	
    	public myIterator(Taxi taxi) {
    		/**@REQUIRES:taxi!=null;
    	    *@MODIFIES:
    	    *		\this.RecordNow;
    	    *		\this.n;
    	    *		\this.m;
    	    *@EFFECTS:
    	    *		\this.RecordNow==taxi.getRecord();
    	    *		\this.n==0;
    	    *		\this.m==RecordNow.size()-1;	
    	    */
    	    	
    		
    		this.RecordNow=taxi.getRecord();
    		this.n=0;
    		this.m=RecordNow.size()-1;
    	}
    	
    	public boolean hasnext() {
    		/**@REQUIRES:
    	    *@MODIFIES:None;
    	    *@EFFECTS:
    	    *		n<RecordNow.size()==>result==true;
    	    *		n>=RecordNow.size()==>\result==false;	
    	    */
    	    	
    		
    		return n<RecordNow.size();
    	}
    	
    	public boolean hasprevious() {
    		/**@REQUIRES:
    	    *@MODIFIES:None;
    	    *@EFFECTS:
    	    *		m>=0==>\result==true;
    	    *       m<0==>\result==false;	
    	    */
    	    	
    		
    		return m>=0;
    	}
    	
    	public String next() {
    		/**@REQUIRES:
    	    *@MODIFIES:None;
    	    *@EFFECTS:
    	    *		\result==RecordNow.get(n++);
    	    */
    	    	
    		
    		return RecordNow.get(n++);
    	}
    	
    	public String previous() {
    		/**@REQUIRES:
    	    *@MODIFIES:None;
    	    *@EFFECTS:
    	    *		\result==RecordNow.get(m--);	
    	    */
    	    	
    		
    		return RecordNow.get(m--);
    	}
    	
    }
    
}

	interface Iterator{
		public boolean hasnext();
		public boolean hasprevious();
		public String next();
		public String previous();
	}
