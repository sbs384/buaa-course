package taxi;

import java.util.ArrayList;
import java.util.List;
import java.awt.Point;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class ReqQueue {
	/* @Overview:ReqQueue类构造请求队列，根据调度器调度情况对请求进行删除  */
	
	private List <Request> queue=new ArrayList <Request>();
	private TaxiGUI gui;
	private int reqID=0;
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *       \result==!(gui!=null || queue==null ==>\result==false)&&
        *      !(\all int i,j;0<=i<queue.size();queue.get(i)==null)&&
        *      !(reqID<0 ==>\result=false);
        */ 
	  if(queue==null ||gui==null) return false;
	  for(int i=0;i<queue.size();i++) {
		 if(queue.get(i)==null) return false;
	  }
	 
	  if(reqID<0) return false;
	  
	  return true;        
   }
	
	public ReqQueue(TaxiGUI gui) {
		/**@REQUIRES:gui!=null;
        *@MODIFIES:
      	*		\this.gui;
        *@EFFECTS:
       	*		\this.gui==gui;			
        */
		
		this.gui=gui;
	}
	
	
	public synchronized void add(Request r) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.queue;
        *@EFFECTS:
      	*		!(r.depax()==r.destx() && r.depay()==r.desty()) && !queue.contains(r)==>queue.add(r); 	
      	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();			
        */
		try {
		if(!(r.depax()==r.destx() && r.depay()==r.desty())) {
			if(queue.size()==0) {
				queue.add(r); 
			    r.setID(reqID);
			    r.setOut(new File("log"+reqID+".txt"));
			    r.setPath("log"+reqID+".txt");
				//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().flush();
				++reqID;
				//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
			}
			else{
				if(!queue.contains(r)) {
					queue.add(r); 
					r.setID(reqID);
					r.setOut(new File("log"+reqID+".txt"));
					r.setPath("log"+reqID+".txt");
					//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().flush();
					++reqID;
					//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
				}
				else System.out.println("#SAME!Invalid input!");
			}
		}
		else System.out.println("#ERROR!Invalid input!");
		}catch(Exception e) {
			System.out.println("Crash error!");
			e.printStackTrace();
		}
	}
	
	
	public synchronized void delete(int i) {
		/**@REQUIRES:0<=i<queue.Len();
        *@MODIFIES:
      	*		\this.queue;
        *@EFFECTS:
      	*		queue.remove(i);	
      	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();			
        */
		
		queue.remove(i);
	}
	
	public synchronized void listAdd(int i,int j) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         *          0<=j<queue.get(i).carReady.Len();
         * @MODIFIES:
         * 			queue.get(i).carReady;
         * @EFFECTS:
         * 			queue.get(i).carReady.add(j);	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		queue.get(i).listAdd(j);
	}
	
	public synchronized int Len() {
		/** @REQUIRES:
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.size();	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.size();
	}
	
	public synchronized long time(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).time;		
         * * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();		
         */
		
		return queue.get(i).time();
	}
	
	public synchronized int depax(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).depax;	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.get(i).depax();
	}
	
	public synchronized int depay(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).depay;	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.get(i).depay();
	}
	
	public synchronized int destx(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).dextx;
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();				
         */
		
		return queue.get(i).destx();
	}
	
	public synchronized int desty(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).desty;	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.get(i).desty();
	}
	
	public synchronized List <Integer> list(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).list;	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.get(i).list();
	}
	
	public synchronized Request get(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i);	
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();		
         */
		
		return  queue.get(i);
	}
	
	public int reqID(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).reqID;
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();				
         */
		
		return  queue.get(i).reqID();
	}
	
	public PrintWriter out(int i) {
		/** @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result==queue.get(i).out;
         * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();			
         */
		
		return queue.get(i).out();
	}

}

