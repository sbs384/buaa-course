package taxi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.awt.Point;
import java.util.Random;

public class ArgsReader {
	/* @Overview:AsReader类可以对接口文件初始化 */
	
	private Map map;
	private Taxi [] taxiList;
	private TaxiGUI gui;
	private ReqQueue reqQueue;
	private LightMap lightmap;
	
	public boolean repOK() {
         /** @REQUIRES:
         * @MODIFIES:None;
         * @EFFECTS:
         *      \result==!(map==null || taxiList==null || gui==null || reqQueue==null || lightmap==null)&&
         *      !(\all int i,j;0<=i<100;taxiList[i]==null)&&
         *      !(\all int i;0<=i<reQueue.size();reqQueue.get(i)==null);
         */
       if(map==null) return false;
       if(taxiList==null) return false;
       for(int i=0;i<100;i++) {
    	   if(taxiList[i]==null) return false;
       }
       
       if(reqQueue==null) return false;
       for(int i=0;i<reqQueue.Len();i++) {
    	   if(reqQueue.get(i)==null) return false;
       }
       
       if(lightmap==null) return false;
       
       return true;
             
    }
	

	public ArgsReader(Map map,Taxi [] taxiList,TaxiGUI gui,ReqQueue reqQueue,LightMap lightmap) {
		/** @REQUIRES:map!=null && taxiList!=null && gui!=null && reqQueue!=null && lightmap!=null;
        *@MODIFIES:
        *	\this.map;
        *	\this.taxiList;
        *	\this.gui;
        *	\this.reqQueue;
        *	\this.lightmap;
        *@EFFECTS:
   		*	\this.map==map;
		*	\this.taxiList==taxiList;
		*	\this.gui==gui;
		*	\this.reqQueue==reqQueue;
		*	\this.lightmap==lightmap;		
        */
		
		this.map=map;
		this.taxiList=taxiList;
		this.gui=gui;
		this.reqQueue=reqQueue;
		this.lightmap=lightmap;
	}
	
	public void read(String s,Controller controller,UpdateFlow upf,UpdateLight upl) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.map;
       	*		\this.taxiList;
       	*		\this.reqQueue;
        *@EFFECTS:
       	*		读取file.txt文件
       	*		#map与end_map之间如果有合法文件则重新加载map
       	*		#flow与#end_flow之间如果有合法流量设置，则在相应边加载流量
        *       #taxi与end_taxi之间若有出租车状态设置，则设置相应出租车状态
        *       #request与end_request之间若有请求，则响应相应请求				
        */
		
		
		String str;
		short value;
		int i,x1,y1,x2,y2,id,state,credit;
		int [] ID=new int [100];
		for(i=0;i<100;i++) ID[i]=0;
		
		
		if(!new File(s).exists()) {
			System.out.println("Can't find the test file!");
			System.exit(1);
		}
		
		if(!new File(s).isFile()) {
			System.out.println("Can't find the test file!");
			System.exit(1);
		}
		
		InputStream input = new FileInputStream(new File(s));
        InputStreamReader reader = new InputStreamReader(input);
        BufferedReader buff = new BufferedReader(reader);
        
        try {
        	while((str=buff.readLine())!=null) {
        		if(str.equals("#map")) {
        			str=buff.readLine();
        			if(!str.equals("#end_map")) {
        				if(!map.readfile(str)) {
        					System.out.println("Invalid map of file.txt!");
        					System.exit(1);
        				};
        				gui.LoadMap(map.getMap(),80);
        				map.setMapInit(map.getMap());
        			}
        			else{
        				gui.LoadMap(map.getMap(),80);
        				map.setMapInit(map.getMap());
        			}
        		}
        		
        		else if(str.equals("#light")) {
        			str=buff.readLine();
        			if(!str.equals("#end_light")) {
        				if(!lightmap.readfile(str,new Random().nextInt(2))) {
        					System.out.println("Invalid file for light!");
        					System.exit(1);
        				};
        			}
        			else {
        				System.out.println("There's no legal file for light!");
        				System.exit(1);
        			}
        		}
        		
        		else if(str.equals("#flow")) {
        			while(!(str=buff.readLine()).equals("#end_flow")) {
        				if(!str.matches("^\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\) \\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\) [0-9]{1,3}$")) error();
        				String string[]=str.split(" ");
        				String string1[]=string[0].split(",");
        				x1=Integer.parseInt(string1[0].replaceAll("\\(", ""));
        				y1=Integer.parseInt(string1[1].replaceAll("\\)", ""));
        				
        				String string2[]=string[1].split(",");
        				x2=Integer.parseInt(string2[0].replaceAll("\\(", ""));
        				//System.out.println(string2[1]);
        				y2=Integer.parseInt(string2[1].replaceAll("\\)", ""));
        				
        				value=(short)(Integer.parseInt(string[2]));
        				if(value>1000) error();
        				
        				map.setflow(x1,y1,x2,y2,value);
        			}
        		}
        		
        		else if(str.equals("#taxi")) {
        			while(!(str=buff.readLine()).equals("#end_taxi")) {
        				if(!str.matches("^[0-9]{1,2} [0-9] [0-9]{1,3} \\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)$")) error();
        				String string[]=str.split(" ");
        				id=Integer.parseInt(string[0]);
        				if(id>99) error();
        				state=Integer.parseInt(string[1]);
        				if(state!=0 && state!=1 && state!=2 && state!=3) error();
        				credit=Integer.parseInt(string[2]);
        				if(credit>1000) error();
        				
        				String string1[]=string[3].split(",");
        				x1=Integer.parseInt(string1[0].replaceAll("\\(", ""));
        				y1=Integer.parseInt(string1[1].replaceAll("\\)", ""));
        				
        				ID[id]=1;
        				if(id>=0 && id<=29) taxiList[id]=new TaxiSpecial("taxi"+id,id,gui,map,state,new Point(x1,y1),credit,lightmap);
        				else taxiList[id]=new Taxi("taxi"+id,id,gui,map,state,new Point(x1,y1),credit,lightmap);
        				Thread t=new Thread(taxiList[id]);
        				t.setUncaughtExceptionHandler(new ExceptionHandler());
        				t.start();
        			}
        			
        			for(int k=0;k<100;k++) {
        				if(ID[k]!=1) {
        					//System.out.println(k+";"+ID[k]);
        					if(k>=0 && k<=29) taxiList[k]=new TaxiSpecial("taxi"+k,k,gui,map,lightmap);
            				else taxiList[k]=new Taxi("taxi"+k,k,gui,map,lightmap);
        					Thread t=new Thread(taxiList[k]);
            				t.setUncaughtExceptionHandler(new ExceptionHandler());
            				t.start();
        				}
        			}
        			
        			
        			controller.start();
            		upf.start();
            		upl.start();
        		}
        		
        		
        		else if(str.equals("#request")) {
        			while(!(str=buff.readLine()).equals("#end_request")) {
        				if(!str.matches("^\\[CR,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$")) error();
        				long time=System.currentTimeMillis();
        				time=time/100*100;
        				try {
    						reqQueue.add(new Request(str,time));
    					} catch (FileNotFoundException e) {
    						System.out.println("Crash error!");
    						e.printStackTrace();
    					}
        			}
  
        		}
        	}
        	
        }catch(Exception e) {
        	System.out.println("Crash error!");
        	e.printStackTrace();
        }
	}
	
	public void error() {
		 /** @REQUIRES:
         * @MODIFIES:None;
         * @EFFECTS:
         *     System.out.println("Invalid file content!");
		 *	   System.exit(1);
         */
		
		System.out.println("Invalid file content!");
		System.exit(1);
	}
}


