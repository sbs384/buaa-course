public class Request{
	
	private int ask;
    private int floor;
    private double T;
    private int elevator=0;
	
    //构造方法
	public Request(String s,double T){
		String regex=",";
		String [] str=s.split(regex);
		
		if(str[0].charAt(1)=='E') {
			this.ask=1;
			this.T=T;
			
			if(str[1].charAt(1)=='1') this.elevator=1;
			else if(str[1].charAt(1)=='2') this.elevator=2;
			else if(str[1].charAt(1)=='3') this.elevator=3;
			
			String regexSp="\\)";
			String number=str[2].replaceAll(regexSp,"");
			this.floor=Integer.parseInt(number);
		}
		
		else {
			this.floor=Integer.parseInt(str[1]);
			this.T=T;
			
			if(str[2].charAt(0)=='U') this.ask=2;
			else this.ask=3;
		
		}
		
	}

	//Setter和Getter方法
	public int ask() {
		return ask;
	}
	
	public int floor() {
		return floor;
	}

	public double T() {
		return T;
	}
	
	public int elevator() {
		return elevator;
	}
	
	//重写方法
	@Override
	public boolean equals(Object obj) {
		if(this==obj) return true;
		if(obj==null) return false;
		if(!(obj instanceof Request)) return false;
		Request request=(Request)obj;
		if(this.floor==request.floor) {
			if(this.ask==request.ask && this.elevator==request.elevator) return true;
			else return false;
		}
		else return false;
	  }
	
	
}