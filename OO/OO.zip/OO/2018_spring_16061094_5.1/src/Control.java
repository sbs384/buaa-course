import java.util.List;
import java.util.ArrayList;
import java.io.*;

public class Control extends Controller implements Runnable {
	private List <Request> queueC=new ArrayList <Request>();
	private RequestSimulator reqSimu;
	private ESharePass e1SharePass;
	private ESharePass e2SharePass;
	private ESharePass e3SharePass;
	private Tray tray;
	private Elevator e1;
	private Elevator e2;
	private Elevator e3;
	private PrintWriter out;
	volatile private boolean stopMe=true;
	

	public Control(RequestSimulator reqSimu,Tray tray,Elevator e1,Elevator e2,Elevator e3,ESharePass e1SharePass,ESharePass e2SharePass,ESharePass e3SharePass,PrintWriter out) {
		this.tray=tray;
		this.e1=e1;
		this.e2=e2;
		this.e3=e3;
		this.e1SharePass=e1SharePass; 
		this.e2SharePass=e2SharePass;
		this.e3SharePass=e3SharePass;
		this.reqSimu=reqSimu;	
		this.out=out;
	}
	
	public void run() {
		int i,last=0;
		
		while(stopMe) {
			synchronized(tray) {	 			
				for(i=0;i<tray.Len();) {
					//if(tray.Len()==0) System.out.println(true);
					//else System.out.println(false);
					Request r=tray.curReq(0);
					queueC.add(r);
					tray.delete(r);
				}
			}
			
			
			for(i=0;i<queueC.size();) {
				if(e1.state()==0 || e2.state()==0 || e3.state()==0) i=0;
				//System.out.println("queuCsize:"+queueC.size());
				Request r=queueC.get(i);
				//System.out.println("Control.40:当前control扫描的请求为： ask:"+r.ask()+" "+"floor:"+r.floor()+" "+"T:"+r.T()+" "+"elevator:"+r.elevator());
				if(i==queueC.size()-1) last=1;
				else last=0;
				i=schedule(r,i);
				try {
				Thread.sleep(10);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//System.out.println(i);
				//System.out.println(queueC.size());
				if(last==1) break;
			}
			
			if(reqSimu.stopAlready() && tray.Len()==0 && queueC.size()==0) {
				stopMe();
				e1.ControlStop(true);
				e2.ControlStop(true);
				e3.ControlStop(true);
			}
	     }
		Thread.yield();
	     
	}
	
	public int schedule(Request r,int i) {
		
		if(sameJudge(r)) {
			//System.out.println("same:"+true);
			if(r.ask()==1) out.println("#"+System.currentTimeMillis()+":SAME[ER,#"+r.elevator()+","+r.floor()+","+r.T()+"]");
			else if(r.ask()==2) out.println("#"+System.currentTimeMillis()+":SAME[FR,"+r.floor()+","+"UP"+","+r.T()+"]");
			else out.println("#"+System.currentTimeMillis()+":SAME[FR,"+r.floor()+","+"DOWN"+","+r.T()+"]");
		    out.flush();
			queueC.remove(r);
			return i;
		}
		else{
			//System.out.println("same:"+false);
			if(respond(r)) {
				//System.out.println("respond:"+true);
				//System.out.println("ask:"+r.ask()+"floor:"+r.floor());
				queueC.remove(r);
				//if(tray.Len()!=0) System.out.println(tray.curReq(0).ask());
				//System.out.println("Control.73:queueC.size:"+queueC.size());
				return i;
			}
			else{
				//System.out.println("respond:"+false);
				//System.out.println("ask:"+r.ask()+"floor:"+r.floor());
				++i;
				return i;
			}
		}
		
	}
	
	public boolean sameJudge(Request r) {
		if(r.ask()==1) {
			if(r.elevator()==1 && e1.contain(r)) 		return true;
			else if(r.elevator()==2 && e2.contain(r) ) {
				//System.out.println("Control.146:2号电梯找到了同质");
				/*for(i=0;i<e2.Len();i++) {
					System.out.println("ask:"+e2.curReq(i).ask()+"floor:"+e2.curReq(i).floor());
				}
				*/
				//if(e2.Len()==0) System.out.println(true);
				//else System.out.println(false);
				return true;
			}
			else if(r.elevator()==3 && e3.contain(r)) 	return true;
			else return false;
		}
		
		else {
			if(e1.contain(r) || e2.contain(r) || e3.contain(r)) return true;
			else return false;
		}
	}
	
	public boolean respond(Request r) {
		
		if(r.ask()==1) {
			if(r.elevator()==1) {
				if(elevatorPass(r,e1)) {
					return true;
				}
				else{
					//System.out.println("e1_ER不可响应："+false);
					return false;
				}
			}
			else if(r.elevator()==2) {
				if(elevatorPass(r,e2)) 	return true;
				else return false;
			}
			else {
				if(elevatorPass(r,e3)) 	return true;
				else return false;
			}
		}
		
		else if(r.ask()==2) {
			if(floorPass(r,2)) return true;
			else return false;
		}
		
		else {
			if(floorPass(r,3)) return true;
			else return false;
		}
	}
	
	public boolean elevatorPass(Request r,Elevator e) {
		//System.out.println("e"+e.who()+".state:"+e.state());
		//System.out.println("e"+e.who()+".curFloor:"+e.curfloor());
		if((e.state()==1 && r.floor()>e.curfloor()) || (e.state()==2 && r.floor()<e.curfloor()) || (e.state()==0)) {
			//System.out.println("e1_ER可响应："+true);	
			//System.out.println("r.floor:"+r.floor()+"  r.ask:"+r.ask());
			//System.out.println("e"+e.who()+".state:"+e.state());
			//System.out.println("e"+e.who()+".curFloor:"+e.curfloor());
			//e.add(r);
			if(e.who()==1) {
				synchronized(e1SharePass) {
					if(e1.Len()==0) {
						e1.add(r);
						e1SharePass.delete(r);
					}
					else e1SharePass.put(r);
				}
			}
			
			else if(e.who()==2) {
				synchronized(e2SharePass) {
					if(e2.Len()==0) {
						e2.add(r);
						e2SharePass.delete(r);
					}
					else e2SharePass.put(r);
				}
			}
			
			else{
				synchronized(e3SharePass) {
					if(e3.Len()==0) {
						e3.add(r);
						e3SharePass.delete(r);
					}
					else e3SharePass.put(r);
				}
			}
			return true;
		}
		else return false;
		
	}
	
	public boolean floorPass(Request r,int ask) {
		int [] a=new int [3];
		int [] b=new int [3];
		int sportPass=4000000,sportStill=4000000,pass=0,still=0,i,ele;
		if(ask==2) {
			//电梯状态判断
			//System.out.println(r.floor());
			if(e1.state()==1 && e1.curfloor()<r.floor() && r.floor()<=e1.Destfloor()){
				a[0]=1;
				b[0]=e1.sport();
			}
			else if(e1.state()==0) {
				a[0]=2;
				b[0]=e1.sport();
			}
			//else System.out.println("e1.state=-1");
			
			if(e2.state()==1 && e2.curfloor()<r.floor()  && r.floor()<=e2.Destfloor()) {
				a[1]=1;
				b[1]=e2.sport();
			}
			else if(e2.state()==0) {
				System.out.println("e1.state=0");
				System.out.println("r.floor:"+r.floor()+"  r.ask:"+r.ask());
				a[1]=2;
				b[1]=e2.sport();
			}
			
			if(e3.state()==1 && e3.curfloor()<r.floor()  && r.floor()<=e3.Destfloor()) {
				a[2]=1;
				b[2]=e3.sport();
			}
			else if(e3.state()==0) {
				//System.out.println("e1.state=0");
				//System.out.println("r.floor:"+r.floor()+"  r.ask:"+r.ask());
				a[2]=2;
				b[2]=e3.sport();
			}
		}
		
		else {
			//电梯状态判断
			if(e1.state()==2 && e1.curfloor()>r.floor()  && r.floor()>=e1.Destfloor()){
				a[0]=1;
				b[0]=e1.sport();
			}
			else if(e1.state()==0) {
				a[0]=2;
				b[0]=e1.sport();
			}
			
			
			if(e2.state()==2 && e2.curfloor()>r.floor()  && r.floor()>=e2.Destfloor()) {
				a[1]=1;
				b[1]=e2.sport();
			}
			else if(e2.state()==0) {
				a[1]=2;
				b[1]=e2.sport();
			}
			
			if(e3.state()==2 && e3.curfloor()>r.floor()  && r.floor()>=e3.Destfloor()) {
				a[2]=1;
				b[2]=e3.sport();
			}
			else if(e3.state()==0) {
				a[2]=2;
				b[2]=e3.sport();
			}
		}
			
		//System.out.println("r.floor:"+r.floor());
		//求得最小运动量的电梯
		for(i=0;i<3;i++) {
			if(a[i]==1) {
				if(b[i]<sportPass) {
					sportPass=b[i];
					pass=i;
				}
				//System.out.println(a[i]);
				a[i]=0;
				b[i]=0;
			}
				
			else if(a[i]==2) {
				if(b[i]<sportStill) {
					sportStill=b[i];
					still=i;
				}
				//System.out.println(a[i]);
				a[i]=0;
				b[i]=0;
			}
			//else System.out.println(a[i]);
			
		}
			
			
		//向电梯发送指令并返回响应结果
		if(sportPass!=4000000 || sportStill!=4000000) {
			if(sportPass!=4000000) ele=pass;
			else ele=still;
			
			sportPass=4000000;
			sportStill=4000000;
				
			if(ele==0) {
				synchronized(e1SharePass) {
					if(e1.Len()==0) {
						e1.add(r);
						e1SharePass.delete(r);
					}
					else e1SharePass.put(r);
				}
				return true;
			}
			else if(ele==1) {
				synchronized(e2SharePass) {
					if(e2.Len()==0) {
						e2.add(r);
						e2SharePass.delete(r);
					}
					else e2SharePass.put(r);
				}
				return true;
			}
			else {
				synchronized(e3SharePass) {
					if(e3.Len()==0) {
						e3.add(r);
						e3SharePass.delete(r);
					}
					else e3SharePass.put(r);
				}
				return true;
			}
				
		}
			
		else return false; 
				
	}	
	
	public void stopMe() {
		stopMe=false;
	}
	
	public boolean stopAlready() {
		return stopMe;
	}

}
