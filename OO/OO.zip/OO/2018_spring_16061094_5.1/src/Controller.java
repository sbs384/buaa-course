import java.util.ArrayList;
import java.util.List;

public class Controller extends ControllerFather {
	 private boolean sameJudge;
     private boolean respond;
     private double time;
	 private List <Request> queueC=new ArrayList <Request>();
	 public int schedule(Request r,int i) {
		if(sameJudge) {
			queueC.remove(r);
			System.out.print("#SAME");
			if(r.ask()==1)        System.out.println("["+"FR"+","+r.floor()+","+"UP"+","+time+"]");
			else if(r.ask()==2)   System.out.println("["+"FR"+","+r.floor()+","+"DOWN"+","+time+"]");
			else                  System.out.println("["+"ER"+","+r.floor()+","+time+"]");
			return i;
		}
		else{
			//System.out.println("same:"+false);
			if(respond) {
				queueC.remove(r);
				return i;
			}
			else{
				++i;
				return i;
			}
		}
	}

}
