import java.util.Scanner;
import java.io.*;

public class RequestSimulator extends Thread {
	private PrintWriter out;
	private Tray tray;
	volatile private boolean stopAlready=false;
	
	public RequestSimulator(String name,Tray tray,PrintWriter out) {
		super(name);
		this.tray=tray;
		this.out=out;
	}
	
	public void run() {
		int inputNum=0;
		long time,initialTime=0,flag=0;
		double T;
		
		
		Scanner keyboard=new Scanner(System.in);
		String input=keyboard.nextLine();
		System.out.println(time=System.currentTimeMillis());
		++inputNum;
		
		if(input.equals("END")) {
			out.println("#ERROR");
			out.println("#No request!Please run again!");
			System.exit(1);
		}
		
		
		while(!input.equals("END")) {
			if(flag==0) {
				T=0.0;
				initialTime=time;
				flag=1;
				//System.out.println("RequestSimu.47:initialTime:"+System.currentTimeMillis());
			}
			else{
				T=(double)((time-initialTime)/1000.0);
				T=(double)Math.round(T*10)/10;
			}
			
			String inputOp=opStr(input);
			judgeInput(inputOp,T);
			
			
			input=keyboard.nextLine();
			System.out.println(time=System.currentTimeMillis());
			++inputNum;
			if(!input.equals("END") && inputNum==51) {
				out.println("#ERROR");
				out.println("#The line of request is more than 50!");
				break;
			}
		}
		
		stopAlready=true;
		keyboard.close();
		yield();
	}
	
	
	//去除空格
	public String opStr(String s) {
		String regexSp="\\s+";
		String strOp=s.replaceAll(regexSp,"");
		if(s.equals("")) strOp=';'+strOp;
		else{
			if(s.charAt(0)!=';') strOp=';'+strOp;
		}
		return strOp;
	}
	
		 
	//格式匹配
	public void judgeInput(String s,double T) {
		int i,InvalidLength=0;
		String regex=";";
		String [] strRequest=s.split(regex); 
		
		String regex1="^\\(FR,([1-9]|(1[0-9])),UP\\)$";
		String regex2="^\\(FR,([2-9]|(1[0-9])|20),DOWN\\)$";
		String regex3="^\\(ER,#(1|2|3),([1-9]|(1[0-9])|20)\\)$";
		

		for(i=1;i<=strRequest.length-1;i++) {
			if(i==11) {
				out.println(System.currentTimeMillis()+":INVALID"+"["+s.substring(InvalidLength)+","+T+"]");
				out.flush();
				break;
			}
			else {
				if(strRequest[i].matches(regex1) || strRequest[i].matches(regex2) || strRequest[i].matches(regex3)) structRequest(strRequest[i],T);
				else {
					out.println(System.currentTimeMillis()+":INVALID"+"["+strRequest[i]+","+T+"]");
				    out.flush();
				}
				InvalidLength=InvalidLength+strRequest[i].length()+1;
			}
			
 		}
		
		if(strRequest.length==0) {
			out.println(System.currentTimeMillis()+":INVALID"+"[,"+T+"]");
			out.flush();
		}
		
	} 
	
	public void structRequest(String s,double T) {
		Request request=new Request(s,T);
		synchronized(tray) {
			tray.put(request);
		}
	}
	
	public boolean stopAlready() {
		return stopAlready;
	}
}

