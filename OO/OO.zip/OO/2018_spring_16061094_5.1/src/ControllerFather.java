import java.util.ArrayList;
import java.util.List;

public class ControllerFather {
        private boolean sameJudge;
        private boolean respond;
	    private List <Request> queueC=new ArrayList <Request>();
		public int schedule(Request r,int i) {
			if(sameJudge) {
				queueC.remove(r);
				return i;
			}
			else{
				//System.out.println("same:"+false);
				if(respond) {
					queueC.remove(r);
					return i;
				}
				else{
					++i;
					return i;
				}
			}
		}
	
}
