import java.io.*;

public class Main{
	public static void main(String[] args) throws FileNotFoundException {
		 File file=new File("result.txt"); 
		 PrintWriter out =new PrintWriter(file);
		
		
		 Tray tray=new Tray();
		 ESharePass e1SharePass=new ESharePass(); 
		 ESharePass e2SharePass=new ESharePass();
		 ESharePass e3SharePass=new ESharePass();
		 
		 
	     RequestSimulator requestSimu=new RequestSimulator("request",tray,out);
	     Elevator e1=new Elevator("e1",1,e1SharePass,out);
	     Elevator e2=new Elevator("e2",2,e2SharePass,out);
	     Elevator e3=new Elevator("e3",3,e3SharePass,out);
	     Control controlRunnable=new Control(requestSimu,tray,e1,e2,e3,e1SharePass,e2SharePass,e3SharePass,out);
	     Thread control=new Thread(controlRunnable);
	     
	     e1.start();
	     e2.start();
	     e3.start();
	     requestSimu.start();
	     control.start();
	     
	     try {
			e1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	     try {
			e2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	     try {
				e3.join();
		} catch (InterruptedException e) {
				e.printStackTrace();
		}
	     
	     try {
				requestSimu.join();
		} catch (InterruptedException e) {
				e.printStackTrace();
		}
	     
	     try {
				control.join();
		} catch (InterruptedException e) {
				e.printStackTrace();
		}
	     
	    
	    System.out.println("#END");
	}
}