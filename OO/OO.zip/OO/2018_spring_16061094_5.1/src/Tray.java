import java.util.List;
import java.util.ArrayList;
 
public class Tray {
     private List <Request> queue=new ArrayList <Request>();
     private boolean flag=true;
     
     public void put(Request r) {
    	 queue.add(r);
    	 Request rtest=queue.get(queue.size()-1);
    	 //System.out.println("Tray.11:托盘尾部元素:ask:"+rtest.ask()+" "+"floor:"+rtest.floor()+" "+"T:"+rtest.T()+" "+"elevator"+rtest.elevator());
     }
     
     //反馈队列长度
     public int Len() {
       	 return queue.size();
     }
      
     //反馈当前请求   
     public Request curReq(int i) {
    	 Request r=(Request)queue.get(i);
    	 return r;
     }
     
     public void delete(Request r) {
    	 queue.remove(r);
     }
     
     public boolean flag() {
    	 return  flag;
     }
     
     public void setflag(boolean t) {
    	 flag=t;
     }
     
     public List<Request> get() {
    	 return queue;
     }
    
}

