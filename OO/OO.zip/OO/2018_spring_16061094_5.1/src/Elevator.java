import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class Elevator extends Thread {
	private  List <Request> queuePass=new ArrayList <Request>();
	private  ESharePass eSharePass;
    volatile private int curFloor=1;
    volatile private int state=0;//state:-1主请求开关门;0空闲;1UP:2DOWN
    volatile private int sport=0;
    volatile private  int DestFloor;
    private  int dir=0;//dir:0STILL;1UP;2DOWN
    private  double curTime=0;
    private  int who;
    private  boolean stopMe=true;
    volatile private  boolean ControlStop=false;
    private  PrintWriter out;
   
    public Elevator(String name,int who,ESharePass eSharePass,PrintWriter out) {
    	super(name);
    	this.who=who;  
    	this.eSharePass=eSharePass;
    	this.out=out;
    }
    
    public void run() {
    	String s=new String();
    	double outTime;
    	int i;
    	
        while(stopMe) {
        	synchronized(eSharePass) {	 			
				for(i=0;i<eSharePass.Len();) {
					Request r=eSharePass.curReq(0);
					add(r);
					eSharePass.delete(r);
				}
			}
        	
    		while(queuePass.size()!=0) {
    			//System.out.println("Elevator.37:whilequeueSize.size:"+queuePass.size());
    			if(dir==1 || dir==2) {
    				if(dir==1)  s="UP";
    				else        s="DOWN";
    				
    				//state=dir;
    				try {
						sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				if(dir==1) 		++curFloor;
    				else if(dir==2) --curFloor;
    					
    				++sport;
    				curTime+=3;
    				
    				synchronized(eSharePass) {	 			
    					for(i=0;i<eSharePass.Len();) {
    						Request r=eSharePass.curReq(0);
    						add(r);
    						eSharePass.delete(r);
    					}
    				}
    				
    				Request r=queuePass.get(0);
    				if(curFloor==r.floor()) {
    					if(r.floor()!=DestFloor) {
    						outTime=(double)Math.round(curTime*10)/10;
    						if(r.ask()==1) out.println(System.currentTimeMillis()+":[ER,#"+r.elevator()+","+r.floor()+","+r.T()+"]/"+"(#"+r.elevator()+","+r.floor()+","+s+","+sport+","+outTime+")");
    						else if(r.ask()==2) out.println(System.currentTimeMillis()+":[FR,"+r.floor()+","+"UP"+","+r.T()+"]/"+"(#"+who+","+r.floor()+","+s+","+sport+","+outTime+")");
    						else out.println(System.currentTimeMillis()+":[FR,"+r.floor()+","+"DOWN"+","+r.T()+"]/"+"(#"+who+","+r.floor()+","+s+","+sport+","+outTime+")");
    						out.flush();
    						queuePass.remove(r);
    					}
    					else{ 
    						state=-1;
    						outTime=(double)Math.round(curTime*10)/10;
    						for(;queuePass.size()!=0;) {
    							if(queuePass.get(0).floor()!=DestFloor) break;
    							Request r1=queuePass.get(0);
        						if(r1.ask()==1) out.println(System.currentTimeMillis()+":[ER,#"+r1.elevator()+","+r1.floor()+","+r1.T()+"]/"+"(#"+r1.elevator()+","+r1.floor()+","+s+","+sport+","+outTime+")");
        						else if(r1.ask()==2) out.println(System.currentTimeMillis()+":[FR,"+r1.floor()+","+"UP"+","+r1.T()+"]/"+"(#"+who+","+r1.floor()+","+s+","+sport+","+outTime+")");
        						else out.println(System.currentTimeMillis()+":[FR,"+r1.floor()+","+"DOWN"+","+r1.T()+"]/"+"(#"+who+","+r1.floor()+","+s+","+sport+","+outTime+")");
        						out.flush();
        						queuePass.remove(r1);
    						}
    					}
    					
    					
    					
    					try {
    						sleep(6000);
    					} catch (InterruptedException e) {
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}
    					if(state==-1) {
    						if(queuePass.size()!=0){
    							DestFloor=queuePass.get(queuePass.size()-1).floor();
    							state=dir;
    						}
    						else state=0;
    					}
    					
    					curTime+=6;
    					}
    				}
    			
    			else if(dir==0) {
    				state=-1;
    				try {
						sleep(6000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				curTime+=6;
    				
    				Request r=queuePass.get(0);
    				outTime=(double)Math.round(curTime*10)/10;
					if(r.ask()==1) out.println(System.currentTimeMillis()+":[ER,#"+r.elevator()+","+r.floor()+","+r.T()+"]/"+"(#"+r.elevator()+","+r.floor()+","+"STILL"+","+sport+","+outTime+")");
					else if(r.ask()==2) out.println(System.currentTimeMillis()+":[FR,"+r.floor()+","+"UP"+","+r.T()+"]/"+"(#"+who+","+r.floor()+","+"STILL"+","+sport+","+outTime+")");
					else out.println(System.currentTimeMillis()+":[FR,"+r.floor()+","+"DOWN"+","+r.T()+"]/"+"(#"+who+","+r.floor()+","+"STILL"+","+sport+","+outTime+")");
					out.flush();
					
					state=0;
					queuePass.remove(r);
					
					synchronized(eSharePass) {	 			
    					for(i=0;i<eSharePass.Len();) {
    						Request r1=eSharePass.curReq(0);
    						add(r1);
    						eSharePass.delete(r);
    					}
    				}
    				
    			}
    		}
    		
    		if(ControlStop && eSharePass.Len()==0 && queuePass.size()==0) stopMe();
    	}
    	
    }
    
    
    public boolean contain(Request r) {
    	if(queuePass.contains(r) || eSharePass.contain(r)) return true;
    	else return false;
    }
    
    
    public void add(Request r) {
        int i;
    	if(queuePass.size()==0) {
    		//设置主请求参数
    		this.DestFloor=r.floor();
    		if(r.floor()==curFloor) {
    			state=-1;
    			dir=0;
    		}
    		else if(r.floor()>curFloor) {
    			dir=1;
    			state=1;
    		}
    		else {
    			state=2;
    			dir=2;
    		}
    		
    		if(r.T()>curTime) curTime=r.T();

    		queuePass.add(r);
    		//System.out.println("Elevator.123:构造捎带队列的主请求： ask:"+r.ask()+" "+"floor:"+r.floor()+" "+"T:"+r.T()+" "+"elevator:"+r.elevator());
    		//System.out.println("Elevator.124:addqueueSize:"+queuePass.size());
    	}
    	
    	else {
    		if(state==1) {
    			for(i=0;i<queuePass.size();i++) {
    				Request rcp=queuePass.get(i);
    				if(rcp.floor()>r.floor()) {
    					queuePass.add(i,r);
    					break;
    				}
    			}
    			
    			if(i==queuePass.size()) queuePass.add(r);
    		}
    			
    		else if(state==2) {
    			for(i=0;i<queuePass.size();i++) {
    				Request rcp=queuePass.get(i);
    				if(rcp.floor()<r.floor()) {
    					queuePass.add(i,r);
    					break;
    				}
    			}
    			
    			if(i==queuePass.size()) queuePass.add(r);
    		}
    		
    	}
    }
    
    
    
    //设置属性和返回值的方法
    public int sport() {
    	return sport;
    }
    
    public int state() {
    	return state;
    }
    
    public int curfloor() {
    	return curFloor;
    }
  
    public int who() {
    	return who;
    }
    
    public int Destfloor() {
    	return DestFloor;
    }
    
    public void stopMe() {
    	stopMe=false;
    }
    
    public void ControlStop(boolean ControlStop) {
    	this.ControlStop=ControlStop;
    }
    
    public void setState(Request r) {
		if(r.floor()==curFloor)  state=-1;
		else if(r.floor()>curFloor) state=1;
		else  state=2;
    }
    
    public int queueSize() {
    	return queuePass.size();
    }
  
    
    public Request curReq(int i) {
    	return queuePass.get(i);
    }
    
    public int Len() {
    	return queuePass.size();
    }
    
    
   
}
