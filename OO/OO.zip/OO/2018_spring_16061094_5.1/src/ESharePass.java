
import java.util.ArrayList;
import java.util.List;

public class ESharePass {
	volatile private List <Request> eSharePass=new ArrayList <Request>();
	volatile private boolean empty=true;
	
	public Request curReq(int i) {
		return eSharePass.get(i);
	}
	
	public void put(Request r) {
		eSharePass.add(r);
	}
	
	public void delete(Request r) {
		eSharePass.remove(r);
	}
	
	public int Len() {
		return eSharePass.size();
	}
	
	public boolean contain(Request r) {
		if(eSharePass.contains(r)) return true;
		else return false;
	}
	
	public boolean empty() {
		return empty;
	}
	
	public void setEmpty(boolean empty) {
		this.empty=empty;
	}
}