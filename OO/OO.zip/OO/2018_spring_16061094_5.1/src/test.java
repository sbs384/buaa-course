import java.math.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class test   {
	
	 public void run() {
		 int row;
		 String number="1 2";
		 String regexSp="\\s+";
		 String str=number.replaceAll(regexSp,"");
		 System.out.println(row=Integer.parseInt(str));
			 
	 }
	
	 public static void main(String[] args) {
	 /*DecimalFormat df = new DecimalFormat("0.0");
     double d1 = 3.26556;
     double d2=0.0;
     System.out.println(df.format(d1));
     System.out.println(d2);*/
     //test t=new test();
     //t.start();
		 Scanner keyboard=new Scanner(System.in);
			String input=keyboard.nextLine();
			
			System.out.println(true);
	
	 }
}