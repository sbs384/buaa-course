package smartElevator;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
//import org.junit.contrib.java.lang.system.SystemOutRule;


public class ControllerTest {
	private Controller controller;
	PrintStream console=null;
	ByteArrayOutputStream bytes=null;
	
	@Before
	public void before() {
		controller=new Controller();
		
	}
	
	@After
	public void after() {
		controller=null;
		
	}
	
	//@Rule
	//public final SystemOutRule log = new SystemOutRule().enableLog();

	@Test
	public void testRepOK() {
		assertEquals(true,controller.repOK());
	}
	
	@Test
	public void testDeal() {
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		Elevator ele=new Elevator();
		QueueReq queue=new QueueReq();
		queue.manage(new Request("(FR,1,UP,0)"));
		queue.manage(new Request("(ER,3,0)"));
		queue.manage(new Request("(ER,2,0)"));
		queue.manage(new Request("(ER,2,0)"));
		controller.deal(queue,ele);
		//assertEquals("[FR,1,UP,0]/(1,STILL,1.0)\r\n[ER,2,0]/(2,UP,1.5)\r\n[ER,3,0]/(3,UP,3.0)\r\n#SAME[ER,2,0]\r\n",log.getLog());
		assertEquals("[FR,1,UP,0]/(1,STILL,1.0)\r\n[ER,2,0]/(2,UP,1.5)\r\n[ER,3,0]/(3,UP,3.0)\r\n#SAME[ER,2,0]\r\n",bytes.toString());
		System.setOut(console);
		
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		Elevator ele1=new Elevator();
		QueueReq queue1=new QueueReq();
		queue1.manage(new Request("(FR,1,UP,0)"));
		queue1.manage(new Request("(ER,3,0)"));
		queue1.manage(new Request("(ER,4,0)"));
		controller.deal(queue1,ele1);
		//assertEquals("[FR,1,UP,0]/(1,STILL,1.0)\r\n[ER,3,0]/(3,UP,2.0)\r\n[ER,4,0]/(4,UP,3.5)\r\n",log.getLog());
		assertEquals("[FR,1,UP,0]/(1,STILL,1.0)\r\n[ER,3,0]/(3,UP,2.0)\r\n[ER,4,0]/(4,UP,3.5)\r\n",bytes.toString());
		System.setOut(console);
	}
	
	@Test
	public void testControl() {
		Elevator ele=new Elevator();
		//QueueReq queue=new QueueReq();
		List <Request> rCom=new ArrayList <Request> ();
		List <Request> rSet=new ArrayList <Request> ();
		List <Request> queue=new ArrayList <Request> ();
		
		//scheduler=0;
		ele.setrCom(rCom);
		ele.setrSet(rSet);
		rCom.add(new Request("(FR,1,UP,0)"));
		rSet.add(new Request("(ER,1,0)"));
		
		//branch1-3;
		Request r=new Request("(FR,1,UP,0)");
		queue.add(r);
		queue.add(new Request("(FR,1,UP,0)"));
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		controller.control(queue,r,ele,0);
		//assertEquals("#SAME[FR,1,UP,0]\r\n#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n#SAME[FR,1,UP,0]\r\n",bytes.toString());
		assertEquals(0,queue.size());
		System.setOut(console);
		
		//branch4;
		r=new Request("(FR,1,UP,0)");
		queue.add(r);
		queue.add(new Request("(ER,1,0)"));
		queue.add(new Request("(FR,1,UP,0)"));
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		controller.control(queue,r,ele,0);
		//assertEquals("#SAME[FR,1,UP,0]\r\n#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n#SAME[FR,1,UP,0]\r\n",bytes.toString());
		assertEquals(1,queue.size());
		System.setOut(console);
		
		//scheduler=1;
		Request r1=new Request("(ER,1,0)");
		controller.control(queue,r1,ele,0);
		assertEquals(1,queue.size());
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		queue.add(r);
		controller.control(queue,r1,ele,0);
		//assertEquals("#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n",bytes.toString());
		assertEquals(1,queue.size());
		System.setOut(console);
		
		//scheduler=2;
		//MainExis && !byway
		queue.remove(0);
		r1=new Request("(ER,2,0)");
		queue.add(r1);
		controller.control(queue,r1,ele,0);
		assertEquals(1,queue.size());
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		queue.add(r);
		controller.control(queue,r1,ele,0);
		assertEquals(1,queue.size());
		//assertEquals("#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n",bytes.toString());
		System.setOut(console);
		
		//MainExist && byway
		ele.rSetClear();
		Request r2=new Request("(ER,3,0)");
		ele.Main(r2);
		queue.remove(0);
		queue.add(r1);
		controller.control(queue,r1,ele,0);
		assertEquals(0,queue.size());
		assertEquals(2,ele.rSetLen());
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		ele.rSetClear();
		queue.add(r1);
		queue.add(r);
		ele.Main(r2);
		controller.control(queue,r1,ele,0);
		assertEquals(0,queue.size());
		assertEquals(2,ele.rSetLen());
		//assertEquals("#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n",bytes.toString());
		System.setOut(console);
		
		ele.rSetClear();
		queue.add(r2);
		queue.add(r1);
		ele.Main(r2);
		controller.control(queue,r2,ele,0);
		assertEquals(1,queue.size());
		assertEquals(2,ele.rSetLen());
		
		//!MainExist
		ele.rSetClear();
		queue.remove(0);
		queue.add(r2);
		controller.control(queue,r2,ele,0);
		assertEquals(0,queue.size());
		assertEquals(1,ele.rSetLen());
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		ele.rSetClear();
		queue.add(r2);
		queue.add(r);
		controller.control(queue,r2,ele,0);
		assertEquals(0,queue.size());
		assertEquals(1,ele.rSetLen());
		//assertEquals("#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n",bytes.toString());
		System.setOut(console);
	
		
	}
	 

	@Test
	public void testPrintSame() {
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		controller.printSame(new Request("(FR,1,UP,0)"));
		//assertEquals("#SAME[FR,1,UP,0]\r\n",log.getLog());
		assertEquals("#SAME[FR,1,UP,0]\r\n",bytes.toString());
		System.setOut(console);
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		controller.printSame(new Request("(FR,2,DOWN,1)"));
		//assertEquals("#SAME[FR,2,DOWN,1]\r\n",log.getLog());
		assertEquals("#SAME[FR,2,DOWN,1]\r\n",bytes.toString());
		System.setOut(console);
		
		//log.clearLog();
		bytes=new ByteArrayOutputStream();
		console=System.out;
		System.setOut(new PrintStream(bytes));
		controller.printSame(new Request("(ER,3,2)"));
		//assertEquals("#SAME[ER,3,2]\r\n",log.getLog());
		assertEquals("#SAME[ER,3,2]\r\n",bytes.toString());
		System.setOut(console);
	}
	

	
	@Test
	public void testSchedule() {
		int result;
		Elevator ele=new Elevator();
		List <Request> rCom=new ArrayList <Request> ();
		List <Request> rSet=new ArrayList <Request> ();
		Request request1=new Request("(ER,1,0)");
		Request request2=new Request("(ER,3,0)");
		Request request3=new Request("(ER,1,2)");
		Request request4=new Request("(FR,3,UP,2)");
		request1.setLimit(new BigDecimal("1"));
		request2.setLimit(new BigDecimal("3"));
		request3.setLimit(new BigDecimal("5"));
		request4.setLimit(new BigDecimal("7"));
		
		
		rCom.add(request1);
		rCom.add(request2);
		rSet.add(request3);
		rSet.add(request4);
		ele.setrCom(rCom);
		ele.setrSet(rSet);
		
		result=controller.schedule(new Request("(ER,1,1)"),ele);
		assertEquals(0,result);
		
		result=controller.schedule(new Request("(ER,1,0)"),ele);
		assertEquals(0,result);
		
		result=controller.schedule(new Request("(ER,1,2)"),ele);
		assertEquals(1,result);
		
		result=controller.schedule(new Request("(ER,3,5)"),ele);
		assertEquals(2,result);
		
		result=controller.schedule(new Request("(FR,3,UP,3)"),ele);
		assertEquals(1,result);
		
		result=controller.schedule(new Request("(FR,5,UP,3)"),ele);
		assertEquals(2,result);
		
	}
	
	
}
