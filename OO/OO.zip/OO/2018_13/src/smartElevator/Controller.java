package smartElevator;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Controller{
	/*Overview:Controller类对请求进行调度*/
	
	public boolean repOK() {
		/** @REQUIRES:None;
        *@MODIFIES:None;
        *@EFFECTS:
        * 		\result==true; 
        */
		
		return true;
	}
	
	public void deal(QueueReq Queue,Elevator e) {
		 /**@REQUIRES:Queue!=null && e!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		对请求进行调度
         */
		
		 List <Request> res=new ArrayList <Request>();
		 List <Request> queue=new ArrayList <Request>();
		 int i=0;
		 queue=Queue.queOut();
		 
		 while(queue.size()!=0) {
			 control(queue,(Request)queue.get(0),e,0);
			 res=e.curMDone(); 
			 if(res!=null) {
				 for(i=res.size()-1;i>=0;i--) queue.add(0,res.get(i));
				 for(i=res.size()-1;i>=0;i--) res.remove(i);
			 }
		 }
	}
	

	public int control(List <Request>queue,Request r,Elevator e,int i) {
		 /**@REQUIRE:queue!=null && r!=null && e!=null && i>=0 && i<queue.size();
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==0;
         *		对请求进行同质以及捎带判断;
         */
		
		if(schedule(r,e)==0) {
			queue.remove(r);
			printSame(r);
			if(queue.size()!=0 && i!=queue.size()){
				r=(Request)queue.get(i);
				control(queue,r,e,i);
			}
		}
		
		else if(schedule(r,e)==1) {
			if(i!=queue.size()-1){
				r=(Request)queue.get(++i);
				control(queue,r,e,i);
			}
			else return 0;
		}
		
		else{
			if(e.MainExist()) {
				if(e.ByWay(r)) {
					queue.remove(r);
					if(queue.size()!=0  && i!=queue.size()){
						r=(Request)queue.get(i);
						control(queue,r,e,i);
					}
					else return 0;
				}
				else {
					if(i!=queue.size()-1){
						r=(Request)queue.get(++i);
						control(queue,r,e,i);
					}
					else return 0;
				}
			}
			
			else {
				e.Main(r);
				queue.remove(r);
				if(i!=queue.size() && queue.size()!=0){
					r=(Request)queue.get(i);
					control(queue,r,e,i);
				}
				else return 0;
			}
		}
		
		return 0;
		
	}   
	
	public void printSame(Request r) {
		 /**@REQUIRES:r!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		System.out.println("#SAME[request]");
         */
		
		System.out.print("#SAME");
		if(r.ask()==1)        System.out.println("["+"FR"+","+r.floor()+","+"UP"+","+r.time()+"]");
		else if(r.ask()==2)   System.out.println("["+"FR"+","+r.floor()+","+"DOWN"+","+r.time()+"]");
		else                  System.out.println("["+"ER"+","+r.floor()+","+r.time()+"]");
	}
	
	
	public int schedule(Request r,Elevator e) {
		 /**@REQUIRES:r!=null && e!=null;
         *@MODIFIES:None;
         *@EFFECTS:
         *		same(request)==>(\result==0);
         *		sametemporary(request)==>(\result==1);
         *		!same(request)==>)(\result==2);
         */
		
		BigDecimal limitTime;
		
		if(e.findCom(r)) {
			limitTime=e.limitCom(r);
			if(r.time().compareTo(limitTime)==0) return 0;
			else if (r.time().compareTo(limitTime)==-1) return 0;
			else {
				if(e.findSet(r)) return 1;
				else return 2;
			}
		}
		
		else {
			if(e.findSet(r)) return 1;
			else return 2;
		}
		
	}

}
