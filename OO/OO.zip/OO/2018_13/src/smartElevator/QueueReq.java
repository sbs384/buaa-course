package smartElevator;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
 
public class QueueReq{
	/* @Overview:对请求进行队列管理 */
     private List <Request> queEfficient=new ArrayList <Request>();
     
     
     public boolean repOK() {
    	 /** @REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         * 		(\this.queEfficient==null) ==> (\result==false); 
         * 		(\this.queEfficient!=null) ==> (\result==true); 	
         */
    	 
    	 if(queEfficient==null) return false;
    	 else return true;
     }
     
  
     public int manage(Request r) {
    	 /** @REQUIRES:r!=null && queueEfficient!=null;
         *@MODIFIES:this;
         *@EFFECTS:
         * 		(\this.size == \old(\this).size+1) && (\this.contains(r)==true) ==> (\result==0); 
         * 		(\this.size != \old(\this).size+1) ==> (\result==1); 		
         */
    	 
    	 int last;
    	 BigDecimal zero=new BigDecimal("0");
    
    	 if(queEfficient.size()==0) {
    		 if((r.time().compareTo(zero)==0) && (r.floor()==1) && (r.ask()==1)) {
    			 queEfficient.add(r);
    			 r.setOrder(queEfficient.size()-1);
    			 return 0; 
    		 }
    		 else return 1;
    	 }
    	 else {
    		last=queEfficient.size();
    		Request rLast=(Request)queEfficient.get(last-1);
    		if(r.time().compareTo(rLast.time())==-1) return 1;
    		else if(r.time().compareTo(rLast.time())==0) {
    		    queEfficient.add(r);
    		    r.setOrder(queEfficient.size()-1);
    			return 0;
    		}
    		else {
    			queEfficient.add(r);
    			r.setOrder(queEfficient.size()-1);
    			return 0;
    		}
    	 }
     }
     
        
     public int Len() {
    	 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==queueEfficient.size();
         */
    	 
       	 return queEfficient.size();
     }
     
     
     public Request curReq(int i) {
    	 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==queueEfficient.get(i);
         */
    	 
    	 Request r=(Request)queEfficient.get(i);
    	 return r;
     }
     
     
     public List <Request> queOut() {
    	 /**@REQUIRES:None;
         *@MODIFIES:None;
         *@EFFECTS:
         *		\result==queueEfficient;
         */
    	 
    	 return queEfficient;
     }

     //测试使用
     public void clear() {
    	 for(;queEfficient.size()!=0;) queEfficient.remove(0);
     }
    
     public void setQueEfficient() {
     	queEfficient=null;
     }
}
