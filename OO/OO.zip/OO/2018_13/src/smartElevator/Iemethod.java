package smartElevator;
 
public abstract interface Iemethod {    
       public abstract int curfloor(Request r);
}
   