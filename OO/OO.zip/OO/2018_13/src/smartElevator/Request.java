package smartElevator;
import java.math.BigDecimal;
 
public class Request {
	/*Overview:Request类形成请求*/
	
	private int floor;
	private int ask;
    private BigDecimal time;
    private BigDecimal limit;
    private int intflow=0;
    private int order;
   
   	
    public Request(String s) {
    	 /**@REQUIRES:s.matches("^\\(FR,[+]?0{0,100}[1-9],UP,[+]?0{0,100}\\d{1,10}\\)$")||
    	 *			  s.matches("^\\(FR,[+]?0{0,100}([2-9]|(10)),DOWN,[+]?0{0,100}\\d{1,10}\\)$")||
    	 *			  s.matches("^\\(ER,[+]?0{0,100}([1-9]|(10)),[+]?0{0,100}\\d{1,10}\\)$"); 		
         *@MODIFIES:
         *			\this.floor();
         *			\this.ask;
         *			\this.time;
         *@EFFECTS:
         *			根据字符串初始化请求的各类属性;
         */
    	
    	int i=0,len=s.length();
    	char x;
    	String number=new String();
    	String direction=new String();
    	BigDecimal maxnumber=new BigDecimal("4294967296");
    	BigDecimal zero=new BigDecimal("0");
    	
    	setLimit(zero);
    	
    	while(i<len) {
    		x=s.charAt(i);
    		if(x=='(') ++i;
    		
    		else if(x=='F' || x=='E') {
    			if(x=='E') setAsk(3);
    			i+=3;
    			x=s.charAt(i);
    			if(x=='+') x=s.charAt(++i);
    			number=new String();
    			while(x>='0' && x<='9') {
    				number+=x;
    				x=s.charAt(++i);
    			}
                setFloor(Integer.parseInt(number));
    			++i;
    		}
    		
    		else if(x=='U' || x=='D') {
    			direction=new String();
    			while(x!=',') {
    				direction+=x;
    				x=s.charAt(++i);
    			}
    			if(direction.equals("UP"))        this.setAsk(1);
    			else this.setAsk(2);
    			++i;
    		}
    		
    		else if(x=='+') {
    			x=s.charAt(++i);
    			number=new String();
    			while(x>='0' && x<='9') {
    				number+=x;
    				x=s.charAt(++i);
    			}
    			BigDecimal trans=new BigDecimal (number);
                if(trans.compareTo(maxnumber)==-1) setTime(trans);
                else setIntflow(1);
    		}
    		
    		else if(x>='0' && x<='9') {
    			number=new String();
    			while(x>='0' && x<='9') {
    				number+=x;
    				x=s.charAt(++i);
    			}
    			BigDecimal trans=new BigDecimal (number);
                if(trans.compareTo(maxnumber)==-1) setTime(trans);
                else setIntflow(1);
    		}
    		
    		else ++i;
    	}
    }
  
    public void setIntflow(int intflow) {
		this.intflow = intflow;
	}

   	public void setFloor(int floor) {
   		this.floor = floor;
   	}

   	public void setTime(BigDecimal time) {
   		this.time = time;
   	}

   	public void setAsk(int ask) {
   		this.ask = ask;
   	}
   	   
   	public void setLimit(BigDecimal limit) {
   		this.limit = limit;
   	}
    
   	public void setOrder(int order) {
   		this.order = order;
   	}   
    
    public int flow() {
    	return intflow;
    }
    
    public int floor() {
    	return floor;
    }
    
    public BigDecimal time() {
    	return time;
    }
    
    public BigDecimal limit() {
    	return limit;
    }
   
   public int ask() {
	   return ask;
   }
   
   public int order() {
	   return order;
   }
   
   //重写方法
   @Override
	public boolean equals(Object obj) {
 		if(this==obj) return true;
		if(obj==null) return false;
		if(!(obj instanceof Request)) return false;
		Request request=(Request)obj;
		if(this.floor==request.floor) {
			if(this.ask==request.ask) return true;
			else return false;
		}
 		else return false;
   }

}
