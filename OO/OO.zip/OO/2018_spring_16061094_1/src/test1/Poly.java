package test1;

public class Poly {
     private int [][] terms=new int [1005][2];
     private int amt;
     private int same=0;
      
	
      
	//���췽�� 
     public Poly() {  
    	 this.setAmt(0); 
     };
    
 
 
	public Poly(String s) {
		 int [][] termsget=new int [1005][2];
		 int sort []=new int [2];
    	 int i=0,j=0,len=s.length(),opNum,row=0,column=0,amtget=0;
    	 char x;
    	 String number=new String();
    	 while(i<len) {
    		 x=s.charAt(i);
    		 //'('ֻ�ܵ�',  
    		 if(x=='(') {
    			 x=s.charAt(++i);
    			 if(x=='-'||x=='+') {
    				 if(x=='-') opNum=0;
    				 else opNum=1;
    				 
    				 x=s.charAt(++i);
    				 number=new String();
    				 while(x>='0'&&x<='9') {
    					 number+=x;
    					 x=s.charAt(++i);
    				 }
    				 row=Integer.parseInt(number);
    				 if(opNum==0) row=0-row;  				 
    			 }
  
    			 else if(x>='0'&&x<='9') {
    				 number=new String();
    				 while(x>='0'&&x<='9') {
    					 number+=x;
    					 x=s.charAt(++i);
    				 }
    				 row=Integer.parseInt(number);				 
    			 }
    		 }
    		 
    		 //','ֻ�ܵ�')'
    		 else if(x==',') {
    			 x=s.charAt(++i);
    			 if(x=='+') {
    				 x=s.charAt(++i);
    				 number=new String();
    				 while(x>='0'&&x<='9') {
    					 number+=x;
    					 x=s.charAt(++i);
    				 }
    				 column=Integer.parseInt(number);			 
    			 }
    			 
    			 else if(x=='-') {
    				 x=s.charAt(++i);
    				 number=new String();
    				 while(x=='0') {
    					 number+=x;
    					 x=s.charAt(++i);
    				 }
    				 column=Integer.parseInt(number);			 
    			 }
  
    			 else if(x>='0'&&x<='9') {
    				 number=new String();
    				 while(x>='0'&&x<='9') {
    					 number+=x;
    					 x=s.charAt(++i);
    				 }
    				 column=Integer.parseInt(number);				 
    			 }
    			 
    		 }
    		 
    		 
    		 else if(x==')') {
    			 i=i+2;
    			 termsget[j][0]=row;
    			 termsget[j][1]=column;
    			 j++;
    		 }
    		 
    	 }
    	 
    	 this.setAmt(j);
    	 amtget=j;
   
    	 
    	 for(i=0;i<amtget-1;i++) {
    		 for(j=i+1;j<amtget;j++) {
    			 if(termsget[i][1]>termsget[j][1]) {
    				 sort=termsget[i];
    				 termsget[i]=termsget[j];
    				 termsget[j]=sort;
    			 }
    			 else if(termsget[i][1]==termsget[j][1]) {
    				 this.setSame(1);
    			 }
    		 }
    	 }
    	 
    	 this.setTerms(termsget);
    	 
     }


	//Getters and Setters
     public int[][] getTerms() {
		return terms;
	 } 
    
     public int getAmt() {
		return amt;
	 }


	 public void setAmt(int amt) {
		this.amt = amt;
	 }


	 public void setTerms(int[][] terms) {
		this.terms = terms;
	 }
	
	 
	 public int getSame() {
		 return same;
	 }


	 public void setSame(int same) {
		 this.same = same;
	 }
     
	 
     //��ͨ����
     public Poly add(Poly q) {
    	 int [][] termsget=new int [1005][2];
    	 int [][] termsgetq=new int [1005][2];
    	 int i=0,mid=0,j,low,high,amtget,amtgetq;
    	 amtget=this.getAmt();
    	 amtgetq=q.getAmt();
    	 termsget=this.getTerms();
    	 termsgetq=q.getTerms();
    	 for(i=0;i<amtget;i++) {
    		 low=0;
    		 high=amtgetq-1;
    		 while(low<=high) {
    			 mid=(low+high)/2;
    			 if(termsgetq[mid][1]<termsget[i][1])       low=mid+1;
    			 else if(termsgetq[mid][1]>termsget[i][1])  high=mid-1;
    			 else if(termsgetq[mid][1]==termsget[i][1]) {
    				 termsgetq[mid][0]+=termsget[i][0];
    				 break;
    			 }
    		 }
    		 if(termsgetq[mid][1]>termsget[i][1]) {
    			 for(j=amtgetq;j>mid;j--)  termsgetq[j]=termsgetq[j-1];
                 termsgetq[mid]=termsget[i];
                 amtgetq++;
    		 }
    		 
    		 else if(termsgetq[mid][1]<termsget[i][1]) {
    			 for(j=amtgetq;j>mid+1;j--) termsgetq[j]=termsgetq[j-1];
    			 termsgetq[mid+1]=termsget[i];
    			 amtgetq++;
    		 }
    	 }
    	 
    	 q.setAmt(amtgetq);
    	 q.setTerms(termsgetq);
    	 return q;
     }
     
     
     public Poly sub(Poly q) {
    	 int [][] termsget=new int [1005][2];
    	 int [][] termsgetq=new int [1005][2];
    	 int i=0,mid=0,j,low,high,amtget,amtgetq;
    	 amtgetq=q.getAmt();
    	 amtget=this.getAmt(); 
    	 termsget=this.getTerms();
    	 termsgetq=q.getTerms();
    	 for(i=0;i<amtgetq;i++) termsgetq[i][0]=0-termsgetq[i][0];
    	 for(i=0;i<amtget;i++) {
    		 low=0;
    		 high=amtgetq-1;
    		 while(low<=high) {
    			 mid=(low+high)/2;
    			 if(termsgetq[mid][1]<termsget[i][1])       low=mid+1;
    			 else if(termsgetq[mid][1]>termsget[i][1])  high=mid-1; 
    			 else if(termsgetq[mid][1]==termsget[i][1]) {
    				 termsgetq[mid][0]+=termsget[i][0];
    				 break;
    			 }
    		 }
    		 if(termsgetq[mid][1]>termsget[i][1]) {
    			 for(j=amtgetq;j>mid;j--)  termsgetq[j]=termsgetq[j-1];
                 termsgetq[mid]=termsget[i];
                 amtgetq++;
    		 }
    		 
    		 else if(termsgetq[mid][1]<termsget[i][1]) {
    			 for(j=amtgetq;j>mid+1;j--) termsgetq[j]=termsgetq[j-1];
    			 termsgetq[mid+1]=termsget[i];
    			 amtgetq++;
    		 }
    	 }
    	 
    	 q.setAmt(amtgetq);
    	 q.setTerms(termsgetq);
    	 return q;
     }  
    
}
