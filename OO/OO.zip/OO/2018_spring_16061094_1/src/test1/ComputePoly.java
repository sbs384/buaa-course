package test1;
import java.util.Scanner;

public class ComputePoly {
	//���� 
	private Poly polylist[]=new Poly [22];
	private int oplist[]=new int [22];
	private int num;
	
	  
	//��ͨ���� 
	//ȥ���ո� 
	private String operString(String s) {
		String regexSp="\\s+";
		String strNosp=s.replaceAll(regexSp,"");
		if (strNosp.isEmpty()) return "ERROR";
		else {
			char head=strNosp.charAt(0);
		    if(head=='{') strNosp='+'+strNosp;
		    return strNosp;
		}
	}
	
	//�ж��ַ���
	private boolean judgeString(String s) {
		int i;
		boolean result,result1=false,result2=false;
		//�жϻ�����
		String regex1="^([+-]\\{[^\\{\\}]+\\}){1,20}$";
		result1=s.matches(regex1);
		//�ָ�������
		String regexSplit="[+-]\\{";
		String [] strSplit=s.split(regexSplit);
		//�Ի������ڽ����ж�
	    for(i=1;i<strSplit.length;i++) {
	    		String regex2="\\([+-]?\\d{1,6},(([+]?\\d{1,6})|(-0{1,6}))\\)(,\\([+-]?\\d{1,6},(([+]?\\d{1,6})|(-0{1,6}))\\)){0,49}\\}";
	    		result2=strSplit[i].matches(regex2);
	    	    if(!result2) break;
	     }
	    result=result1&&result2;
		return result;
	}
	
	//����oplist����
	private void operOplist(String s) {
		int i,j=0;
		char x,y;
		for(i=0;i<s.length()-1;i++){
			x=s.charAt(i);
			y=s.charAt(i+1);
			if(((x=='+')||(x=='-'))&&(y=='{')) {
				if(x=='+')      oplist[j++]=1;
				else if(x=='-') oplist[j++]=0;		
			}
		}
		num=j;
	}
	
	//�������ʽ����
	private void operPoly(String s) {
		int i;
		String regexOp="[\\+-]\\{";
		String [] strPoly=s.split(regexOp);
		polylist[0]=new Poly();
		for(i=1;i<=strPoly.length-1;i++) {
			polylist[i]=new Poly(strPoly[i]);
			if(polylist[i].getSame()==1) {
				System.out.println("ERROR");
				System.out.println("#Please correct your input!");
                System.exit(0);
			}
		}
	}
	
	//�������ʽ
	private Poly computePoly() {
		int i;
		Poly p=polylist[0],p1=polylist[0],p2;
		for(i=1;i<=num;i++) {
			p2=polylist[i];
			int op=oplist[i-1];
			if(op==1)      p1=p.add(p2);
			else if(op==0) p1=p.sub(p2);
			p=p1;
		}
		return p;
	}
   
	//���������
	private void printPoly(Poly p) {
		int i,j=0,fPrint=0;
		int [][] printArr=p.getTerms();
		int [][] copy=new int [1005][2];
		for(i=0;i<1000;i++) {
			if(printArr[i][0]!=0) {
				copy[j][0]=printArr[i][0];
				copy[j][1]=printArr[i][1];
				j++;
				fPrint=1;
			}	
		}
		
		if(fPrint==0) System.out.print(0);
		else {
			System.out.print("{");
			for(i=0;i<j;i++) {
				System.out.print("("+copy[i][0]+","+copy[i][1]+")");
			    if(i!=j-1) System.out.print(",");
			}
			System.out.print("}");
		}
	}
	 
	
    //main����
	public static void main(String[] args) {
		try {
			ComputePoly cp=new ComputePoly();
			Scanner input=new Scanner(System.in);
			String strInput=input.nextLine();
			input.close();
        
        
        //��֤������ַ����Ƿ�Ϊ��
        	if(strInput.isEmpty()) {
        		System.out.println("ERROR");
        		System.out.println("#Please correct your input!");
        	}
        	else {
        
        		//�õ�ȥ���ո���ַ���
        		String strOper=cp.operString(strInput);
        		//�ж��ַ����Ƿ�Ϸ�
        		boolean judRes=cp.judgeString(strOper);
        		if(judRes) {
        			//����oplist����
        			cp.operOplist(strOper);
        			//�������ʽ����
        			cp.operPoly(strOper);
        			//����ʽ����
        			Poly pRes=cp.computePoly();
        			//���������
        			cp.printPoly(pRes);
        		}
        		else {
        			System.out.println("ERROR");
        			System.out.println("#Please correct your input!");
        		}
        	}
        	
        	System.exit(0);
        	
        }catch(Exception e){
        	System.out.println("ERROR");
        	System.out.println("#Please correct your input!");
        	System.exit(0);
        }
        
        
	}

}
