package elevator;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;

public class Elevator {
    private BigDecimal OT=new BigDecimal("0");
	private List <Request> rAccomplish=new ArrayList <Request>();
	
 	//普通方法
    //operator方法对命令进行操作
	//OT最新的执行完时间;timeOUt/ST停靠时间;RT当前进入的请求发出时间;UDT升降时间
    public void operator(Request r,Floor f) {
    	int floorDiffer,floorOut;
    	double one=1;
    	BigDecimal timeOut=new BigDecimal("0");
    	String directOut=new String();
    	
    	floorDiffer=r.floor()-f.floor();
    	//判断目标楼层与当前电梯楼层是否为同一楼层
    	if(floorDiffer!=0) {
    		//对输出的结果进行处理
    		//得到运行时间和停靠楼层
    		if(floorDiffer<=0) { 
    			directOut="DOWN";
                floorDiffer=0-floorDiffer;
    		}
    		else directOut="UP";
    		floorOut=r.floor();
    		//计算停靠时间
    		double Differ=(double)floorDiffer;
    		Differ=Differ*0.5; 
    		if(r.time().compareTo(OT)==1) timeOut=new BigDecimal(Double.toString(add(r.time(), Differ)));
    		else timeOut=new BigDecimal(Double.toString(add(OT, Differ)));
    		//输出结果
    		System.out.println("("+floorOut+","+directOut+","+timeOut.setScale(1,BigDecimal.ROUND_DOWN)+")");
    		
    		
    		//修改电梯以及楼层除List以外的属性
    		OT=new BigDecimal(Double.toString(add(timeOut,one)));
    		f.changeFloor(r.floor());
            //当前请求完成，入队
    	    r.setLimit(OT);
    		rAccomplish.add(r);
    		
    	}
    	
    	else if(floorDiffer==0) {
    		directOut="STILL";
    		floorOut=r.floor();
    		if(r.time().compareTo(OT)==1) timeOut=new BigDecimal(Double.toString(add(r.time(),one)));
    		else timeOut=new BigDecimal(Double.toString(add(OT,one)));
    		//输出结果
    		System.out.println("("+floorOut+","+directOut+","+timeOut.setScale(1,BigDecimal.ROUND_DOWN)+")");  
    		//修改电梯以及楼层除List以外的属性
    		OT=timeOut;
    		f.changeFloor(r.floor());
            //当前请求完成，入队
    		r.setLimit(OT);
    		rAccomplish.add(r);
    	}
    	
    	
    }
    
    //find方法查看已完成请求队列中是否有与当前请求一样的	请求
    public boolean find(Request r) {
    	if(rAccomplish.contains(r)) return true;
    	else return false;
    }
    
  
    //limit方法查看与当前请求距离最近的请求的同质限制时间
    public BigDecimal limit(Request r) {
    	BigDecimal time;
    	int index;
    	Request rLast;
    	index=rAccomplish.lastIndexOf(r);
    	rLast=(Request)rAccomplish.get(index);
    	time=rLast.limit();
    	return time;
    }
    
    //BigDecimal加法
    public double add(BigDecimal b1,double d2){     
        BigDecimal b2 = new BigDecimal(d2);  
        return b1.add(b2).doubleValue();
	}

}
