package elevator;
import java.util.Scanner;


public class Main {
	
	//对输入的字符串进行处理
	public String opStr(String s) {
		String regexSp="\\s+";
		String strOp=s.replaceAll(regexSp,"");
		return strOp;
	}
	
	//判断输入的请求是否合法
	public boolean judgeInput(String s) {
		String regex1="^\\(FR,[+]?0{0,100}[1-9],UP,[+]?0{0,100}\\d{1,10}\\)$";
		String regex2="^\\(FR,[+]?0{0,100}([2-9]|(10)),DOWN,[+]?0{0,100}\\d{1,10}\\)$";
		String regex3="^\\(ER,[+]?0{0,100}([1-9]|(10)),[+]?0{0,100}\\d{1,10}\\)$";
		
		
		if(s.matches(regex1)) return true;
		if(s.matches(regex2)) return true;
		if(s.matches(regex3)) return true;
		return false;
	}

	public static void main(String[] args) {
		boolean resInput=false,resSche=false;
		int queueLen=0,i=0,resManage=-1,inputNum=0;
		
		//初始化相关对象实例
		Main main=new Main();
		QueueReq queue=new QueueReq();
		Elevator elevator=new Elevator();
		Floor floor=new Floor();
		Control control=new Control();
		
		try {
			Scanner keyboard=new Scanner(System.in);
			String input=keyboard.nextLine();
			++inputNum;
			
			if(input.equals("RUN")) {
				System.out.println("ERROR");
				System.out.println("#No request!Please run again!");
				System.exit(1);
			}
			
			//对输入的请求进行处理
			while(!input.equals("RUN")) {
				//判断输入的请求是否合法
				String inputOp=main.opStr(input);
				resInput=main.judgeInput(inputOp);
				
				if(resInput) {
					//构造请求对象
					Request request=new Request(inputOp);
					
					//如果请求时间超过32bit无符号数范围
					if (request.flow()==1) {
						System.out.println("ERROR");
						System.out.println("#The request time is out of range!Please input a new request!");
					}
					//否则对输入的请求进行管理
					else {
						resManage=queue.manage(request);
						if(resManage==1) {
							System.out.println("ERROR");
							System.out.println("#The first request time must be zero!Please input a new request!");
						}
						else if(resManage==2) {
							System.out.println("ERROR");
							System.out.println("#The request time mustn't be in a descending order!Please input a new request!");
						}
					}
				}
				
				
				else{
					System.out.println("ERROR");
					System.out.println("#The input is illegal!Please input a new request!");
				}
				
				input=keyboard.nextLine();
				++inputNum;
				if(!input.equals("RUN") && inputNum==101) {
					System.out.println("ERROR");
					System.out.println("#The number of request is more than 100!Please run again!");
					System.exit(0);  
				}
			}
			
			keyboard.close();
		      

			if(queue.Len()==0) {
				System.out.println("ERROR");
				System.out.println("#There's no legal request!Please run again!");
				System.exit(1);
			}
			
            
			
			queueLen=queue.Len();
			//调度类访问请求
			for(i=0;i<queueLen;i++) {
				Request r=queue.curReq(i);
				//调用调度类的schedule方法取得可调度的请求
				resSche=control.schedule(r,elevator);
				//取得可调度的请求后对电梯发出命令
				if(resSche) control.command(r,elevator,floor);
				if(!resSche) System.out.println("#Invalid request!");
			}
			System.exit(0);
			
			
		}catch(Exception e) {
			System.out.println("ERROR");
			System.out.println("#Crush Error!Please run again!");
			System.exit(1);
		}

	}

}
