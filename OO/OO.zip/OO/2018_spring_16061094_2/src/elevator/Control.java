package elevator;
import java.math.BigDecimal;

public class Control {
     
	//普通方法
	//schedule方法判断当前请求是否为可调度请求，即不是前面某个请求的同质请求
	public boolean schedule(Request r,Elevator e) {
		BigDecimal limitTime;
		if(e.find(r)) {
			limitTime=e.limit(r);
			if(r.time().compareTo(limitTime)==1) return true;
			else return false;
		}
		else return true;
	}
	
	//command方法向电梯发出命令   
	public void command(Request r,Elevator e,Floor f) {
		e.operator(r,f);
	}
}
