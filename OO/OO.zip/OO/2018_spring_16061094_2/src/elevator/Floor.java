package elevator;

public class Floor {
     private int curFloor;
     
     public Floor(){
    	 curFloor=1;
     }
     
     public int floor() {
    	 return curFloor;
     }
     
     public void changeFloor(int curFloor) {
    	 this.curFloor=curFloor;
     }
}


   