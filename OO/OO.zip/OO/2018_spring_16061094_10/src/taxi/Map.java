package taxi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.awt.Point;
import java.util.Random;

public class Map{
	/* @Overview:Map类对城市地图初始化，包括每个节点地图信息查询功能  */
	
	private int map[][]=new int [82][82];
	private int mapInit[][]=new int [82][82];
	private int flow[][]=new int [6405][6405];
	private int state=0;
	private int dist[][]=new int [82][82];
	private boolean visit [][]=new boolean [82][82];
	private Queue <Point> distqueue=new LinkedList <Point> ();

	private final static int infinite=40000000;
	private TaxiGUI gui;
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==!(dist==null || map==null || flow==null || visit==null || distqueue==null ||gui!=null ||distqueue==null)&&
        *      !(\all int i,j;0<=i<80,0<=j<80;map[i][j]!=0 || map[i][j]!=1 || map[i][j]!=2 || map[i][j]!=3)&&
        *      !(state<0 ==>\result);
        */ 
	  if(dist==null || map==null || flow==null || visit==null || distqueue==null ||gui==null ||distqueue==null) return false;
	  for(int i=0;i<80;i++) {
		  for(int j=0;j<80;j++) {
			  if(map[i][j]!=0 && map[i][j]!=1 && map[i][j]!=2 && map[i][j]!=3) return false; 
		  }
	  }
	 
	  if(state<0) return false;
	  
	  return true;        
   }
	
	public Map(TaxiGUI gui) throws FileNotFoundException {
		/** @REQUIRES:gui!=null;
        *@MODIFIES:
        *	\this.flow;
        *	\this.map;
        *	\this.gui;
        *	\this.name;
        *@EFFECTS:
   		*	(\all int i,j;0<=i<=6405 && 0<=j<=6405)==>flow[i][j]=0;
		*	\this.gui==gui;		
		*	initial map according to map.txt;
        */
		
		int i,j;
		if(!readfile("map.txt")) {
			error();
			System.exit(1);
		}
		
		for(i=0;i<6405;i++) {
			for(j=0;j<6405;j++) flow[i][j]=0;
		}
		
		this.gui=gui;
	}
	
	public boolean readfile(String path) throws FileNotFoundException {  
		/** @REQUIRES:
        *@MODIFIES:
        *     \this.map;
        *@EFFECTS:
       	*	File(path).exists && File(path).isFile==>read File(path);
        *   no parse error of File(path)==> load content to map;   
        */
		
		int i=0;
		String str;
		
		if(!new File(path).exists()) return false;
		if(!new File(path).isFile()) return false;
		
        InputStream input = new FileInputStream(new File(path));
        InputStreamReader reader = new InputStreamReader(input);
        BufferedReader buff = new BufferedReader(reader);
        
        try {
        	while((str=buff.readLine())!=null) {
        		if(i==80) return false;
        		
        		else {
        			str=str.replaceAll("\\s+","");
        			
        			if(str.length()!=80) return false;
        			else {
        				for(int k=0;k<str.length();k++) {
        					char x=str.charAt(k);
        					if((x-'0')>=0 && (x-'0')<=3) map[i][k]=x-'0';
        					else return false;
        				}
        			}
        		}
        		
        		++i;
        	}
        	
        	return true;
        	
        }catch(Exception e) {
        	System.out.println("Crash error!");
        	return false;
        }
	}
	
	
	
	public void open(String s) {
		/**@REQUIRES:
        *@MODIFIES:
        *   \this.map;
        *@EFFECTS:
       	*	(\all int x1,x2,y1,y2;map[demens(x1,y1)][demens(x2,y2)] not open)==>open map[demens(x1,y1)][demens(x2,y2)];
        *   (\all int x1,x2,y1,y2;map[demens(x1,y1)][demens(x2,y2)] open)==>System.out.println("The road has been existed!");
        */
		
		int x1,y1,x2,y2,temp;
		
		String [] str=s.split(",");
		
		//System.out.println(str[1]);
		x1=Integer.parseInt(str[1].replaceAll("\\(",""));
		y1=Integer.parseInt(str[2].replaceAll("\\)",""));
		x2=Integer.parseInt(str[3].replaceAll("\\(",""));
		str[4]=str[4].replaceAll("\\)","");
		y2=Integer.parseInt(str[4].replaceAll("\\]",""));
		
		if(x1==x2 && Math.abs(y1-y2)==1) {
			if(y1>y2) {//y1为较小值
				temp=y1;
				y1=y2;
				y2=temp;
			}
			
			if(mapInit[x1][y1]!=1 && mapInit[x1][y1]!=3) System.out.println("The road can not be opened!");
			
			
			else {
				if(map[x1][y1]==1 || map[x1][y1]==3) System.out.println("The road has been existed!");
				else if(map[x1][y1]==0) {
					map[x1][y1]=1;
					++state;
					gui.SetRoadStatus(new Point(x1,y1), new Point(x1,y1+1), 1);
				}
				else{
					map[x1][y1]=3;
					++state;
					gui.SetRoadStatus(new Point(x1,y1), new Point(x1,y1+1), 1);
				}
			}
		}
		
		else if(y1==y2 && Math.abs(x1-x2)==1) {
			if(x1>x2) {//y1为较小值
				temp=x1;
				x1=x2;
				x2=temp;
			}
			
			if(mapInit[x1][y1]!=2 && mapInit[x1][y1]!=3) System.out.println("The road can not be opened!");
			
			
			else {
				if(map[x1][y1]==2 || map[x1][y1]==3) System.out.println("The road has been existed!");
				else if(map[x1][y1]==0) {
					map[x1][y1]=2;
					++state;
					gui.SetRoadStatus(new Point(x1,y1), new Point(x1+1,y1), 1);
				}
				else {
					map[x1][y1]=3;
					++state;
					gui.SetRoadStatus(new Point(x1,y1), new Point(x1+1,y1), 1);
				}
			}
		}
		
		else System.out.println("Invalid path request!");
	}
	
	public void close(String s) {
		/**@REQUIRES:
        *@MODIFIES:
        *     \this.map;
        *@EFFECTS:
       	*	(\all int x1,x2,y1,y2;map[demens(x1,y1)][demens(x2,y2)] not close)==>close map[demens(x1,y1)][demens(x2,y2)];
        *   (\all int x1,x2,y1,y2;map[demens(x1,y1)][demens(x2,y2)] close)==>System.out.println("The road has been closed!");
        */
		
		int x1,y1,x2,y2,temp;
		
		String [] str=s.split(",");
		
		x1=Integer.parseInt(str[1].replaceAll("\\(", ""));
		y1=Integer.parseInt(str[2].replaceAll("\\)",""));
		x2=Integer.parseInt(str[3].replaceAll("\\(",""));
		str[4]=str[4].replaceAll("\\)","");
		y2=Integer.parseInt(str[4].replaceAll("\\]",""));
		
		if(x1==x2 && Math.abs(y1-y2)==1) {
			if(y1>y2) {//y1为较小值
				temp=y1;
				y1=y2;
				y2=temp;
			}
			
			if(map[x1][y1]==0 || map[x1][y1]==2) System.out.println("The road has been closed!");
			else if(map[x1][y1]==1) {
				map[x1][y1]=0;
				++state;
				gui.SetRoadStatus(new Point(x1,y1), new Point(x1,y1+1), 0);
			}
			else {
				map[x1][y1]=2;
				++state;
				gui.SetRoadStatus(new Point(x1,y1), new Point(x1,y1+1), 0);
			}
		}
		
		else if(y1==y2 && Math.abs(x1-x2)==1) {
			if(x1>x2) {//y1为较小值
				temp=x1;
				x1=x2;
				x2=temp;
			}
			
			if(map[x1][y1]==0 || map[x1][y1]==1) System.out.println("The road has been closed!");
			else if(map[x1][y1]==2) {
				map[x1][y1]=0;
				++state;
				gui.SetRoadStatus(new Point(x1,y1), new Point(x1+1,y1), 0);
			}
			else {
				map[x1][y1]=1;
				++state;
				gui.SetRoadStatus(new Point(x1,y1), new Point(x1+1,y1), 0);
			}
		}
		
		else System.out.println("Invalid path request!");
	}
	
	public synchronized int[][] getMap(){
		/** @REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
       	*		\result=map;
       	* @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		return map;
	}
	
	public void error() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
   		*	System.out.println("Invalid map file!");
        */
		
		System.out.println("Invalid map file!");
	}
	
	public int demens(int x,int y) {
		/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result==x*80+y;
        */
		
		return x*80+y;
	}
	
	public synchronized void changeState() {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.state;
        *@EFFECTS:
       	*		state=state+1;
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */      
		
		++state;
	}
	
	public synchronized int state() {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result=state;
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */     
		
		
		return state;
	}
	
	public synchronized void addflow(Point p1,Point p2) {
		/**@REQUIRES:
        *@MODIFIES:
      	*		flow[start][end];
      	*		flow[end][start];
        *@EFFECTS:
      	*		flow[start][end]++;
      	*		flow[end][start]++;
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */
		
		
		int x1=(int)(p1.getX()),y1=(int)(p1.getY()),x2=(int)(p2.getX()),y2=(int)(p2.getY());
		int start=demens(x1,y1),end=demens(x2,y2);
		flow[start][end]++;
		flow[end][start]++;
	}
	
	public synchronized void clearflow() {
		/**@REQUIRES:
        *@MODIFIES:
      	*		flow[][];
        *@EFFECTS:
      	*		(\all int i,j;0<=i<=6405 && 0<=j<6405)==>flow[i][j]=0;
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */      
		
		
		int i,j;
		for(i=0;i<6405;i++) {
			for(j=0;j<6405;j++) flow[i][j]=0;
		}
	}
	
	public synchronized int getflow(int x1,int y1,int x2,int y2) {
		/**@REQUIRES:0<=x1<=79 && 0<=x2<=79 && 0<=y1<=79 && 0<=y2<=79;
        *@MODIFIES:None;
        *@EFFECTS:
      	*		\result=flow[start][end];
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */     
		
		
		int start=demens(x1,y1),end=demens(x2,y2);
		return flow[start][end];
	}
	
	public void setflow(int x1,int y1,int x2,int y2,int value) {
		/**@REQUIRES:0<=x1<=79 && 0<=y1<=79 && 0<=x2<=79 && 0<=y2<=79 && 0<=value<=1000;
        *@MODIFIES:
      	*		flow[start][end];
       	*		flow[end][start];
        *@EFFECTS:
       	*		(x1==x2 && Math.abs(y1-y2)==1)||(y1==y2 && Math.abs(x1-x2)==1)==>flow[start][end]=value && flow[end][start]=value;
      	*		!(x1==x2 && Math.abs(y1-y2)==1)||(y1==y2 && Math.abs(x1-x2)==1)==>System.out.println("The flow can't be set!");
        */
		
		
		int start=demens(x1,y1),end=demens(x2,y2);
	    if((x1==x2 && Math.abs(y1-y2)==1)||(y1==y2 && Math.abs(x1-x2)==1) && value>=0 && value<=1000) {
	    	flow[start][end]=value;
	    	flow[end][start]=value;
	    }
	    else System.out.println("The flow can't be set!");
	}
	
	
	public synchronized int[][] SPFA(int x,int y) {
		/**@REQUIRES:0<=x<=79 && 0<=y<=79;
        *@MODIFIES:None;
        *@EFFECTS:
        *     find the shortest distance of every node in map to (x,y);
        *     record the shortest distance in dist[][];
        * @THREAD_REQUIRES:
        *      \locked(\this);
        * @THREAD_EFFECTS:
        *      \locked();
        */      
		
		distqueue.clear();
		for(int i=0;i<82;i++) {
			for(int j=0;j<82;j++) {
				dist[i][j]=infinite;
				visit[i][j]=false;
			}
		}
		
		dist[x][y] = 0;
		visit[x][y]=true;
		distqueue.offer(new Point(x,y));
		
		while (!distqueue.isEmpty()){
			int x1= (int)(distqueue.peek().getX());
			int y1= (int)(distqueue.poll().getY());
			visit[x1][y1]=false;
			
			if(map[x1][y1]==1 || map[x1][y1]==3) {//right
				lax(x1,y1,x1,y1+1);
			}
			if(y1-1>=0 && (map[x1][y1-1]==1 || map[x1][y1-1]==3)) {//left
				lax(x1,y1,x1,y1-1);
			}
			if(x1-1>=0 && (map[x1-1][y1]==2 || map[x1-1][y1]==3)) {//up
				lax(x1,y1,x1-1,y1);
			}
			if((map[x1][y1]==2 || map[x1][y1]==3)) {//down
				lax(x1,y1,x1+1,y1);
			}
		}
		return dist;
	}
	
    public void lax(int x,int y,int xnew,int ynew) {
    	/**@REQUIRES:0<=x<=79 && 0<=y<=79 && 0<=xnew<=79 && 0<=ynew<=79;
        *@MODIFIES:None;
        *@EFFECTS:
       	*		slax the edge between (x,y) and (xnew,ynew);
        */
    	
    	if(dist[xnew][ynew]>dist[x][y]+1) {
    		dist[xnew][ynew]=dist[x][y]+1;
    		if(!visit[xnew][ynew]) {
    			distqueue.offer(new Point(xnew,ynew));
    			visit[xnew][ynew]=true;
    		}
    	}
    }
    
    public void setMapInit(int [][] mapInit) {
    	/**@REQUIRES:mapInit!=null
        *@MODIFIES:\this.mapInit[][];
        *@EFFECTS:
        *		\this.mapInit==mapInit;
        */
    	
    	this.mapInit=mapInit;
    }
	
}
