package taxi;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.awt.Point;


public class Main {
	/* @Overview:Main类模拟出租车调度系统  */
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==true;
        */ 
 
      return true;
            
   }

	public static void main(String[] args) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		initial all objects;
        */
	    	
		
		TaxiGUI gui=new TaxiGUI();
		
		
		Map map=new Map (gui);
		if(!map.readfile("map.txt")) System.exit(1);
		
		LightMap lightmap=new LightMap(gui,map);
		
		ReqQueue reqQueue=new ReqQueue(gui); 
		
		Taxi [] taxiList=new Taxi [100];
	
		//
		RequestSimulator requestsimu=new RequestSimulator("requestsimulator",reqQueue,map);
		requestsimu.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		
		//
		Controller controller=new Controller("controller",map,reqQueue,taxiList);
		controller.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		//
		UpdateFlow upf=new UpdateFlow(map);
		upf.setUncaughtExceptionHandler(new ExceptionHandler());
		
		//
		Test test=new Test(taxiList);
		test.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		//
		UpdateLight upl=new UpdateLight(lightmap);
		upl.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		
		ArgsReader argsreader=new ArgsReader(map,taxiList,gui,reqQueue,lightmap);
		
		try {	
			argsreader.read(args[1],controller,upf,upl);
			requestsimu.start();
			
			//test在这里!!!
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Crash error!");
			}
			test.start();
			
			
		}catch(Exception e) {
			System.out.println("Crash error!");
		}
	}
	

}
