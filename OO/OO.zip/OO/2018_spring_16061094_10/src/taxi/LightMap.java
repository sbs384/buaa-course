package taxi;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;


public class LightMap {
	/* @Overview:LightMap类对红绿灯城市地图初始化，查询每个路口红绿灯情况 */
	
	private TaxiGUI gui;
	private int [][] map;
	private int [][] light=new int [82][82];
	private long lightTime;
	private volatile int state;
	
	private final static int empty=0;
	private final static int green=1;
	private final static int red=2;
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==!(gui==null || map==null || light==null)&&
        *      !(\all int i,j;0<=i<80,0<=j<80;map[i][j]!=0 && map[i][j]!=1 && map[i][j]!=2 && map[i][j]!=3 && light[i][j]!=0 && light[i][j]!=1)&&
        *      !(state!=empty && state!=green && state!=red)&&
        *      !(lightTime<500 || lightTime>1000);
        */ 
	  if(gui==null || map==null || light==null) return false;
	  for(int i=0;i<80;i++) {
		  for(int j=0;i<80;j++) {
			  if(map[i][j]!=0 && map[i][j]!=1 && map[i][j]!=2 && map[i][j]!=3) return false; 
			  if(light[i][j]!=0 && light[i][j]!=1) return false; 
		  }
	  }
	 
	  if(state!=empty && state!=green && state!=red) return false;
	  if(lightTime<500 || lightTime>1000) return false;
	  
	  return true;        
   }
	
	
	public LightMap(TaxiGUI gui,Map map) {
		/**@REQUIRES:map!=null && gui!=null;
		*@MODIFIES:
		*	\this.lighTime;
		*	\this.gui;
		*	\this.map;
		*@EFFECTS:
		*	\this.lighTime==Random().nextInt(501)+500;
		*	\this.gui==gui;
		*	\this.map==map;		
		*/
		
		lightTime=new Random().nextInt(501)+500;
		//lightTime=5000;
		this.gui=gui;
		this.map=map.getMap();
	}
	
	
	public boolean readfile(String path,int color) throws FileNotFoundException {
		/** @REQUIRES:
	    *@MODIFIES:
	    *     \this.light;
	    *@EFFECTS:
	    *	File(path).exists && File(path).isFile==>read File(path);
	    *   no parse error of File(path)==> load content to light;  
	    */
		
		int i=0,j;
		String str;
		
		if(!new File(path).exists()) return false;
		if(!new File(path).isFile()) return false;
		
		//lightTime=new Random().nextInt;
		
        InputStream input = new FileInputStream(new File(path));
        InputStreamReader reader = new InputStreamReader(input);
        BufferedReader buff = new BufferedReader(reader);
        
        try {
        	if(color==0) state=green;
        	else state=red;
        	
        	while((str=buff.readLine())!=null) {
        		if(i==80) return false;
        		
        		else {
        			str=str.replaceAll("\\s+","");
        			
        			if(str.length()!=80) return false;
        			else {
        				for(int k=0;k<str.length();k++) {
        					char x=str.charAt(k);
        					
        					if((x-'0')>=0 && (x-'0')<=1) {
        						if(!cross(i,k)) {
        							light[i][k]=empty;
        							gui.SetLightStatus(new Point(i,k),0);
        							
        							if(x=='1') System.out.println("Invalid Light setting!");
        						}
        							
        						else {
        							if(x=='0') {
        								light[i][k]=empty;
        								gui.SetLightStatus(new Point(i,k),0);
        							}
            						else{
            							if(color==0){
            								light[i][k]=green;
            								gui.SetLightStatus(new Point(i,k),green);
            							}
            							else {
            								light[i][k]=red;
            								gui.SetLightStatus(new Point(i,k),red);
            							}
            							
            						}
        						}
        					}
        					
        					else return false;
        				}
        			}
        		}
        		
        		++i;
        	}
        	
        	return true;
        	
        }catch(Exception e) {
        	System.out.println("Crash error!");
        	return false;
        }
	}
	
	public boolean cross(int x,int y) {
		/** @REQUIRES:0<=x<=79 && 0<=y<=79;
	    *@MODIFIES:None;
	    *@EFFECTS:
	    *	(x,y).iscross==>\result==true;
	    *   !(x,y).iscross==>\resutl==false;
	    */
		
		int num=0;
		if(map[x][y]==1 || map[x][y]==3) ++num;
		if(y-1>=0 && (map[x][y-1]==1 || map[x][y-1]==3)) ++num;
		if(x-1>=0 && (map[x-1][y]==2 || map[x-1][y]==3)) ++num;
		if((map[x][y]==2 || map[x][y]==3)) ++num;
		
		if(num>=3) return true;
		else return false;
	}
	
	 public int demens(int x,int y) {
	    	/**@REQUIRES:0<=x<=79 && 0<=y<=79;
	        *MODIFIES:None;
	        *@EFFECTS:
	       	*	   \result==x*80+y;
	        */
	    	
	    	return x*80+y;
	 }
	 
	 public synchronized int getLight(int x,int y) {
		 /**@REQUIRES:0<=x<=79 && 0<=y<=79;
	     *MODIFIES:None;
	     *@EFFECTS:
	     *	   \result==light[x][y];
	     * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();
	     */
		 
		 return light[x][y];
	 }
	 
	 public synchronized void updateLight() {
		 /**@REQUIRES:
		 *MODIFIES:\this.light;
		 *@EFFECTS:
		 *	   (\all int i,j;0<=i<79 && 0<=j<=79)==>light[i][j].changestate;
		 * @THREAD_REQUIRES:
         *      \locked(\this);
         * @THREAD_EFFECTS:
         *      \locked();
		 */
		 
		 int i,j;
		 
		 if(state==green) {
			 state=red;
			 for(i=0;i<80;i++) {
				 for(j=0;j<80;j++) {
					 if(light[i][j]==green) {
						 light[i][j]=red;
						 gui.SetLightStatus(new Point(i,j),red);
					 }
				 }
			 }
		 }
		 
		 else {
			 state=green;
			 for(i=0;i<80;i++) {
				 for(j=0;j<80;j++) {
					 if(light[i][j]==red) {
						 light[i][j]=green;
						 gui.SetLightStatus(new Point(i,j),green);
					 }
				 }
			 }
		 }
	 }
	 
	 public long getTime() {
		 /**@REQUIRES:
	     *MODIFIES:None;
	     *@EFFECTS:
	     *	   \result==lightTime;
	     */
		 
		 return lightTime;
	 }
}
