package taxi;

import java.util.List;
import java.util.ArrayList;

public class Test extends Thread{
	/*Overview:测试线程提供测试功能*/
	
	private Taxi [] taxi=new Taxi [100]; 
	private final static int stop=0;
	private final static int orderTaking=1;
	private final static int wait=2;
	private final static int serve=3;
	
	/**test线程无关，不需要写JSF repOK Overview*/
	
	
	public boolean repOK() {
        /** @REQUIRES:None;
        * @MODIFIES:None;
        * @EFFECTS:
        *      \result==true;
        */ 
 
      return true;
            
   }
	
	public Test(Taxi [] taxi) {
		this.taxi=taxi;
	}
	
    public List <Taxi> checktaxi(int state){
    	List <Taxi> out=new ArrayList <Taxi> ();
    	for(Taxi t:taxi) {
    		if(t.state()==state) out.add(t);
    	}
    	return out;
    }
	
	public void IDInformation(int i) {
		//您可以使用时可以通过输出来获得信息 System.out.println(taxi[i].checkstate());
		taxi[i].checkcoorDinate();
		taxi[i].checktime();
	}
	
	public void stateInformation(int state) {
		checktaxi(state);
	}
	
	public void run() {
		IDInformation(0);
		stateInformation(wait);//该方法返回一个List,您可以对该队列进行相关操作获得信息
	}
	
}
