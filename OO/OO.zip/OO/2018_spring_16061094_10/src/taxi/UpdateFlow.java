package taxi;

public class UpdateFlow extends Thread{
	/* @Overview:UpdateFlow类对流量进行更新 */
	
	private Map map;
	
	public boolean repOK() {
		/** @REQUIRES:None;
		 * @MODIFIES:None;
		 * @EFFECTS:
		 *      \result==!(map==null)&&
		 *      !(\all int i,j;0<=i<reqQueue.Len();queue.get(i)==null);
		 */ 
		if(map==null) return false;
		return true;        
	}
	
	public UpdateFlow(Map map) {
		/**@REQUIRES:map!=null;
		*@MODIFIES:\this.map;
		*@EFFECTS:
		*  		\this.map==map;	
		*/
		
		this.map=map;
	}
    
	
	public void run() {
		/**@REQUIRES:
	    *@MODIFIES:None;
	    *@EFFECTS:
	    *  		(System.currentTimeMillis()-time>=500)==>map.clearflow();
	    */
			
		
		long time;
		int flag=0;
		time=System.currentTimeMillis();
		
		while(true) {
			if(System.currentTimeMillis()-time>=500) {
				map.clearflow();
				time=System.currentTimeMillis();
			}
			
		}
	}
}
