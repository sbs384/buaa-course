package taxi;

public class UpdateLight extends Thread{
	/* @Overview:UpdateLight类对红绿灯地图进行更新 */
	
	private LightMap lightmap;
	private long lightTime;
	
	public boolean repOK() {
		/** @REQUIRES:None;
		 * @MODIFIES:None;
		 * @EFFECTS:
		 *      \result==!(map==null || lightTime<500 || lightTime>1000);
		 */ 
		if(lightmap==null || (lightTime<500 || lightTime>1000)) return false;
		return true;        
	}
	
	public UpdateLight(LightMap lightmap) {
		/**@REQUIRES:lightmap!=null;
		*@MODIFIES:
		*		\this.lightmap;
		*		\this.lightTime;
		*@EFFECTS:
		*  		\this.lightmap==lightmap;
		*  		\this.lightTime==lightTime;
		*/
				
		
		this.lightmap=lightmap;
		this.lightTime=lightmap.getTime();
	}
	
	
	public void run() {
		/**@REQUIRES:
		*@MODIFIES:None;
		*@EFFECTS:
		*  		(System.currentTimeMillis()-time>=lightTime)==>lightmap.updateLight();
		*/
				
		
		long time=System.currentTimeMillis();
		
		while(true) {
			if(System.currentTimeMillis()-time>=lightTime) {
				lightmap.updateLight();
				time=System.currentTimeMillis();
			}
			
		}
	}
	
}
