package taxi;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
      	*		initial all objects;
        */
		
		
		String str;
		TaxiGUI gui=new TaxiGUI();
		
		Map map=new Map (gui);
		if(!map.readfile("map.txt")) System.exit(1);
		
		ReqQueue reqQueue=new ReqQueue(gui); 
		
		Taxi [] taxiList=new Taxi [100];
	
		//
		RequestSimulator requestsimu=new RequestSimulator("requestsimulator",reqQueue,map);
		requestsimu.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		
		//
		Controller controller=new Controller("controller",map,reqQueue,taxiList);
		controller.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		//
		UpdateFlow upf=new UpdateFlow(map);
		upf.setUncaughtExceptionHandler(new ExceptionHandler());
		
		//
		Test test=new Test(taxiList);
		test.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		ArgsReader argsreader=new ArgsReader(map,taxiList,gui,reqQueue);
		
		try {	
			argsreader.read(args[1],controller,upf);
			requestsimu.start();
			
			//test在这里!!!
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Crash error!");
			}
			test.start();
			
			
		}catch(Exception e) {
			System.out.println("Crash error!");
		}
	}
	

}
