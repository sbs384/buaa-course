package taxi;

import java.util.ArrayList;
import java.util.List;
import java.awt.Point;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class ReqQueue {
	private List <Request> queue=new ArrayList <Request>();
	private TaxiGUI gui;
	private int reqID=0;
	
	public ReqQueue(TaxiGUI gui) {
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.gui;
        *@EFFECTS:
       	*		\this.gui=gui;			
        */
		
		this.gui=gui;
	}
	
	
	public synchronized void add(Request r) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:
       	*		\this.queue;
        *@EFFECTS:
      	*		!(r.depax()==r.destx() && r.depay()==r.desty()) && !queue.contains(r)==>queue.add(r); 				
        */
		
		if(!(r.depax()==r.destx() && r.depay()==r.desty())) {
			if(queue.size()==0) {
				queue.add(r); 
			    r.setID(reqID);
			    r.setOut(new File("log"+reqID+".txt"));
				//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().flush();
				++reqID;
				//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
			}
			else{
				if(!queue.contains(r)) {
					queue.add(r); 
					r.setID(reqID);
					r.setOut(new File("log"+reqID+".txt"));
					//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().flush();
					++reqID;
					//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
				}
				else System.out.println("#SAME!Invalid input!");
			}
		}
		else System.out.println("#ERROR!Invalid input!");
	}
	
	
	public synchronized void delete(int i) {
		/**@REQUIRES:0<=i<queue.Len();
        *@MODIFIES:
      	*		\this.queue;
        *@EFFECTS:
      	*		queue.remove(i);				
        */
		
		queue.remove(i);
	}
	
	public synchronized void listAdd(int i,int j) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         *          0<=j<queue.get(i).carReady.Len();
         * @MODIFIES:
         * 			queue.get(i).carReady;
         * @EFFECTS:
         * 			queue.get(i).carReady.add(j);				
         */
		
		queue.get(i).listAdd(j);
	}
	
	public synchronized int Len() {
		/*
         * @REQUIRES:None;
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.size();				
         */
		
		return queue.size();
	}
	
	public synchronized long time(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).time;				
         */
		
		return queue.get(i).time();
	}
	
	public synchronized int depax(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).depax;				
         */
		
		return queue.get(i).depax();
	}
	
	public synchronized int depay(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).depay;				
         */
		
		return queue.get(i).depay();
	}
	
	public synchronized int destx(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).dextx;				
         */
		
		return queue.get(i).destx();
	}
	
	public synchronized int desty(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).desty;				
         */
		
		return queue.get(i).desty();
	}
	
	public synchronized List <Integer> list(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).list;				
         */
		
		return queue.get(i).list();
	}
	
	public synchronized Request get(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i);				
         */
		
		return  queue.get(i);
	}
	
	public int reqID(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).reqID;				
         */
		
		return  queue.get(i).reqID();
	}
	
	public PrintWriter out(int i) {
		/*
         * @REQUIRES:
         * 			0<=i<queue.Len();
         * @MODIFIES:None;
         * @EFFECTS:
         * 			\result=queue.get(i).out;				
         */
		
		return queue.get(i).out();
	}

}

