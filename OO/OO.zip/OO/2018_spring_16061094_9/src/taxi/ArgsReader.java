package taxi;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.ArrayList;
import java.awt.Point;

public class ArgsReader {
	private Map map;
	private Taxi [] taxiList;
	private TaxiGUI gui;
	private ReqQueue reqQueue;

	public ArgsReader(Map map,Taxi [] taxiList,TaxiGUI gui,ReqQueue reqQueue) {
		/** @REQUIRES:
        *@MODIFIES:
        *	\this.map;
        *	\this.taxiList;
        *	\this.gui;
        *	\this.reqQueue;
        *@EFFECTS:
   		*	\this.map=map;
		*	\this.taxiList=taxiList;
		*	\this.gui=gui;
		*	\this.reqQueue=reqQueue;		
        */
		
		this.map=map;
		this.taxiList=taxiList;
		this.gui=gui;
		this.reqQueue=reqQueue;
	}
	
	public void read(String s,Controller controller,UpdateFlow upf) throws FileNotFoundException {
		/**@REQUIRES:
        *@MODIFIES:
      	*		\this.map;
       	*		\this.taxiList;
       	*		\this.reqQueue;
        *@EFFECTS:
       	*		读取file.txt文件
       	*		#map与end_map之间如果有合法文件则重新加载map
       	*		#flow与#end_flow之间如果有合法流量设置，则在相应边加载流量
        *       #taxi与end_taxi之间若有出租车状态设置，则设置相应出租车状态
        *       #request与end_request之间若有请求，则响应相应请求				
        */
		
		
		String str;
		int i,x1,y1,x2,y2,value,id,state,credit;
		int [] ID=new int [100];
		for(i=0;i<100;i++) ID[i]=0;
		
		
		if(!new File(s).exists()) {
			System.out.println("Can't find the test file!");
			System.exit(1);
		}
		
		if(!new File(s).isFile()) {
			System.out.println("Can't find the test file!");
			System.exit(1);
		}
		
		InputStream input = new FileInputStream(new File(s));
        InputStreamReader reader = new InputStreamReader(input);
        BufferedReader buff = new BufferedReader(reader);
        
        try {
        	while((str=buff.readLine())!=null) {
        		if(str.equals("#map")) {
        			str=buff.readLine();
        			if(!str.equals("#end_map")) {
        				if(!map.readfile(str)) {
        					System.out.println("Invalid map of file.txt!");
        					System.exit(1);
        				};
        				gui.LoadMap(map.getMap(),80);
        			}
        			else gui.LoadMap(map.getMap(),80);
        		}
        		
        		else if(str.equals("#flow")) {
        			while(!(str=buff.readLine()).equals("#end_flow")) {
        				String string[]=str.split(" ");
        				String string1[]=string[0].split(",");
        				x1=Integer.parseInt(string1[0].replaceAll("\\(", ""));
        				y1=Integer.parseInt(string1[1].replaceAll("\\)", ""));
        				
        				String string2[]=string[1].split(",");
        				x2=Integer.parseInt(string2[0].replaceAll("\\(", ""));
        				//System.out.println(string2[1]);
        				y2=Integer.parseInt(string2[1].replaceAll("\\)", ""));
        				
        				value=Integer.parseInt(string[2]);
        				
        				map.setflow(x1,y1,x2,y2,value);
        			}
        		}
        		
        		else if(str.equals("#taxi")) {
        			while(!(str=buff.readLine()).equals("#end_taxi")) {
        				String string[]=str.split(" ");
        				id=Integer.parseInt(string[0]);
        				state=Integer.parseInt(string[1]);
        				credit=Integer.parseInt(string[2]);
        				
        				String string1[]=string[3].split(",");
        				x1=Integer.parseInt(string1[0].replaceAll("\\(", ""));
        				y1=Integer.parseInt(string1[1].replaceAll("\\)", ""));
        				
        				ID[id]=1;
        				taxiList[id]=new Taxi("taxi"+id,id,gui,map,state,new Point(x1,y1),credit);
        				taxiList[id].setUncaughtExceptionHandler(new ExceptionHandler()); 
        				//System.out.println(id);
        				taxiList[id].start();
        			}
        			
        			for(int k=0;k<100;k++) {
        				if(ID[k]!=1) {
        					//System.out.println(k+";"+ID[k]);
        					taxiList[k]=new Taxi("taxi"+k,k,gui,map);
        					taxiList[k].setUncaughtExceptionHandler(new ExceptionHandler()); 
        					taxiList[k].start();
        				}
        			}
        			
        			
        			controller.start();
            		upf.start();
        		}
        		
        		
        		else if(str.equals("#request")) {
        			while(!(str=buff.readLine()).equals("#end_request")) {
        				long time=System.currentTimeMillis();
        				time=time/100*100;
        				try {
    						reqQueue.add(new Request(str,time));
    					} catch (FileNotFoundException e) {
    						e.printStackTrace();
    					}
        			}
  
        		}
        	}
        	
        }catch(Exception e) {
        	System.out.println("Crash error!");
        }
	}
}


