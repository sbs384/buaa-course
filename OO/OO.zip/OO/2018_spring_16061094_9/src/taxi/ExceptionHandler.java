package taxi;

public class ExceptionHandler implements Thread.UncaughtExceptionHandler{
	public void uncaughtException(Thread t, Throwable e) {  
		/** @REQUIRES:
        *@MODIFIES:None;
        *@EFFECTS:
   		*	exceptional_behavior(Exception);
        */
		
		System.out.println("Crash error!");
    } 
}
