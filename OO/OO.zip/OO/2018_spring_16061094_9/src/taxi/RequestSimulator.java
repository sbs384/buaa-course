package taxi;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class RequestSimulator extends Thread{
		private ReqQueue reqQueue;
		private Map map;
		public RequestSimulator(String name,ReqQueue reqQueue,Map map) {
			/**@REQUIRES:
	        *@MODIFIES:
	       	*		\this.name;
	       	*		\this.reqQueue;
	       	*		\this.map=map;
	        *@EFFECTS:
	      	*		\this.name=name;
	      	*		\this.reqQueue=reqQueue;
	      	*		\this.map=map;
	        */
			
			super(name);
			this.reqQueue=reqQueue;
			this.map=map;
		}
		
		public void run() {
			/**@REQUIRES:
	        *@MODIFIES:
	       	*		\this.reQueue;
	       	*		\this.map;
	        *@EFFECTS:
	      	*		add the request in requestQueue;
	      	*		open the according road;
	        *       close the according road;
	        */
			
			long time;
			Scanner keyboard=new Scanner(System.in);
			String input=keyboard.nextLine();
			time=(System.currentTimeMillis()/100)*100;
			
			if(input.equals("END")) {
				System.out.println("#ERROR!No request!Please run again!");
				System.exit(1);
			}
			
			while(!input.equals("END")) {
			 	input=input.replaceAll("\\s+","");
				
				if(judgeInput(input)==0)
					try {
						reqQueue.add(new Request(input,time));
					} catch (FileNotFoundException e) {
						System.out.println("Crash error!");
					}
				
				else if(judgeInput(input)==1) map.open(input);
				else if(judgeInput(input)==2) map.close(input);
				else System.out.println("#ERROR!Invalid request!");
				
				input=keyboard.nextLine();
				time=(System.currentTimeMillis()/100)*100;
			}
			
			keyboard.close();
			yield();
		}
		
		//格式匹配
		public int judgeInput(String s) {
			/**@REQUIRES:
	        *@MODIFIES:None;
	        *@EFFECTS:
	       	*		s.matches(regex1)==>\result=0;
	       	*		s.matches(regex2)==>\result=1;
	      	*		s.matches(regex3)==>\result=2;
	      	*		!s.matches(regex1) && !s.matches(regex2) && !s.matches(regex3)==>\result=-1;
	        */
			
			String regex1="^\\[CR,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			String regex2="^\\[OP,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			String regex3="^\\[CP,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			if(s.matches(regex1)) return 0;
			else if(s.matches(regex2)) return 1;
			else if(s.matches(regex3)) return 2;
			else return -1;	
		} 
		
	}



