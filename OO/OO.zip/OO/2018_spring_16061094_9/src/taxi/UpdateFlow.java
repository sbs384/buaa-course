package taxi;

public class UpdateFlow extends Thread{
	private Map map;
	
	public UpdateFlow(Map map) {
		this.map=map;
	}
    
	
	public void run() {
		/**@REQUIRES:
	        *@MODIFIES:None;
	        *@EFFECTS:
	      			(System.currentTimeMillis()-time==500)==>map.clearflow();
	        */
			
		
		long time;
		int flag=0;
		time=System.currentTimeMillis();
		
		while(true) {
			/*if(flag==0) {
				if(System.currentTimeMillis()-time==450) {
					map.clearflow();
					time=System.currentTimeMillis();
					flag=1;
				}
			}
			else {
				if(System.currentTimeMillis()-time==500) {
					map.clearflow();
					time=System.currentTimeMillis();
				}
			}*/
			if(System.currentTimeMillis()-time>=500) {
				map.clearflow();
				time=System.currentTimeMillis();
			}
			
		}
	}
}
