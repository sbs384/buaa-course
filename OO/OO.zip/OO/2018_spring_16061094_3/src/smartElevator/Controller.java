package smartElevator;
 
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Controller extends Control {

	public Controller() {
		
	}
	
	
	//普通方法 
	public void deal(QueueReq Queue,Elevator e) {
		 List <Request> res=new ArrayList <Request>();
		 List <Request> queue=new ArrayList <Request>();
		 int i=0;
		 queue=Queue.queOut();
		 
		 while(queue.size()!=0) {
			 control(queue,(Request)queue.get(0),e,0);
			 res=e.curMDone(); 
			 if(res!=null) {
				 for(i=res.size()-1;i>=0;i--) queue.add(0,res.get(i));
				 for(i=res.size()-1;i>=0;i--) res.remove(i);
			 }
		 }
		 System.exit(0);
		 
	}
	

	public int control(List <Request>queue,Request r,Elevator e,int i) {
		if(schedule(r,e)==0) {
			queue.remove(r);
			printSame(r);
			if(queue.size()!=0 && i!=queue.size()){
				r=(Request)queue.get(i);
				control(queue,r,e,i);
			}
		}
		
		else if(schedule(r,e)==1) {
			if(i!=queue.size()-1){
				r=(Request)queue.get(++i);
				control(queue,r,e,i);
			}
			else return 0;
		}
		
		else{
			if(e.MainExist()) {
				if(e.ByWay(r)) {
					queue.remove(r);
					if(queue.size()!=0  && i!=queue.size()){
						r=(Request)queue.get(i);
						control(queue,r,e,i);
					}
					else return 0;
				}
				else {
					if(i!=queue.size()-1){
						r=(Request)queue.get(++i);
						control(queue,r,e,i);
					}
					else return 0;
				}
			}
			
			else {
				e.Main(r);
				queue.remove(r);
				if(queue.size()!=0  && i!=queue.size()){
					r=(Request)queue.get(i);
					control(queue,r,e,i);
				}
				else return 0;
			}
		}
		
		return 0;
		
	}   
	
	public void printSame(Request r) {
		System.out.print("#SAME");
		if(r.ask()==1)        System.out.println("["+"FR"+","+r.floor()+","+"UP"+","+r.time()+"]");
		else if(r.ask()==2)   System.out.println("["+"FR"+","+r.floor()+","+"DOWN"+","+r.time()+"]");
		else                  System.out.println("["+"ER"+","+r.floor()+","+r.time()+"]");
	}
	
	
	public int schedule(Request r,Elevator e) {
		BigDecimal limitTime;
		//0 是同质请求；1 跳过；2 不是同志质请求
		if(e.findCom(r)) {
			limitTime=e.limitCom(r);
			if(r.time().compareTo(limitTime)==0) return 0;
			else if (r.time().compareTo(limitTime)==-1) return 0;
			else {
				if(e.findSet(r)) return 1;
				else return 2;
			}
		}
		
		else {
			if(e.findSet(r)) return 1;
			else return 2;
		}
		
	}

}
