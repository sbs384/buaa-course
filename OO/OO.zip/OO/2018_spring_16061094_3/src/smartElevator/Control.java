package smartElevator;
import java.math.BigDecimal;
 
public class Control {
	
	//普通方法
	//schedule方法判断当前请求是否为可调度请求，即不是前面某个请求的同质请求
	public int schedule(Request r,Elevator e) {  
		BigDecimal limitTime;
		if(e.findCom(r)) {
			limitTime=e.limitCom(r);
			if(r.time().compareTo(limitTime)==1) return 1;
			else return 0;
		} 
		else return 1;
	}
	
}
  