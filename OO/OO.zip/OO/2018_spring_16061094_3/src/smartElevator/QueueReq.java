package smartElevator;
import java.util.List;
import java.util.ArrayList;
import java.math.BigDecimal;
 
public class QueueReq{
     private List <Request> queEfficient=new ArrayList <Request>();
     
  
     //普通方法
     //管理队列，第一个命令请求时间不为零(return 1)去除降序(return2)
     public int manage(Request r) {
    	 int last;
    	 BigDecimal zero=new BigDecimal("0");
    	 //如果当前为第一个请求，则判断其请求时间是否合法
    	 if(queEfficient.size()==0) {
    		 if((r.time().compareTo(zero)==0) && (r.floor()==1) && (r.ask()==1)) {
    			 queEfficient.add(r);
    			 r.setOrder(queEfficient.size()-1);
    			 return 0; 
    		 }
    		 else return 1;
    	 }
    	 else {
    		last=queEfficient.size();
    		Request rLast=(Request)queEfficient.get(last-1);
    		if(r.time().compareTo(rLast.time())==-1) return 1;
    		else if(r.time().compareTo(rLast.time())==0) {
    		    queEfficient.add(r);
    		    r.setOrder(queEfficient.size()-1);
    			return 0;
    		}
    		else {
    			queEfficient.add(r);
    			r.setOrder(queEfficient.size()-1);
    			return 0;
    		}
    	 }
     }
     
        
     //反馈队列长度
     public int Len() {
       	 return queEfficient.size();
     }
     
     
     //反馈当前请求   
     public Request curReq(int i) {
    	 Request r=(Request)queEfficient.get(i);
    	 return r;
     }
     
     
     public List <Request> queOut() {
    	 return queEfficient;
     }

     
    
}
