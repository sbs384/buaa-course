package taxi;

import java.io.FileNotFoundException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Map map=new Map ();
		TaxiGUI gui=new TaxiGUI();
		ReqQueue reqQueue=new ReqQueue(gui); 
		
		//
		RequestSimulator requestsimu=new RequestSimulator("requestsimulator",reqQueue);
		requestsimu.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		//
		Taxi [] taxiList=new Taxi [100];
		for(int i=0;i<100;i++) {
			taxiList[i]=new Taxi("taxi"+i,i,gui,map.getMap());
			taxiList[i].setUncaughtExceptionHandler(new ExceptionHandler()); 
		}
		
		//
		Controller controller=new Controller("controller",map.getMap(),reqQueue,taxiList);
		controller.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		//
		Test test=new Test(taxiList);
		test.setUncaughtExceptionHandler(new ExceptionHandler()); 
		
		
		try {
			if(!map.readfile("map.txt")) System.exit(1);
			
			else {
				gui.LoadMap(map.getMap(),80);
				
				requestsimu.start();
				controller.start();
				for(int i=0;i<100;i++) taxiList[i].start();
			}
			
			//test在这里!!!
			test.start();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	

}
