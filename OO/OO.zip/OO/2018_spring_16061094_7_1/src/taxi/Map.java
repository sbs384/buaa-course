package taxi;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Map {
	private int map[][]=new int [82][82];
	
	public boolean readfile(String path) throws FileNotFoundException {   
		int i=0;
		String str;
		if(!new File(path).exists()) {
			error();
			System.exit(1);
		}
		
		if(!new File(path).isFile()) {
			error();
			System.exit(1);
		}
		
        InputStream input = new FileInputStream(new File(path));
        InputStreamReader reader = new InputStreamReader(input);
        BufferedReader buff = new BufferedReader(reader);
        
        try {
        	while((str=buff.readLine())!=null) {
        		if(i==80) {
        			error();
        			return false;
        		}
        		
        		else {
        			str=str.replaceAll("\\s+","");
        			
        			if(str.length()!=80) {
        				error();
        				return false;
        			}
        			else {
        				for(int k=0;k<str.length();k++) {
        					char x=str.charAt(k);
        					if((x-'0')>=0 && (x-'0')<=3) map[i][k]=x-'0';
        					else{
        						error();
        						return false;
        					}
        				}
        			}
        		}
        		
        		++i;
        	}
        	
        	return true;
        	
        }catch(Exception e) {
        	e.printStackTrace();
        	return false;
        }
	}
	
	public int[][] getMap(){
		return map;
	}
	
	public void error() {
		System.out.println("Invalid map file!");
	}
}
