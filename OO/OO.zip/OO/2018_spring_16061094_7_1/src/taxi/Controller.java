package taxi;

import java.awt.Point;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
 
public class Controller extends Thread{
    private final static int infinite=40000000;
	private int [][] map=new int [82][82];
	private ReqQueue queue;
	private int chosen;
	private int dist[][]=new int [82][82];
	private boolean visit [][]=new boolean [82][82];
	private Queue <Point> distqueue=new LinkedList <Point> ();
	private Taxi [] taxiList=new Taxi [100];
	private boolean stopMe=true;
	
	private final static int stop=0;
	private final static int orderTaking=1;
	private final static int wait=2;
	private final static int serve=3;

	public Controller(String name,int [][] map,ReqQueue queue,Taxi [] taxiList) {
		super(name);
		this.queue=queue;
		this.taxiList=taxiList;
		this.map=map;
	}
 
	public void run() {
		int i,flag=0,distMin=0,distTemp;
		long curTime;
		try {
		while(stopMe) {
			curTime=System.currentTimeMillis();
			
			//当前时间是否在窗口期内
			while(queue.Len()!=0 && curTime>=queue.time(0)+3000) {
				SPFA(queue.depax(0),queue.depay(0));
				
				//对已抢单出租车进行比较
				for(int k: queue.list(0)) {
					queue.out(0).println("#Taxi"+taxiList[k].ID()+" take:CurCoordinate：("+taxiList[k].curx()+","+taxiList[k].cury()+")"+"; CurState:"+taxiList[k].state()+"; credit:"+taxiList[k].credit());
					queue.out(0).flush();
					
					if(taxiList[k].state()==wait) {
						if(flag==0) {
							distMin=dist[taxiList[k].curx()][taxiList[k].cury()];
							chosen=k;
							flag=1;
						}
						else {
							distTemp=dist[taxiList[k].curx()][taxiList[k].cury()];
							if(taxiList[k].credit()>taxiList[chosen].credit()) {
								distMin=distTemp;
								chosen=k;
							}
							else if (taxiList[k].credit()==taxiList[chosen].credit()) {
								if(distTemp<distMin) {
									distMin=distTemp;
									chosen=k;
								}
							}
						}
					}
				}
				
				
						//对被选中的出租车进行分单
						if(flag==0) {
							//System.out.println("Request"+queue.reqID(0)+" failed!");
							queue.out(0).print("Request"+queue.reqID(0)+" failed!");
							queue.out(0).flush();
							queue.delete(0);
						}
						else {
							//System.out.print("#出租车"+taxiList[chosen].ID()+"被派单:");
							//System.out.println("被派单时坐标:("+taxiList[chosen].curx()+","+taxiList[chosen].curx()+"); 被派单时刻:"+(queue.time(0)+3000));
							if(taxiList[chosen].state()==2) {
								taxiList[chosen].setOrder(queue.get(0),new Point(queue.depax(0),queue.depay(0)),new Point(queue.destx(0),queue.desty(0)));
								queue.out(0).print("#Taxi"+taxiList[chosen].ID()+" ordered:");
								queue.out(0).flush();
								queue.out(0).println("CurCoordinate:("+taxiList[chosen].curx()+","+taxiList[chosen].cury()+"); curTime:"+System.currentTimeMillis());
								queue.out(0).flush();
								queue.delete(0);
								flag=0;
							}
							else {
								queue.out(0).print("Request"+queue.reqID(0)+" failed!");
								queue.out(0).flush();
								queue.delete(0);
								flag=0;
							}
						}
				
			}
			
			//否则进行扫描
			for(i=0;i<queue.Len();i++) {
				//对100辆出租进行扫描
				for(int j=0;j<100;j++) {
					if(Math.abs(taxiList[j].curx()-queue.depax(i))<=2 && Math.abs(taxiList[j].cury()-queue.depay(i))<=2 && taxiList[j].state()==wait) {
						if(!queue.list(i).contains(j)) {
							queue.listAdd(i,j);
							taxiList[j].creditAdd(1);
							//System.out.println("请求"+queue.reqID(i)+":");
							//System.out.println("抢单的出租车：车号:"+taxiList[j].ID()+"; 当前位置：("+taxiList[j].curx()+","+taxiList[j].cury()+")"+"; 当前状态:"+taxiList[j].state()+"; 信用信息:"+taxiList[j].credit());
							//queue.out(i).println("#请求"+queue.reqID(i)+":");
						}
					}
				}	
			}
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
}
	
	
	public void SPFA(int x,int y) {
		distqueue.clear();
		for(int i=0;i<82;i++) {
			for(int j=0;j<82;j++) {
				dist[i][j]=infinite;
				visit[i][j]=false;
			}
		}
		
		dist[x][y] = 0;
		distqueue.offer(new Point(x,y));
		visit[x][y]=true;
		
		while (!distqueue.isEmpty()){
			int x1= (int)(distqueue.peek().getX());
			int y1= (int)(distqueue.poll().getY());
			visit[x1][y1]=false;
			
			if(map[x1][y1]==1 || map[x1][y1]==3) {//right
				lax(x1,y1,x1+1,y1);
			}
			if(x1-1>=0 && (map[x1-1][y1]==1 || map[x1-1][y1]==3)) {//left
				lax(x1,y1,x1-1,y1);
			}
			if(y1-1>=0 && (map[x1][y1-1]==2 || map[x1][y1-1]==3)) {//up
				lax(x1,y1,x1,y1-1);
			}
			if((map[x1][y1]==2 || map[x1][y1]==3)) {//down
				lax(x1,y1,x1,y1+1);
			}
		}
	}
	
    public void lax(int x,int y,int xnew,int ynew) {
    	if(dist[xnew][ynew]>dist[x][y]+1) {
    		dist[xnew][ynew]=dist[x][y]+1;
    		if(!visit[xnew][ynew]) {
    			distqueue.offer(new Point(xnew,ynew));
    			visit[xnew][ynew]=true;
    		}
    	}
    }
    
    
}
