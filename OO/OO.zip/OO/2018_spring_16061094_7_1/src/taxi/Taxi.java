package taxi;

import java.util.Random;
import java.awt.Point;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;


public class Taxi extends Thread {
	private final static int infinite=40000000;
	private int ID;
	private int curx;
	private int cury;
	private int state;
	private int credit=0;
	private long waitStartTime;
	private int reqID;
	private int depax;
	private int depay;
	private int destx;
	private int desty;
	private TaxiGUI gui;
	private int orderflag=0;
	private int serveflag=0;
	private long curTime;
	private int map[][]=new int [82][82];
	private boolean stopMe=true;
	private Request request;
	private int dist[][]=new int [82][82];
	private boolean visit [][]=new boolean [82][82];
	private Queue <Point> distqueue=new LinkedList <Point> ();
	private Point [][] ahead=new Point [82][82];
	
	private final static int stop=0;
	private final static int orderTaking=1;
	private final static int wait=2;
	private final static int serve=3;
	
	public Taxi(String name,int ID,TaxiGUI gui,int map [][]) {
		this.ID=ID;
		initialCoordinate();
		state=wait;
		this.gui=gui;
		this.map=map;
		this.waitStartTime=System.currentTimeMillis();
		gui.SetTaxiStatus(ID,new Point(curx,cury),state);
	}
	
	public void run() {
		while(stopMe) {
			int curState=state();
			
			//orderTaking状态
			if(curState==orderTaking) {
				if(orderflag==0) {
					curTime=System.currentTimeMillis();
					orderflag=1;
					request.out().println("-----------------------------------pathOrder-----------------------------------");
					request.out().flush();
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
				}
				if(curx==depax && cury==depay) {
					//System.out.println("到达乘客位置的时刻:"+curTime);
					//System.out.println("到达乘客位置坐标:("+curx()+","+cury()+")");
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),stop);
					try {
						sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					setServe(destx,desty);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
					curTime+=1000;
					orderflag=0;
				}
				
				else {
					try {
						sleep(200);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					curTime+=200;
					//System.out.println("order:"+curx+";"+cury);
					setCoordinate(ahead[curx][cury]);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
					
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
					if(curx==depax && cury==depay) {
						request.out().println("OrderDestTime:"+curTime+"  OrderDestCoordinate:("+curx()+","+cury()+")");
						request.out().flush();
					}
					
				}
			}
			
			//wait状态
			else if(curState==wait) {
				if(waitStartTime+20000<=System.currentTimeMillis()) {
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					try {
						sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if(state()!=orderTaking) {
					setState(wait);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					waitStartTime=System.currentTimeMillis();
					}
				}
				
				else {
					try {
						sleep(200);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					randomCoordinate(curx,cury);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
				}
			}
			
			//serve状态
			else if(curState==serve) {
				if(serveflag==0) {
					request.out().println("-----------------------------------pathServe-----------------------------------");
					request.out().flush();
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
					serveflag=1;
				}
				if(curx==destx &&cury==desty) {
					//System.out.println("服务成功啦:"+curx+";"+cury);
					creditAdd(3);
					setState(stop);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					try {
						sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					serveflag=0;
					setState(wait);
					waitStartTime=System.currentTimeMillis();
					gui.SetTaxiStatus(ID,new Point(curx,cury),state);
				}
				
				else {
					try {
						sleep(200);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					//System.out.println("serve:"+curx+";"+cury);
					setCoordinate(ahead[curx][cury]);
					gui.SetTaxiStatus(ID,new Point(curx,cury),state());
					curTime+=200;

					//System.out.println("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().print("currentTime:"+curTime+"  ("+curx()+","+cury()+")-->");
					request.out().flush();
					if(curx==destx && cury==desty) {
						//System.out.println("ServeDestTime:"+curTime+"  ServeDestCoordinate:("+curx()+","+cury()+")");
						request.out().print("\n");
						request.out().flush();
						request.out().println("ServeDestTime:"+curTime+"  ServeDestCoordinate:("+curx()+","+cury()+")");
						request.out().flush();
						request.out().println("The request is ended successfully!");
						request.out().flush();
					}
					
			}
		}
	}
}
	
	
	public void initialCoordinate() {
		Random rand=new Random();
		curx=rand.nextInt(80);
		cury=rand.nextInt(80);
	}

	
	public synchronized void randomCoordinate(int x,int y) {
		int randindex;
		List <Integer> existDirection=new ArrayList <Integer>();
		if(map[x][y]==1 || map[x][y]==3) {//right
			existDirection.add(0);
		}
		if(x-1>=0 && (map[x-1][y]==1 || map[x-1][y]==3)) {//left
			existDirection.add(1);
		}
		if(y-1>=0 && (map[x][y-1]==2 || map[x][y-1]==3)) {//up
			existDirection.add(2);
		}
		if((map[x][y]==2 || map[x][y]==3)) {//down
			existDirection.add(3);
		}
		
		Random rand=new Random();
		randindex=existDirection.get(rand.nextInt(existDirection.size()));
		if(randindex==0) {
			curx=x+1;
			cury=y;
		}
		else if(randindex==1) {
			curx=x-1;
			cury=y;
		}
		else if(randindex==2) {
			curx=x;
			cury=y-1;
		}
		else {
			curx=x;
			cury=y+1;
		}
		
		existDirection.clear();
	}

	
	public synchronized int state() {
		return state;
	}	
	
	
	public synchronized void setState(int i) {
		state=i;
	}
	
	public synchronized int credit() {
		return credit;
	}	
	
	
	public synchronized void creditAdd(int i) {
		if(i==1) credit+=1;
		else  credit+=3;
	}
	
	public synchronized void setOrder(Request r,Point depa,Point dest) {
		state=orderTaking;
		gui.SetTaxiStatus(ID,new Point(curx,cury),state());
		depax=(int)(depa.getX());
		depay=(int)(depa.getY());
		//System.out.println("depa:"+depax+";"+depay);
		SPFA((int)(depa.getX()),(int)(depa.getY()));
		reqID=r.reqID();
		request=r;
		destx=(int)(dest.getX());
		desty=(int)(dest.getY());
	}
	
	public synchronized void setServe(int x,int y) {
		state=serve;
		gui.SetTaxiStatus(ID,new Point(curx,cury),state());
		SPFA(x,y);
	}
	
	public synchronized int curx() {
		return curx;
	}
	
	public synchronized int cury() {
		return cury;
	}
	
	
	public synchronized int ID() {
		return ID;
	}
	
	public void SPFA(int x,int y) {
	    distqueue.clear();
		for(int i=0;i<82;i++) {
			for(int j=0;j<82;j++) {
				dist[i][j]=infinite;
				visit[i][j]=false;
			}
		}
		
		dist[x][y] = 0;
		visit[x][y]=true;
		ahead[x][y]=new Point(x,y);
		distqueue.offer(new Point(x,y));
		
		while (!distqueue.isEmpty()){
			int x1= (int)(distqueue.peek().getX());
			int y1= (int)(distqueue.poll().getY());
			visit[x1][y1]=false;
			
			if(map[x1][y1]==1 || map[x1][y1]==3) {//right
				lax(x1,y1,x1+1,y1);
			}
			if(x1-1>=0 && (map[x1-1][y1]==1 || map[x1-1][y1]==3)) {//left
				lax(x1,y1,x1-1,y1);
			}
			if(y1-1>=0 && (map[x1][y1-1]==2 || map[x1][y1-1]==3)) {//up
				lax(x1,y1,x1,y1-1);
			}
			if((map[x1][y1]==2 || map[x1][y1]==3)) {//down
				lax(x1,y1,x1,y1+1);
			}
		}
	}
	
    public void lax(int x,int y,int xnew,int ynew) {
    	if(dist[xnew][ynew]>dist[x][y]+1) {
    		dist[xnew][ynew]=dist[x][y]+1;
    		ahead[xnew][ynew]=new Point(x,y);
    		if(!visit[xnew][ynew]) {
    			distqueue.offer(new Point(xnew,ynew));
    			visit[xnew][ynew]=true;
    		}
    	}
    }
    
    public synchronized void setCoordinate(Point point) {
    	curx=(int)(point.getX());
        cury=(int)(point.getY());
    }
	
    //接口函数
    //指定id出租车的相关信息
    public  int checkstate() {
    	return  state();
    }
    
    public  Point checkcoorDinate() {
    	return new Point(curx(),cury());
    }
   
    
    public long checktime() {
    	return System.currentTimeMillis();
    }
    
}

