package taxi;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class RequestSimulator extends Thread{
		private ReqQueue reqQueue;
		public RequestSimulator(String name,ReqQueue reqQueue) {
			super(name);
			this.reqQueue=reqQueue;
		}
		
		public void run() {
			long time;
			Scanner keyboard=new Scanner(System.in);
			String input=keyboard.nextLine();
			//time=(System.currentTimeMillis()/100)*100;
			//System.out.println("RequestTime:");
			//System.out.println(time=System.currentTimeMillis());
			time=(System.currentTimeMillis()/100)*100;
			//time=(time/100)*100;
			
			if(input.equals("END")) {
				System.out.println("#ERROR!No request!Please run again!");
				System.exit(1);
			}
			
			while(!input.equals("END")) {
			 	input=input.replaceAll("\\s+","");
				
				if(judgeInput(input))
					try {
						reqQueue.add(new Request(input,time));
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				else System.out.println("#ERROR!Invalid request!");
				
				input=keyboard.nextLine();
				//System.out.println("RequestTime:");
				//System.out.println(time=System.currentTimeMillis());
				time=(System.currentTimeMillis()/100)*100;
				//time=(time/100)*100;
			}
			
			keyboard.close();
			yield();
		}
		
		//格式匹配
		public boolean judgeInput(String s) {
			String regex="^\\[CR,\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\),\\(([0-9]|[1-7][0-9]),([0-9]|[1-7][0-9])\\)\\]$";
			if(!s.matches(regex)) return false; 
			else return true;	
		} 
		
	}



