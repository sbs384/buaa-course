package taxi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.List;

import java.util.ArrayList;


public class Request {
	private int depax;
	private int depay;
	private int destx;
	private int desty;
	private long time;
	private int reqID;
	private PrintWriter out;
	private List <Integer> carReady=new ArrayList <Integer> ();
	

    public Request(String s,long time) {
    	try {
		String [] str=s.split(",");
		
		depax=Integer.parseInt(str[1].replaceAll("\\(",""));
		depay=Integer.parseInt(str[2].replaceAll("\\)",""));
		destx=Integer.parseInt(str[3].replaceAll("\\(",""));
		str[4]=str[4].replaceAll("\\)","");
		desty=Integer.parseInt(str[4].replaceAll("\\]",""));
		
		this.time=time;
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
	}
	
	public void listAdd(int j) {
		carReady.add(j);
	}
	
	public long time() {
		return time;
	}
	
	public int depax() {
		return depax;
	}
	
	public int depay() {
		return depay;
	}
	
	public int destx() {
		return destx;
	}
	
	public int desty() {
		return desty;
	}
	
	public List <Integer> list() {
		return carReady;
	}
	
	public void setID(int reqID) {
		this.reqID=reqID;
	}
	
	public int reqID() {
		return reqID;
	}
	
	public void setOut(File file) throws FileNotFoundException{
		this.out=new PrintWriter(file);
	}
	
	public PrintWriter out() {
		return out;
	}
	
	//重写方法
	   @Override
		public boolean equals(Object obj) {
			if(this==obj) return true;
			if(obj==null) return false;
			if(!(obj instanceof Request)) return false;
			Request request=(Request)obj;
			if(this.depax==request.depax && this.depay==request.depay && this.destx==request.destx && this.desty==request.desty && this.time==request.time) {
				return true;
			}
			else return false;
	   }
}
