package taxi;

import java.util.ArrayList;
import java.util.List;
import java.awt.Point;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class ReqQueue {
	private List <Request> queue=new ArrayList <Request>();
	private TaxiGUI gui;
	private int reqID=0;
	
	public ReqQueue(TaxiGUI gui) {
		this.gui=gui;
	}
	
	
	public synchronized void add(Request r) throws FileNotFoundException {
		if(!(r.depax()==r.destx() && r.depay()==r.desty())) {
			if(queue.size()==0) {
				queue.add(r); 
			    r.setID(reqID);
			    r.setOut(new File("log"+reqID+".txt"));
				//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
				r.out().flush();
				++reqID;
				//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
			}
			else{
				if(!queue.contains(r)) {
					queue.add(r); 
					r.setID(reqID);
					r.setOut(new File("log"+reqID+".txt"));
					//System.out.println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().println("#Request"+reqID+":Time:"+r.time()+"; StartCoordinate:("+r.depax()+","+r.depay()+")"+"; DestCoordinate:("+r.destx()+","+r.desty()+")");
					r.out().flush();
					++reqID;
					//gui.RequestTaxi(new Point(r.depax(),r.depay()),new Point(r.destx(),r.desty()));
				}
				else System.out.println("#SAME!Invalid input!");
			}
		}
		else System.out.println("#ERROR!Invalid input!");
	}
	
	
	public synchronized void delete(int i) {
		queue.remove(i);
	}
	
	public synchronized void listAdd(int i,int j) {
		queue.get(i).listAdd(j);
	}
	
	public synchronized int Len() {
		return queue.size();
	}
	
	public synchronized long time(int i) {
		return queue.get(i).time();
	}
	
	public synchronized int depax(int i) {
		return queue.get(i).depax();
	}
	
	public synchronized int depay(int i) {
		return queue.get(i).depay();
	}
	
	public synchronized int destx(int i) {
		return queue.get(i).destx();
	}
	
	public synchronized int desty(int i) {
		return queue.get(i).desty();
	}
	
	public synchronized List <Integer> list(int i) {
		return queue.get(i).list();
	}
	
	public synchronized Request get(int i) {
		return  queue.get(i);
	}
	
	public int reqID(int i) {
		return  queue.get(i).reqID();
	}
	
	public PrintWriter out(int i) {
		return queue.get(i).out();
	}

}

