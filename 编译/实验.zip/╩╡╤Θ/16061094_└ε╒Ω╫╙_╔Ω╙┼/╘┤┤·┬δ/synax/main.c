#include <stdio.h>
#include <stdarg.h>
#include "lexcical.h"
#include "error.h"
#include "global.h"
#include "synax.h"
#include "midcode.h"
#include "optimize.h"
//#include "mipsnew.h"
#include "mips.h"


int main(){
    char filename[50];
    scanf("%s",filename);
    if((outg=fopen("grammar.txt","w"))==NULL){
        printf("The file can't be opened!");
        exit(1);
    }
     if((pin=fopen(filename,"r"))==NULL){
        printf("The file in can't be opened!\n");
        exit(1);
    }
    if((poutv=fopen("lexic.txt","w"))==NULL){
        printf("The file out can't be opened!\n");
        exit(1);
    }
    if((poute=fopen("error.txt","w"))==NULL){
        printf("The file error can't be opened!\n");
        exit(1);
    }
    if((poutm=fopen("mips.txt","w"))==NULL){
        printf("The file error can't be opened!\n");
        exit(1);
    }
    //if((poutmnew=fopen("mipsnew.txt","w"))==NULL){
        //printf("The file error can't be opened!\n");
        //exit(1);
    //}


    fputs("Number   MemoryWord     Value\n",poutv);

    getch();
    insymbol();

    program();
    if(errorsign==0){
        printfcode();
        constFolding();
        genmips();
        printftTab();
        printfgfTab();
    }
    else printf("error!\n");

    fclose(pin);
    fclose(poutv);
    fclose(poute);
    fclose(outg);

    return 0;
}
