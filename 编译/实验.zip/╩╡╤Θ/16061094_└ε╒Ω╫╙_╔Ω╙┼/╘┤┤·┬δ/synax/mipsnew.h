#ifndef _MIPSNEW_H_
#define _MIPSNEW_H_
#include <stdio.h>
#include "global.h"
#include "synax.h"
#include "optimize.h"

#define norvar  0
#define regvar  1
#define globalvar 2
#define tempvar 3
#define numvar 4


struct regdiscrib{
    int sign;
    char name[idsize];
};

struct regdiscrib1{
    int sign;
    int addr;
    int id;
};

struct regdiscribplus{
    int sign;
    int addr;
    char name[idsize];
};

struct tempTab{
    char name[tempsize]; //temp����
    int addr; //temp��ַ
};

FILE *poutmnew;
int stringcount=0,codeindex=0,fttemp=0,tt=0,faddr,funsize=0; //tt,temp������;ftempt,��ǰ�����������
char stringtemp[32];
struct regdiscrib regarr[10];
struct regdiscrib1 regarr1[8];
struct tempTab tTab[512];

int isnum();
void newstring();
void iniglobalvar();
int searchid(char *name,int* index);
void initmips();
void fundefmips();
void funendmips();
void vparamips();
void callmips();
void retmips();
void assfmips();
void jumpmips();
void jalmips();
void labelmips();
void arrmips();
void arrwmips();
void calcumips();
void assignmips();
void scanmips();
void printmips();
void genmips();
int getgt(char*name);
void regvaraddr(char*name,int *index);
int findfuncsize(char*name);
int getReg(char*name);
int findReg(char*name);
void iniregarr();
int getgt(char*name);
int searchtemp(char *temp);
void inserttemp(char *temp);
void printftTab();
int tempfind(char*name);



int tempfind(char*name){
    int i;
    for(i=findex[fttemp].tstart;i<findex[fttemp].tend;i++){
        if(strcmp(name,tTab[i].name)==0) return i;
    }
    return 0;
}

void printftTab(){
    int i;
    FILE* poutt;
    if((poutt=fopen("tTab.txt","w"))==NULL) printf("the file can't be opened!\n");
    fprintf(poutt,"*******************tTab******************\n");
    fprintf(poutt,"name       addr        \n");
    for(i=0;i<tt;i++) fprintf(poutt,"%s       %d      \n",tTab[i].name,tTab[i].addr);
}


int getgt(char* name){
    int i;
    for(i=0;i<gt;i++){
        if(strcmp(name,gTab[i].name)==0){
            return gTab[i].len;
        }
    }
    return -1;
}

int searchtemp(char *temp){ //1,�ҵ���;0,û���ҵ�
    int i;
    for(i=findex[fttemp].tstart;i<tt;i++){
        if(strcmp(temp,tTab[i].name)==0) return 1;
    }
    return 0;
}

void inserttemp(char *temp){
    strcpy(tTab[tt].name,temp);
    faddr+=4;
    tTab[tt].addr=faddr;
    funsize+=4;
    tt++;
}


int isnum(char *name){ //�����ַ���1,���Ƿ���0
    if((name[0]>='0'&&name[0]<='9')||(name[0]=='-'&&name[1]>='0'&&name[1]<='9')) return 1;
    else return 0;
}

void newstring(){
    if(stringcount==stringnum){
        error(47); //string����
        exit(1);
    }
    memset(stringtemp,0,strlen(stringtemp));
    sprintf(stringtemp,"$string%d",stringcount);
    stringcount++;
}


int searchid(char *name,int* index){ //û�ҵ�,����ֵΪ-1;���򷵻�ֵΪ������ַ
    int i,reg;
    for(i=findex[fttemp].tstart;i<findex[fttemp].tend;i++){
        if(strcmp(tTab[i].name,name)==0){
            *index=tTab[i].addr;
            return tempvar;
        }
    }

    for(i=findex[fttemp].vstart;i<findex[fttemp].vend;i++){
        if(strcmp(fTab[i].name,name)==0){
            if(fTab[i].reg!=-1){ //�ֲ��Ĵ�������
                *index=fTab[i].reg-1;
                reg=fTab[i].reg-1;
                regarr1[reg].sign=1;
                regarr1[reg].addr=fTab[i].addr;
                regarr1[reg].id=i;

                return regvar;
            }
            else{ //��ͨ����
                *index=fTab[i].addr;
                return norvar;
            }
        }
    }

    //ȫ�ֱ���
    *index=0;
    return globalvar;
}


void regvaraddr(char*name,int *index){
    int i;
    for(i=findex[fttemp].vstart;i<findex[fttemp].vend;i++){
        if(strcmp(fTab[i].name,name)==0){
            *index=fTab[i].addr;
            return;
        }
    }
}

int findfuncsize(char*name){
    int i;
    for(i=0;i<gt;i++){
        if(strcmp(gTab[i].name,name)==0) return gTab[i].size;
    }
    return 0;
}

int getReg(char*name){
    int i,index;
    for(i=0;i<10;i++){
        if(regarr[i].sign==0){
            regarr[i].sign=1;
            memset(regarr[i].name,0,idsize);
            strcpy(regarr[i].name,name);
            return i;
        }
    }
    searchid(regarr[0].name,&index);
    fprintf(poutmnew,"\tsw $t0,%d($fp)\n",-1*index);
    memset(regarr[0].name,0,idsize);
    strcpy(regarr[i].name,name);
    return 0;
}

int findReg(char*name){
    int i;
    for(i=0;i<10;i++){
        if((regarr[i].sign==1)&&(strcmp(regarr[i].name,name)==0)){
           regarr[i].sign=0;
           memset(regarr[i].name,0,idsize);
           return i;
        }
    }
    return -1;
}


void iniregarr(){
    int i;
    for(i=0;i<10;i++) regarr[i].sign=0;
    for(i=0;i<8;i++){
        regarr1[i].sign=0;
        regarr1[i].addr=0;
        regarr1[i].id=0;
    }

}


void iniglobalvar(){
    int i=0,len;
    while(cTab[i].sign==CONI||cTab[i].sign==CONC) i++;
    while(cTab[i].sign==VARI||cTab[i].sign==VARC){
        if(strcmp(cTab[i].op2,"\0")!=0){
            len=atoi(cTab[i].op2);
            len=len*4;
            memset(cTab[i].op2,0,opsize);
            sprintf(cTab[i].op2,"%d",len);
            fprintf(poutmnew,"\t%s: .space %s\n",cTab[i].op1,cTab[i].op2);
        }
        else fprintf(poutmnew,"\t%s: .space 4\n",cTab[i].op1);
        i++;
    }
    codeindex=i;
}

/*
    1.temp
    2.string
    4.main(j,$sp)
*/
void initmips(){
    int i,mainsize,stemp;
    fprintf(poutmnew,".data\n");

    //��ʼ���Ĵ����洢��
    iniregarr();

    //����ȫ�ֱ���
    iniglobalvar();

    //������Ԫʽ����string���ҵ����Ż���������ȫ�ּĴ���
    for(i=codeindex;i<ct;i++){
        //�����ַ���
        if(cTab[i].sign==PRINTS){
            newstring();
            fprintf(poutmnew,"\t%s:.asciiz \"%s\"\n",stringtemp,cTab[i].op1);
            memset(cTab[i].op1,0,stringsize);
            strcpy(cTab[i].op1,stringtemp);
        }
        else if(cTab[i].sign==FUNDEFC||cTab[i].sign==FUNDEFI||cTab[i].sign==FUNDEFV){
            printf("###%s\n",cTab[i].op1);
            allocGlobalReg(i,fttemp);

            findex[fttemp].tstart=tt;
            funsize=gTab[findex[fttemp].gt].size;
            if(funsize==0) faddr=4;
            else faddr=fTab[findex[fttemp].vend-1].addr;
        }
        else if(cTab[i].sign==FUNEND){
            gTab[findex[fttemp].gt].size=funsize;
            findex[fttemp].tend=tt;
            fttemp++;
        }
        else if(cTab[i].sign==ADD||cTab[i].sign==SUB||cTab[i].sign==MUL||cTab[i].sign==DIVI||cTab[i].sign==ARR){
            if(cTab[i].op3[0]=='$'){
                stemp=searchtemp(cTab[i].op3);
                if(stemp==0) inserttemp(cTab[i].op3);
            }
        }
        else if(cTab[i].sign==ASSF){
            if(cTab[i].op1[0]=='$'){
                stemp=searchtemp(cTab[i].op1);
                if(stemp==0) inserttemp(cTab[i].op1);
            }
        }
        else if(cTab[i].sign==ASS){
            if(cTab[i].op1[0]=='$'){
                stemp=searchtemp(cTab[i].op1);
                if(stemp==0) inserttemp(cTab[i].op1);
            }
            if(cTab[i].op2[0]=='$'){
                stemp=searchtemp(cTab[i].op2);
                if(stemp==0) inserttemp(cTab[i].op2);
            }
        }
    }

    //������������
    mainsize=gTab[findex[funcnum-1].gt].size;
    fprintf(poutmnew,".text\n");
    fprintf(poutmnew,"\taddi $fp,$sp,0\n"); //����mainջ��
    fprintf(poutmnew,"\tsubi $sp,$sp,%d\n",mainsize); //����$sp,����ռ�
    fprintf(poutmnew,"\tj main\n"); //��תmain

    fttemp=0;
}

/*
    fundefi a,NULL,NULL
*/
void fundefmips(){
    fprintf(poutmnew,"%s:\n",cTab[codeindex].op1); //���ú�����ǩ
    if(strcmp(cTab[codeindex].op1,"main")!=0) fprintf(poutmnew,"\tsw $ra,-4($fp)\n"); //���淵�ص�ַ
}

/*
    funend a,NULL,NULL
*/
void funendmips(){
    fttemp++;
}

void paramips(){
    int index,index1;
    if(searchid(cTab[codeindex].op1,&index)==regvar){
        regvaraddr(cTab[codeindex].op1,&index1);
        fprintf(poutmnew,"\tlw $s%d,%d($fp)\n",index,-1*index1);
    }
}

/*
    vpara a,NULL,NULL;
*/
void vparamips(){
    int index,type,reg;

    if(isnum(cTab[codeindex].op1)==1){ //������
        fprintf(poutmnew,"\tli $a2,%s\n",cTab[codeindex].op1);
        fprintf(poutmnew,"\tsw $a2,($sp)\n");
        fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
    }
    else{
        type=searchid(cTab[codeindex].op1,&index); //�Ҳ����ĵ�ַ
        if(type==globalvar){ //global
            fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
            fprintf(poutmnew,"\tlw $a2,($a2)\n");
            fprintf(poutmnew,"\tsw $a2,($sp)\n");
            fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
        }
        else if(type==tempvar){
            reg=findReg(cTab[codeindex].op1);
            if(reg!=-1){
                fprintf(poutmnew,"\tsw $t%d,($sp)\n",reg);
                fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
            }
            else{
                fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
                fprintf(poutmnew,"\tsw $a2,($sp)\n");
                fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
            }
        }
        else if(type==norvar){
            fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
            fprintf(poutmnew,"\tsw $a2,($sp)\n");
            fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
        }
        else{
            fprintf(poutmnew,"\tsw $s%d,($sp)\n",index);
            fprintf(poutmnew,"\tsubi,$sp,$sp,4\n");
        }
    }
}

/*
    call a,NULL,NULL;
*/
void callstmips(){ //$a1���ڴ���
    fprintf(poutmnew,"\tsubi $sp,$sp,8\n");
}

void callendmips(){
    int i,parasize,index,id,j,mark,funsize;
    struct regdiscribplus regsave[10];
    struct regdiscrib1 regsave1[8];
    //����ֲ������Ĵ���
    for(i=0;i<8;i++){
        mark=0;
        if(regarr1[i].sign==1){
            //�鿴�ñ����Ƿ��ڳ��ڴ���Ծ
            id=regarr1[i].id;
            for(j=0;j<fTab[id].actnum;j++){
                if(fTab[id].act[j]==codeindex){//��Ծ
                    fprintf(poutmnew,"\tsw $s%d %d($fp)\n",i,-1*regarr1[i].addr);
                    regsave1[i].sign=1;
                    regsave1[i].addr=regarr1[i].addr;
                    regsave1[i].id=regarr1[i].id;
                    break;
                }
            }
            if(mark==0){
                regsave1[i].sign=0;
                regsave1[i].addr=0;
                regsave1[i].id=0;
            }
        }
        else{
            regsave1[i].sign=0;
            regsave1[i].addr=0;
            regsave1[i].id=0;
        }


        //���ȫ�ּĴ�����¼��
        regarr1[i].sign=0;
        regarr1[i].addr=0;
        regarr1[i].id=0;
    }

    //������ʱ�����Ĵ���
    for(i=0;i<10;i++){
        if(regarr[i].sign==1){
            index=tempfind(regarr[i].name);
            fprintf(poutmnew,"\tsw $t%d,%d($fp)\n",i,-1*(tTab[index].addr));

            regsave[i].sign=1;
            regsave[i].addr=tTab[index].addr;
            memset(regsave[i].name,0,sizeof(regsave[i].name));
            strcpy(regsave[i].name,regarr[i].name);
        }
        else regsave[i].sign=0;
        regarr[i].sign=0;
        memset(regarr[i].name,0,sizeof(regarr[i].name));
    }

    parasize=getgt(cTab[codeindex].op1)*4;

    //����ջ����
    funsize=findfuncsize(cTab[codeindex].op1)-parasize;
    fprintf(poutmnew,"\taddi $a2,$sp,%d\n",parasize+8);
    fprintf(poutmnew,"\tsw $fp,($a2)\n"); //������һ��������ջ��
    fprintf(poutmnew,"\taddi $fp,$a2,0\n"); //����$fp
    fprintf(poutmnew,"\tsubi $sp,$sp,%d\n",funsize); //����ջ�ռ�


    fprintf(poutmnew,"\tjal %s\n",cTab[codeindex].op1); //��ת��Ŀ�꺯��

     //�ָ��Ĵ���ֵ
    for(i=0;i<8;i++){
        if(regsave1[i].sign==1) fprintf(poutmnew,"\tlw $s%d %d($fp)\n",i,-1*regsave1[i].addr);
        regarr1[i].sign=regsave1[i].sign;
        regarr1[i].addr=regsave1[i].addr;
        regarr1[i].id=regsave1[i].id;
    }

     //�ָ���ʱ�Ĵ���ֵ
     for(i=0;i<10;i++){
        if(regsave[i].sign==1){
            fprintf(poutmnew,"\tlw $t%d,%d($fp)\n",i,-1*(regsave[i].addr));
            regarr[i].sign=1;
            memset(regarr[i].name,0,sizeof(regarr[i].name));
            strcpy(regarr[i].name,regsave[i].name);
        }
        else{
            regarr[i].sign=0;
            memset(regarr[i].name,0,sizeof(regarr[i].name));
        }
    }

}

/*
    ret a,NULL,NULL
*/
void retmips(){
    int index,reg;
    if(strcmp(cTab[codeindex].op1,"\0")!=0){ //���淵��ֵ��$v0
        if(isnum(cTab[codeindex].op1)==1) fprintf(poutmnew,"\tli $v0,%s\n",cTab[codeindex].op1);
        else{
            type=searchid(cTab[codeindex].op1,&index);
            if(type==globalvar){ //global
                fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
                fprintf(poutmnew,"\tlw $v0,($a2)\n");
            }
            else if(type==norvar) fprintf(poutmnew,"\tlw $v0,%d($fp)\n",-1*index);
            else if(type==tempvar){
                reg=findReg(cTab[codeindex].op1);
                if(reg==-1) fprintf(poutmnew,"\tlw $v0,%d($fp)\n",-1*index);
                else fprintf(poutmnew,"\tmove $v0,$t%d\n",reg);
            }
            else fprintf(poutmnew,"\tmove $v0,$s%d\n",index);
        }
    }

    if(fttemp!=funcnum-1){ //����main����
        fprintf(poutmnew,"\tlw $ra,-4($fp)\n"); //ȡ���ص�ַ��$ra
        fprintf(poutmnew,"\tmove $sp,$fp\n"); //����$spΪ$fp
        fprintf(poutmnew,"\tlw $fp,($fp)\n"); //����$fpֵ
        fprintf(poutmnew,"\tjr $ra\n"); //��ת�����ص�ַ��
    }
    else{ //��main����
        fprintf(poutmnew,"\tli $v0,10\n");
        fprintf(poutmnew,"\tsyscall\n");
    }
}

/*
    ass a,b==>a=b
*/
void assmips(){ //a2����ȡַ
    int type1,type2,index1,index2,rega,regb;
    //b
    if(isnum(cTab[codeindex].op2)==1) type1=numvar;
    else{
        type1=searchid(cTab[codeindex].op2,&index1);
        if(type1==tempvar) regb=findReg(cTab[codeindex].op2); //��ʱ����
        else if(type1==globalvar) fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op2);
        else if(type1==regvar) regb=index1; //�ֲ��Ĵ�������
    }

    //a
    type2=searchid(cTab[codeindex].op1,&index2);
    if(type2==tempvar){//��ʱ����
        rega=getReg(cTab[codeindex].op1);
        if(type1==numvar) fprintf(poutmnew,"\tli $t%d,%s\n",rega,cTab[codeindex].op2);
        else if(type1==globalvar) fprintf(poutmnew,"\tlw $t%d,($a2)\n",rega);
        else if(type1==norvar||(type1==tempvar&&regb==-1)) fprintf(poutmnew,"\tlw,$t%d,%d($fp)\n",rega,-1*index1);
        else if(type1==tempvar&&regb!=-1) fprintf(poutmnew,"\tmove $t%d,$t%d\n",rega,regb);
        else fprintf(poutmnew,"\tmove $t%d,$s%d\n",rega,regb);
    }
    else if(type2==regvar){ //�ֲ��Ĵ�������
        rega=index2;
        if(type1==numvar) fprintf(poutmnew,"\tli $s%d,%s\n",rega,cTab[codeindex].op2);
        else if(type1==globalvar) fprintf(poutmnew,"\tlw $s%d,($a2)\n",rega);
        else if(type1==norvar||(type1==tempvar&&regb==-1)) fprintf(poutmnew,"\tlw,$s%d,%d($fp)\n",rega,-1*index1);
        else if(type1==tempvar&&regb!=-1) fprintf(poutmnew,"\tmove $s%d,$t%d\n",rega,regb);
        else fprintf(poutmnew,"\tmove $s%d,$s%d\n",rega,regb);
    }
    else if(type2==globalvar){ //ȫ�ֱ���
        fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op1);
        if(type1==numvar){
            fprintf(poutmnew,"\tli $a2,%s\n",cTab[codeindex].op2);
            fprintf(poutmnew,"\tsw $a2,($a1)\n");
        }
        else if(type1==globalvar){
            fprintf(poutmnew,"\tlw,$a2,($a2)\n");
            fprintf(poutmnew,"\tsw $a2,($a1)\n");
        }
        else if(type1==norvar||(type1==tempvar&&regb==-1)){
            fprintf(poutmnew,"\tlw,$a2,%d($fp)\n",-1*index1);
            fprintf(poutmnew,"\tsw $a2,($a1)\n");
        }
        else if(type1==tempvar&&regb!=-1) fprintf(poutmnew,"\tsw $t%d,($a1)\n",regb);
        else fprintf(poutmnew,"\tsw $s%d,($a1)\n",regb);
    }
    else{ //��ͨ�ֲ�����
        if(type1==numvar){
            fprintf(poutmnew,"\tli $a2,%s\n",cTab[codeindex].op2);
            fprintf(poutmnew,"\tsw $a2,%d($fp)\n",-1*index2);
        }
        else if(type1==globalvar){
            fprintf(poutmnew,"\tlw,$a2,($a2)\n");
            fprintf(poutmnew,"\tsw $a2,%d($fp)\n",-1*index2);
        }
        else if(type1==norvar||(type1==tempvar&&regb==-1)){
            fprintf(poutmnew,"\tlw,$a2,%d($fp)\n",-1*index1);
            fprintf(poutmnew,"\tsw $a2,%d($fp)\n",-1*index2);
        }
        else if(type1==tempvar&&regb!=-1) fprintf(poutmnew,"\tsw $t%d,%d($fp)\n",regb,-1*index2);
        else fprintf(poutmnew,"\tsw $s%d,%d($fp)\n",regb,-1*index2);
    }
}

/*
    assf,a,NULL,NULL
*/
void assfmips(){ //һ����temp��Ϊassf��Ŀ�Ĳ�����
    int rega;

    rega=getReg(cTab[codeindex].op1);
    fprintf(poutmnew,"\tmove $t%d,$v0\n",rega);
}


/*
    jump a,NULL,NULL
*/
void jumpmips(){
    fprintf(poutmnew,"\tj %s\n",cTab[codeindex].op1);
}


/*
    jal a,NULL,NULL
*/
void jalmips(){
    int type1,type2,index,reg1,reg2;
    //����,����,op3
    //��������ֵ,��ֵ,op1
    //�Ƚ�

    //$a2��Ž��
    //����,����
    if(cTab[codeindex-1].sign==ADD||cTab[codeindex-1].sign==SUB||cTab[codeindex-1].sign==MUL||cTab[codeindex-1].sign==DIVI||cTab[codeindex-1].sign==ARR){
        type1=searchid(cTab[codeindex-1].op3,&index);
        if(type1==globalvar){
            fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex-1].op3);
            fprintf(poutmnew,"\tlw $a2,($a2)\n");
        }
        else if(type1==norvar) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
        else if(type1==tempvar){
            reg1=findReg(cTab[codeindex-1].op3);
            if(reg1==-1) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
        }
        else reg1=index;
    }
    //��������ֵ,��ֵ
    else if(cTab[codeindex-1].sign==ASSF||cTab[codeindex-1].sign==ASS){
        type1=searchid(cTab[codeindex-1].op1,&index);
        if(type1==globalvar){
            fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex-1].op1);
            fprintf(poutmnew,"\tlw $a2,($a2)\n");
        }
        else if(type1==norvar) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
        else if(type1==tempvar){
            reg1=findReg(cTab[codeindex-1].op1);
            if(reg1==-1) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
        }
        else reg1=index;
    }

    //$t0�ŵ�һ��������,$t1�ŵڶ���������
    //�Ƚ�
    else if(cTab[codeindex-1].sign==EQUAL||cTab[codeindex-1].sign==NEQUAL||cTab[codeindex-1].sign==GREAT||cTab[codeindex-1].sign==LESS||cTab[codeindex-1].sign==GEQUAL||cTab[codeindex-1].sign==LEQUAL){
        if(isnum(cTab[codeindex-1].op1)==1){
            fprintf(poutmnew,"\tli $a2,%s\n",cTab[codeindex-1].op1);
            type1=numvar;
        }
        else{
            type1=searchid(cTab[codeindex-1].op1,&index);
            if(type1==globalvar){
                fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex-1].op1);
                fprintf(poutmnew,"\tlw $a2,($a2)\n");
            }
            else if(type1==norvar) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
            else if(type1==tempvar){
                reg1=findReg(cTab[codeindex-1].op1);
                if(reg1==-1) fprintf(poutmnew,"\tlw $a2,%d($fp)\n",-1*index);
            }
            else reg1=index;
        }

        if(isnum(cTab[codeindex-1].op2)==1){
            fprintf(poutmnew,"\tli $a1,%s\n",cTab[codeindex-1].op2);
            type2=numvar;
        }
        else{
            type2=searchid(cTab[codeindex-1].op2,&index);
            if(type2==globalvar){
                fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex-1].op2);
                fprintf(poutmnew,"\tlw $a1,($a1)\n");
            }
            else if(type2==norvar) fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
            else if(type2==tempvar){
                reg2=findReg(cTab[codeindex-1].op2);
                if(reg2==-1) fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
            }
            else reg2=index;
        }
    }
    else error(50); //�����ܳ���


    //������תָ��
    if(cTab[codeindex-1].sign==ADD||cTab[codeindex-1].sign==SUB||cTab[codeindex-1].sign==MUL||cTab[codeindex-1].sign==DIVI||cTab[codeindex-1].sign==ARR||cTab[codeindex-1].sign==ASSF||cTab[codeindex-1].sign==ASS){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)) fprintf(poutmnew,"\tbeqz $a2,%s\n",cTab[codeindex].op1);
        else if(type1==tempvar&&reg1!=-1) fprintf(poutmnew,"\tbeqz $t%d,%s\n",reg1,cTab[codeindex].op1);
        else fprintf(poutmnew,"\tbeqz $s%d,%s\n",reg1,cTab[codeindex].op1);
    }

    else if(cTab[codeindex-1].sign==EQUAL){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbne $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbne $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbne $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbne $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbne $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbne $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbne $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbne $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbne $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else if(cTab[codeindex-1].sign==NEQUAL){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbeq $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbeq $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbeq $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbeq $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbeq $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbeq $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbeq $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbeq $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbeq $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else if(cTab[codeindex-1].sign==GREAT){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tble $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tble $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tble $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tble $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tble $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tble $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tble $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tble $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tble $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else if(cTab[codeindex-1].sign==LESS){
       if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbge $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbge $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbge $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbge $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbge $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbge $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbge $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbge $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbge $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else if(cTab[codeindex-1].sign==GEQUAL){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tblt $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tblt $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tblt $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tblt $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tblt $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tblt $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tblt $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tblt $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tblt $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else if(cTab[codeindex-1].sign==LEQUAL){
       if(type1==globalvar||type1==norvar||(type1==tempvar&&reg1==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbgt $a2,$a1,%s\n",cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbgt $a2,$t%d,%s\n",reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbgt $a2,$s%d,%s\n",reg2,cTab[codeindex].op1);
        }
        else if(type1==tempvar&&(reg1!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbgt $t%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbgt $t%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbgt $t%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
        else{
            if(type2==globalvar||type2==norvar||(type2==tempvar&&reg2==-1)||type2==numvar) fprintf(poutmnew,"\tbgt $s%d,$a1,%s\n",reg1,cTab[codeindex].op1);
            else if(type2==tempvar&&(reg2!=-1)) fprintf(poutmnew,"\tbgt $s%d,$t%d,%s\n",reg1,reg2,cTab[codeindex].op1);
            else fprintf(poutmnew,"\tbgt $s%d,$s%d,%s\n",reg1,reg2,cTab[codeindex].op1);
        }
    }

    else error(50); //�����ܳ���
}

/*
    label a,NULL,NULL
*/
void labelmips(){
    fprintf(poutmnew,"%s:\n",cTab[codeindex].op1);
}

/*
    arr a,b,c==>c=a[b]
*/
void arrmips(){
    int index,type1,type2,regb,regc;

    //$a2,a�Ļ�ַ
    type1=searchid(cTab[codeindex].op1,&index);
    if(type1==globalvar) fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
    else fprintf(poutmnew,"\taddi $a2,$fp,%d\n",-1*index);

    //$a1,b*-4
    if(isnum(cTab[codeindex].op2)==1){
        fprintf(poutmnew,"\tli $a1,%s\n",cTab[codeindex].op2);
        if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
        else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
    }
    else{
        type2=searchid(cTab[codeindex].op2,&index);
        if(type2==globalvar){
            fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op2);
            fprintf(poutmnew,"\tlw $a1,($a1)\n");
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
            else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
        }
        else if(type2==norvar){
            fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n");
            else fprintf(poutmnew,"\tmul $a1,$a1,-4\n");
        }
        else if(type2==tempvar){
            regb=findReg(cTab[codeindex].op2);
            if(regb!=-1){
                if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$t%d,4\n",regb);
                else fprintf(poutmnew,"\tmul $a1,$t%d,-4\n",regb);
            }
            else{
                fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
                if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n");
                else fprintf(poutmnew,"\tmul $a1,$a1,-4\n");
            }
        }
        else{
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$s%d,4\n",index);
            else fprintf(poutmnew,"\tmul $a1,$s%d,-4\n",index);
        }
    }

    //$a2,����Ԫ�ػ�ַ
    fprintf(poutmnew,"\tadd $a2,$a2,$a1\n");

    //c��ֵ
    type2=searchid(cTab[codeindex].op3,&index);
    if(type2==globalvar){
        fprintf(poutmnew,"\tlw $a2,($a2)\n");
        fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op3);
        fprintf(poutmnew,"\tsw $a2,($a1)\n");
    }
    else if(type2==norvar){
        fprintf(poutmnew,"\tlw $a2,($a2)\n");
        fprintf(poutmnew,"\tsw $a2,%d($fp)\n",-1*index);
    }
    else if(type2==tempvar){
        regc=getReg(cTab[codeindex].op3);
        fprintf(poutmnew,"\tlw $t%d,($a2)\n",regc);
    }
    else fprintf(poutmnew,"\tlw $s%d,($a2)\n",index);
}

/*
    arrw,a,b,c==>a[b]=c
*/
void arrwmips(){
    int type1,type2,index,regb,regc;

    //$t0,a�Ļ�ַ
    type1=searchid(cTab[codeindex].op1,&index);
    if(type1==globalvar)fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
    else fprintf(poutmnew,"\taddi $a2,$fp,%d\n",-1*index);

    //$a1,b*-4
    if(isnum(cTab[codeindex].op2)==1){
        fprintf(poutmnew,"\tli $a1,%s\n",cTab[codeindex].op2);
        if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
        else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
    }
    else{
        type2=searchid(cTab[codeindex].op2,&index);
        if(type2==globalvar){
            fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op2);
            fprintf(poutmnew,"\tlw $a1,($a1)\n");
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
            else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
        }
        else if(type2==norvar){
            fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
            else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
        }
        else if(type2==tempvar){
            regb=findReg(cTab[codeindex].op2);
            if(regb!=-1){
                if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$t%d,4\n",regb);
                else fprintf(poutmnew,"\tmul $a1,$t%d,-4\n",regb);
            }
            else{
                fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
                if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$a1,4\n"); //ȫ�������ַ��������
                else fprintf(poutmnew,"\tmul $a1,$a1,-4\n"); //�ֲ������ַ��������
            }
        }
        else{
            if(type1==globalvar) fprintf(poutmnew,"\tmul $a1,$s%d,4\n",index);
            else fprintf(poutmnew,"\tmul $a1,$s%d,-4\n",index);
        }
    }


    //$a2,����Ԫ�ػ�ַ
    fprintf(poutmnew,"\tadd $a2,$a2,$a1\n");

    //$t1,c��ֵ
    if(isnum(cTab[codeindex].op3)==1){
        fprintf(poutmnew,"\tli $a1,%s\n",cTab[codeindex].op3);
        fprintf(poutmnew,"\tsw $a1,($a2)\n");
    }
    else{
        type2=searchid(cTab[codeindex].op3,&index);
        if(type2==globalvar){
            fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op3);
            fprintf(poutmnew,"\tlw $a1,($a1)\n");
            fprintf(poutmnew,"\tsw $a1,($a2)\n");
        }
        else if(type2==norvar){
            fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
            fprintf(poutmnew,"\tsw $a1,($a2)\n");
        }
        else if(type2==tempvar){
            regc=findReg(cTab[codeindex].op3);
            if(regc!=-1) fprintf(poutmnew,"\tsw $t%d,($a2)\n",regc);
            else{
                fprintf(poutmnew,"\tlw $a1,%d($fp)\n",-1*index);
                fprintf(poutmnew,"\tsw $a1,($a2)\n");
            }
        }
        else fprintf(poutmnew,"\tsw $s%d,($a2)\n",index);
    }
}

/*
    + - * /
    add,a,b,c==>c=a+b
*/
void calcumips(){
    int index,type1,type2,type3;
    char rega[16],regb[16],regc[16],regat,regbt;

    //������һ��������
    if(isnum(cTab[codeindex].op1)==1){
        fprintf(poutmnew,"\tli $a2,%s\n",cTab[codeindex].op1);
        type1=numvar;
    }
    else{
        type1=searchid(cTab[codeindex].op1,&index);
        if(type1==tempvar){//��ʱ����
            memset(rega,0,sizeof(rega));
            regat=findReg(cTab[codeindex].op1);
            if(regat!=-1) sprintf(rega,"$t%d",regat);
            else fprintf(poutmnew,"\tlw,$a2,%d($fp)\n",-1*index);
        }
        else if(type1==globalvar){ //ȫ�ֱ���
            fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
            fprintf(poutmnew,"\tlw $a2,($a2)\n");
        }
        else if(type1==regvar){ //�ֲ��Ĵ�������
            memset(rega,0,sizeof(rega));
            sprintf(rega,"$s%d",index);
        }
        else{ //��ͨ�ֲ�����
            fprintf(poutmnew,"\tlw,$a2,%d($fp)\n",-1*index);
        }
    }

    //�����ڶ���������
    if(isnum(cTab[codeindex].op2)==1){
        fprintf(poutmnew,"\tli $a1,%s\n",cTab[codeindex].op2);
        type2=numvar;
    }
    else{
        type2=searchid(cTab[codeindex].op2,&index);
        if(type2==tempvar){//��ʱ����
            memset(regb,0,sizeof(regb));
            regbt=findReg(cTab[codeindex].op2);
            if(regbt!=-1) sprintf(regb,"$t%d",regbt);
            else fprintf(poutmnew,"\tlw,$a1,%d($fp)\n",-1*index);
        }
        else if(type2==globalvar){ //ȫ�ֱ���
            fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op2);
            fprintf(poutmnew,"\tlw $a1,($a1)\n");
        }
        else if(type2==regvar){ //�ֲ��Ĵ�������
            memset(regb,0,sizeof(regb));
            sprintf(regb,"$s%d",index);
        }
        else{ //��ͨ�ֲ�����
            fprintf(poutmnew,"\tlw,$a1,%d($fp)\n",-1*index);
        }
    }


    //����������������������
    type3=searchid(cTab[codeindex].op3,&index);
    if(type3==tempvar){//��ʱ����
        memset(regc,0,sizeof(regc));
        sprintf(regc,"$t%d",getReg(cTab[codeindex].op3));
    }
    else if(type3==regvar){ //�ֲ��Ĵ�������
        memset(regc,0,sizeof(regc));
        sprintf(regc,"$s%d",index);
    }


    if(type3==tempvar||type3==regvar){
        if(type1==globalvar||type1==norvar||(type1==tempvar&&regat==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&regbt==-1)||type2==numvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu %s,$a2,$a1\n",regc);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu %s,$a2,$a1\n",regc);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu %s,$a2,$a1\n",regc);
                else{
                    fprintf(poutmnew,"\tdivu $a2,$a1\n");
                    fprintf(poutmnew,"\tmflo,%s\n",regc);
                }
            }
            else if((type2==tempvar&&regbt!=-1)||type2==regvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu %s,$a2,%s\n",regc,regb);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu %s,$a2,%s\n",regc,regb);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu %s,$a2,%s\n",regc,regb);
                else{
                    fprintf(poutmnew,"\tdivu $a2,%s\n",regb);
                    fprintf(poutmnew,"\tmflo,%s\n",regc);
                }
            }
        }

       else if(type1==regvar||(type1==tempvar&&regat!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&regbt==-1)||type2==numvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu %s,%s,$a1\n",regc,rega);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu %s,%s,$a1\n",regc,rega);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu %s,%s,$a1\n",regc,rega);
                else{
                    fprintf(poutmnew,"\tdivu %s,$a1\n",rega);
                    fprintf(poutmnew,"\tmflo,%s\n",regc);
                }
            }
            else if(type2==regvar||(type2==tempvar&&regbt!=-1)){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu %s,%s,%s\n",regc,rega,regb);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu %s,%s,%s\n",regc,rega,regb);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu %s,%s,%s\n",regc,rega,regb);
                else{
                    fprintf(poutmnew,"\tdivu %s,%s\n",rega,regb);
                    fprintf(poutmnew,"\tmflo,%s\n",regc);
                }
            }
        }
    }


    else{
        if(type1==globalvar||type1==norvar||(type1==tempvar&&regat==-1)||type1==numvar){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&regbt==-1)||type2==numvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu $a2,$a2,$a1\n");
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu $a2,$a2,$a1\n");
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu $a2,$a2,$a1\n");
                else{
                    fprintf(poutmnew,"\tdivu $a2,$a1\n");
                    fprintf(poutmnew,"\tmflo,$a2\n");
                }
            }
            else if((type2==tempvar&&regbt!=-1)||type2==regvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu $a2,$a2,%s\n",regb);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu $a2,$a2,%s\n",regb);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu $a2,$a2,%s\n",regb);
                else{
                    fprintf(poutmnew,"\tdivu $a2,%s\n",regb);
                    fprintf(poutmnew,"\tmflo,$a2\n");
                }
            }
        }

        else if(type1==regvar||(type1==tempvar&&regat!=-1)){
            if(type2==globalvar||type2==norvar||(type2==tempvar&&regbt==-1)||type1==numvar){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu $a2,%s,$a1\n",rega);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu $a2,%s,$a1\n",rega);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu $a2,%s,$a1\n",rega);
                else{
                    fprintf(poutmnew,"\tdivu %s,$a1\n",rega);
                    fprintf(poutmnew,"\tmflo,$a2\n");
                }
            }
            else if(type2==regvar||(type2==tempvar&&regbt!=-1)){
                if(cTab[codeindex].sign==ADD)       fprintf(poutmnew,"\taddu $a2,%s,%s\n",rega,regb);
                else if(cTab[codeindex].sign==SUB)  fprintf(poutmnew,"\tsubu $a2,%s,%s\n",rega,regb);
                else if(cTab[codeindex].sign==MUL)  fprintf(poutmnew,"\tmulu $a2,%s,%s\n",rega,regb);
                else{
                    fprintf(poutmnew,"\tdivu %s,%s\n",rega,regb);
                    fprintf(poutmnew,"\tmflo,$a2\n");
                }
            }
        }

        if(type3==globalvar){
            fprintf(poutmnew,"\tla $a1,%s\n",cTab[codeindex].op3);
            fprintf(poutmnew,"\tsw $a2,($a1)\n");
        }
        else fprintf(poutmnew,"\tsw $a2,%d($fp)\n",-1*index);
    }

}


/*
    scani,a,NULL==>scan(a)
*/
void scanmips(){ //aֻ��Ϊ��ʶ��
    int index,type;

    if(cTab[codeindex].sign==SCANC) fprintf(poutmnew,"\tli $v0,12\n");
    else fprintf(poutmnew,"\tli $v0,5\n");
    fprintf(poutmnew,"\tsyscall\n");

    type=searchid(cTab[codeindex].op1,&index);
    if(type==globalvar){
        fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
        fprintf(poutmnew,"\tsw $v0,($a2)\n");
    }
    else if(type==norvar) fprintf(poutmnew,"\tsw $v0,%d($fp)\n",-1*index);
    else fprintf(poutmnew,"\tmove $s%d,$v0\n",index);
}

/*
    prints a,NULL,NULL==>print(a)
*/
void printmips(){
    int index,type,reg;

    if(cTab[codeindex].sign==PRINTS){
        fprintf(poutmnew,"\tli $v0,4\n");
        fprintf(poutmnew,"\tla $a0,%s\n",cTab[codeindex].op1);
    }
    else{
        if(cTab[codeindex].sign==PRINTI) fprintf(poutmnew,"\tli $v0,1\n");
        else fprintf(poutmnew,"\tli $v0,11\n");

        if(isnum(cTab[codeindex].op1)==1) fprintf(poutmnew,"\tli $a0,%s\n",cTab[codeindex].op1);
        else{
            type=searchid(cTab[codeindex].op1,&index);
            if(type==globalvar){
                fprintf(poutmnew,"\tla $a2,%s\n",cTab[codeindex].op1);
                fprintf(poutmnew,"\tlw $a0,($a2)\n");
            }
            else if(type==norvar) fprintf(poutmnew,"\tlw $a0,%d($fp)\n",-1*index);
            else if(type==tempvar){
                reg=findReg(cTab[codeindex].op1);
                if(reg!=-1) fprintf(poutmnew,"\tmove $a0,$t%d\n",reg);
                else fprintf(poutmnew,"\tlw $a0,%d($fp)\n",-1*index);
            }
            else fprintf(poutmnew,"\tmove $a0,$s%d\n",index);
        }
    }
    fprintf(poutmnew,"\tsyscall\n");
}

void genmips(){
    initmips();

    for(;codeindex<ct;codeindex++){
        if(cTab[codeindex].sign==ADD||cTab[codeindex].sign==SUB||cTab[codeindex].sign==MUL||cTab[codeindex].sign==DIVI){
             calcumips();
        }
        else if(cTab[codeindex].sign==ARRW) arrwmips();
        else if(cTab[codeindex].sign==ARR) arrmips();
        else if(cTab[codeindex].sign==SCANC||cTab[codeindex].sign==SCANI) scanmips();
        else if(cTab[codeindex].sign==PRINTC||cTab[codeindex].sign==PRINTI||cTab[codeindex].sign==PRINTS) printmips();
        else if(cTab[codeindex].sign==FUNDEFV||cTab[codeindex].sign==FUNDEFI||cTab[codeindex].sign==FUNDEFC) fundefmips();
        else if(cTab[codeindex].sign==FUNEND) funendmips();
        else if(cTab[codeindex].sign==RET) retmips();
        else if(cTab[codeindex].sign==CALLST) callstmips();
        else if(cTab[codeindex].sign==CALLEND) callendmips();
        else if(cTab[codeindex].sign==ASS) assmips();
        else if(cTab[codeindex].sign==ASSF) assfmips();
        else if(cTab[codeindex].sign==JUMP) jumpmips();
        else if(cTab[codeindex].sign==JAL) jalmips();
        else if(cTab[codeindex].sign==LABEL) labelmips();
        else if(cTab[codeindex].sign==VPARA) vparamips();
        else if(cTab[codeindex].sign==PARAC||cTab[codeindex].sign==PARAI) paramips();
    }
}

#endif
