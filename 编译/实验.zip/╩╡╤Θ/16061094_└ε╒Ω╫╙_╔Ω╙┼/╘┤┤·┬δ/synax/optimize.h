#ifndef _OPTIMIZE_H_
#define _OPTIMIZE_H_
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "global.h"
#include "midcode.h"
#include "synax.h"

#define REGNUM 8
#define yes 1
#define no 2
#define allocglo -1
#define allocyes -2
#define allocno -3
#define byte unsigned char

/*1.���к����ڲ���Ծ��������(��������ڴ���Ծ�ı����ǳ�ͻ����,out�����ǿ�������Ծ�ı���)����ɫ������ȫ�ּĴ���*/
/*2.��ʱ�Ĵ�������*/
/*3.�����ϲ�*/
/*��ʱ��:DAGͼ,���ƴ���*/


struct block{
    int start;
    int end;
};
struct block blockarr[128];
int blockt=1,basic=0;
byte flowmap[128][128],use[128][128],def[128][128],in[128][128],out[128][128],minustemp[128],nodetemp[128],nodetemp2[128],graph[128][128];
int intemp[128];


void constFolding();
int  isConst();
int findvar(char* name,int ftempi);
void allocGlobalReg(int cti,int ftempi);
void getBlock(int start);
void getFlow(int ftempi);
void activeInformation(int ftempi);



int isConst(char* a){
    if((a[0]>='0'&&a[0]<='9')||(a[0]=='-'&&a[1]>='0'&&a[1]<='9')) return 1;
    return 0;
}

int findvar(char*name,int ftempi){
    int i;
    //�Ҿֲ�����
    for(i=findex[ftempi].vstart;i<findex[ftempi].vend;i++){
        if(strcmp(fTab[i].name,name)==0) return i-findex[ftempi].vstart;
    }
    return -1;
}

void constFolding(){
    int i,temp;
    char op2[opsize];
    for(i=0;i<ct;i++){
        if(cTab[i].sign==ADD || cTab[i].sign==SUB || cTab[i].sign==MUL || cTab[i].sign==DIVI){
            if(isConst(cTab[i].op1)&&isConst(cTab[i].op2)){
                if(cTab[i].sign==ADD) temp=atoi(cTab[i].op1)+atoi(cTab[i].op2);
                else if(cTab[i].sign==SUB) temp=atoi(cTab[i].op1)-atoi(cTab[i].op2);
                else if(cTab[i].sign==MUL) temp=atoi(cTab[i].op1)*atoi(cTab[i].op2);
                else temp=atoi(cTab[i].op1)/atoi(cTab[i].op2);

                memset(op2,0,sizeof(op2));
                sprintf(op2,"%d",temp);

                cTab[i].sign=ASS;
                memset(cTab[i].op1,0,sizeof(cTab[i].op1));
                strcpy(cTab[i].op1,cTab[i].op3);
                memset(cTab[i].op2,0,sizeof(cTab[i].op2));
                strcpy(cTab[i].op2,op2);
                memset(cTab[i].op3,0,sizeof(cTab[i].op3));
            }
        }
    }
}

void allocGlobalReg(int cti,int ftempi){
    blockt=1;
    printf("///%s\n",cTab[cti].op1);
    getBlock(cti);
    getFlow(ftempi);
}

void getBlock(int start){
    int i;

    i=start;
    blockarr[blockt].start=i;
    i++;

    while(1){
        if(cTab[i].sign==FUNEND){
            blockarr[blockt++].end=i-1;
            //printf("%d\n",i);
            break;
        }
        else if(cTab[i].sign==LABEL){
            blockarr[blockt].end=i-1;
            blockt++;
            blockarr[blockt].start=i;
            i++;
        }
        else if(cTab[i].sign==RET||cTab[i].sign==CALLEND||cTab[i].sign==JUMP||cTab[i].sign==JAL){
            blockarr[blockt].end=i;
            i++;
            if(cTab[i].sign==FUNEND){
                blockarr[blockt++].end=i-1;
                break;
            }
            blockt++;
            blockarr[blockt].start=i;
            i++;
        }
        else i++;
    }

    //*********************************************
    printf("������\n");
    for(i=1;i<blockt;i++){
        printf("start:%d\n",blockarr[i].start);
        printf("end:%d\n",blockarr[i].end);
    }
    printf("*******************************\n");
    //**********************************************
}

void getFlow(int ftempi){ //һ��������Ľ�����������:�κ�һ��/��ת���
    int i,j,labeli,endi;
    char destlabel[stringsize];


    for(i=0;i<blockt+1;i++){
        for(j=0;j<blockt+1;j++){
            flowmap[i][j]=0;
        }
    }

    flowmap[0][1]=1;
    for(i=1;i<blockt;i++){
        endi=blockarr[i].end;
        if(cTab[endi].sign==RET) flowmap[i][blockt]=1;
        else if(cTab[endi].sign==CALLEND) flowmap[i][i+1]=1;
        else if(cTab[endi].sign==JUMP||cTab[endi].sign==JAL){
            memset(destlabel,0,sizeof(destlabel));
            strcpy(destlabel,cTab[endi].op1);

            for(j=1;j<blockt;j++){
                labeli=blockarr[j].start;
                if(cTab[labeli].sign==LABEL){
                    if(strcmp(cTab[labeli].op1,destlabel)==0){
                        break;
                    }
                }
            }

            if(cTab[endi].sign==JUMP) flowmap[i][j]=1;
            else{
                flowmap[i][j]=1;
                flowmap[i][i+1]=1;
            }
        }
        else flowmap[i][i+1]=1;
    }

    //**********************************************
    printf("��ͼ\n");
    for(i=0;i<blockt+1;i++){
        for(j=0;j<blockt+1;j++) printf("%d ",flowmap[i][j]);
        printf("\n");
    }
    printf("*********************************\n");
    //***********************************************

    activeInformation(ftempi);
}


void activeInformation(int ftempi){
    int varnum,result,k,i,j,change=0;
    varnum=findex[ftempi].vend-findex[ftempi].vstart;


    for(i=0;i<blockt+1;i++){ //��ʼ��
        for(j=0;j<varnum;j++){
            use[i][j]=0;
            def[i][j]=0;
            in[i][j]=0;
            out[i][j]=0;
        }
    }
    for(i=0;i<varnum;i++){
        intemp[i]=0;
        minustemp[i]=0;
    }

    //����use��def
    for(i=1;i<blockt;i++){
        for(j=blockarr[i].start;j<=blockarr[i].end;j++){
            if(cTab[j].sign==PARAC||cTab[j].sign==PARAI){
                result=findvar(cTab[j].op1,ftempi);
                if(result!=-1){
                    if(use[i][result]==0){
                        def[i][result]=1;
                    }
                }
            }
            else if(cTab[j].sign==ADD||cTab[j].sign==SUB||cTab[j].sign==MUL||cTab[j].sign==DIVI||cTab[j].sign==EQUAL||cTab[j].sign==NEQUAL||cTab[j].sign==LESS||cTab[j].sign==LEQUAL||cTab[j].sign==GREAT||cTab[j].sign==GEQUAL){
                result=findvar(cTab[j].op1,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
                result=findvar(cTab[j].op2,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
                result=findvar(cTab[j].op3,ftempi);
                if(result!=-1){
                    if(use[i][result]==0){
                        def[i][result]=1;
                    }
                }
            }

            else if(cTab[j].sign==ASS){
                result=findvar(cTab[j].op1,ftempi);
                if(result!=-1){
                    if(use[i][result]==0){
                        def[i][result]=1;
                    }
                }
                result=findvar(cTab[j].op2,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
            }

            else if(cTab[j].sign==ARR){
                result=findvar(cTab[j].op2,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
                result=findvar(cTab[j].op3,ftempi);
                if(result!=-1){
                    if(use[i][result]==0){
                        def[i][result]=1;
                    }
                }
            }

            else if(cTab[j].sign==ARRW){
                result=findvar(cTab[j].op2,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
                result=findvar(cTab[j].op3,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
            }

            else if(cTab[j].sign==SCANI||cTab[j].sign==SCANC||cTab[j].sign==PRINTI||cTab[j].sign==PRINTC||cTab[j].sign==RET||cTab[j].sign==ASSF||cTab[j].sign==VPARA){
                result=findvar(cTab[j].op1,ftempi);
                if(result!=-1){
                    if(def[i][result]==0){
                        use[i][result]=1;
                    }
                }
            }
        }
    }

    //****************************
    for(i=1;i<blockt;i++){
        printf("use%d:",i);
        for(j=0;j<varnum;j++){
            printf("%d ",use[i][j]);
        }
        printf("\n");
    }
    for(i=1;i<blockt;i++){
        printf("def%d:",i);
        for(j=0;j<varnum;j++){
            printf("%d ",def[i][j]);
        }
        printf("\n");
    }
    printf("************************************\n");
    //****************************



    //����in��out
    do{
        change=0;
        for(i=blockt-1;i>=1;i--){//����ÿһ��������
            //ȡ��̻�����in������
            for(k=0;k<blockt+1;k++){
                if(flowmap[i][k]==1){ //�Ƿ��Ǻ�̻�����
                    for(j=0;j<varnum;j++){ //ȡin������
                        intemp[j]=intemp[j]|in[k][j];
                    }
                }
            }
            for(j=0;j<varnum;j++){ //out=���in����
                if(out[i][j]!=intemp[j]) change=1;
                out[i][j]=intemp[j];
                intemp[j]=0;
            }


            //����in��
            for(j=0;j<varnum;j++){ //out[B]-def[B]
                if(out[i][j]-def[i][j]<=0) minustemp[j]=0;
                else minustemp[j]=1;
            }
            for(j=0;j<varnum;j++){//use[B]U(out[B]-def[B])
                intemp[j]=use[i][j]|minustemp[j];
                if(in[i][j]!=intemp[j]) change=1;
                in[i][j]=intemp[j];
                intemp[j]=0;
                minustemp[j]=0;
            }
        }
    }while(change);
    //****************************
    for(i=1;i<blockt;i++){
        printf("in%d :",i);
        for(j=0;j<varnum;j++){
            printf("%d ",in[i][j]);
        }
        printf("\n");
        printf("out%d:",i);
        for(j=0;j<varnum;j++){
            printf("%d ",out[i][j]);
        }
        printf("\n");
    }
    printf("************************************\n");
    //****************************

    //Ϊÿһ���������ɳ��ڻ�Ծ������Χ
    int recst=findex[ftempi].vstart,actnumt;
    for(i=1;i<blockt;i++){
        if(cTab[blockarr[i].end].sign==CALLEND){
            for(j=0;j<varnum;j++){
                if(out[i][j]==1){
                    actnumt=fTab[j+recst].actnum;
                    fTab[j+recst].act[actnumt]=blockarr[i].end;
                    fTab[j+recst].actnum=actnumt+1;
                }
            }
        }
    }


    //ȡȫ��in������
    for(i=1;i<blockt;i++){
        for(j=0;j<varnum;j++){
            intemp[j]=intemp[j]|in[i][j];
        }
    }

    int nodesum,nodesumt=0;
    for(i=0;i<varnum;i++){
        if(intemp[i]==1){
            intemp[i]=allocglo;
            nodesumt=nodesumt+1;
        }
    }
    nodesum=nodesumt;

    for(i=0;i<varnum;i++) for(j=0;j<varnum;j++) graph[i][j]=0;

    //������ͻͼ
    for(i=1;i<blockt;i++){
        for(j=0;j<varnum-1;j++){
            for(k=j+1;k<varnum;k++){
                if(in[i][j]==1&&in[i][k]==1){
                    graph[j][k]=1;
                    graph[k][j]=1;
                }
            }
        }
    }
    //***********************************
    printf("��ͻͼ\n");
    for(i=0;i<varnum;i++){
        for(j=0;j<varnum;j++){
            printf("%d ",graph[i][j]);
        }
        printf("\n");
    }
    printf("************************************\n");
    //***********************************


    int edge=0,nt=0;
    //��ɫ������Ĵ���
    //��ʼ��
     for(i=0;i<varnum;i++){
        nodetemp[i]=0;
        nodetemp2[i]=0;
    }

    //ȥ����ͻ���ֱ��ֻʣһ��
    int indexmin,edgemin,l;
    if(nodesumt>0){
    while(nodesumt!=1){
            edge=0;
            edgemin=1000000;
            //�ұ�����С�Ľ��
            for(l=0;l<varnum;l++){
                if(intemp[l]==allocglo){
                    for(j=0;j<varnum;j++){
                        if(graph[l][j]==1) edge=edge+1;
                    }
                    if(edge<edgemin){
                        edgemin=edge;
                        indexmin=l;
                    }
                }
                edge=0;
            }

            //�����С�ıߴ���REGSUMȥ����
            if(edgemin>=REGNUM){
                nodesumt--;
                nodetemp[nt]=indexmin;
                nodetemp2[nt++]=no;
                intemp[indexmin]=allocno;
                for(i=0;i<varnum;i++){
                    graph[indexmin][i]=0;
                    graph[i][indexmin]=0;
                }
            }

            //�������������REGNUM
            else if(edgemin<REGNUM){
                nodesumt--;
                nodetemp[nt]=indexmin;//�����ջ
                nodetemp2[nt++]=yes;
                intemp[indexmin]=allocyes;
                for(j=0;j<varnum;j++){ //������ͼ��ȥ��
                    graph[indexmin][j]=0;
                    graph[j][indexmin]=0;
                }
            }

    }
    }

    for(i=0;i<nt;i++) printf("%d ",nodetemp[i]);
    printf("\n");

    //��ɫ
    int nodecolor,regt=1;
    //�ҵ���һ����㲢Ϳɫ
    for(i=0;i<varnum;i++){
        if(intemp[i]==allocglo) break;
    }
    printf("%d\n",i);
    intemp[i]=regt++;
    while(nodesumt!=nodesum){
        nodecolor=nodetemp[nodesum-1-nodesumt]; //ȡ��һ����
        if(nodetemp2[nodesum-1-nodesumt]==yes){ //���Ա���ɫ
            if(regt>8) regt=1; //�Ĵ���������Χ
            intemp[nodecolor]=regt++; //��ɫ
        }
        nodesumt++;
    }

    //**********************************
    printf("��ɫ���\n");
    for(i=0;i<varnum;i++) printf("%d ",intemp[i]);
    printf("\n");
    printf("*******************************************\n");
    //************************************

    //����ɫ�����¼�����ű���
    int recordstart=findex[ftempi].vstart;
    for(i=0;i<varnum;i++){
        if(intemp[i]>0) fTab[recordstart+i].reg=intemp[i];
        else fTab[recordstart+i].reg=-1;
    }

    //�ͷſռ�
    for(i=0;i<varnum;i++) free(graph[i]);
    for(i=0;i<blockt+1;i++) free(in[i]);


}

#endif
