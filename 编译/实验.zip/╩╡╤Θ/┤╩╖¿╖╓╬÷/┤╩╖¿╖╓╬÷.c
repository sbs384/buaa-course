#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESERVENUM 13

//����ؼ���ö������
typedef enum type_keyword{
    charsy,constsy,dosy,elsesy,forsy,ifsy,intsy,mainsy,printfsy,returnsy,scanfsy,voidsy,whilesy,idsy,numsy,lequalsy,lesssy,gequalsy,greatsy,equalsy,assignsy,nequalsy,
    charconsy,stringsy,starsy,divisy,commasy,semisy,lparentsy,rparentsy,lbraketsy,rbraketsy,lbracesy,rbracesy,plussy,minussy
}keyword_enum;

//�������
//ll:�����г���ָ��;cc:�ַ�ָ��;num:��¼����;count:����ַ�������;errpos:����λ��ʶ��;errsign:�Ƿ��д����ʶ
int ll=0,cc=0,num=0,count=0,errpos=0,errsign=0;
//ch:��������ַ�;line:��¼����һ�е�����;string:��¼��������ַ���;id:��¼����ķ���;
char ch,line[1024],string[200],id[20];
//���������ļ�ָ��,����ļ�ָ���Լ��������ļ����ָ��
FILE*pin,*poutv,*poute;
//�������洢����
keyword_enum symbol;

//��������
keyword_enum reserve_enum_array[RESERVENUM]={charsy,constsy,dosy,elsesy,forsy,ifsy,intsy,mainsy,printfsy,returnsy,scanfsy,voidsy,whilesy};
char* reserve_string_array[]={"char","const","do","else","for","if","int","main","printf","return","scanf","void","while"}; //�����ֲ�������
char* keyword_string_array[]={
    "charsy","constsy","dosy","elsesy","forsy","ifsy","intsy","mainsy","printfsy","returnsy","scanfsy","voidsy","whilesy","idsy","numsy","lequalsy","lesssy","gequalsy","greatsy","equalsy","assingsy","nequalsy",
    "charconsy","stringsy","starsy","divisy","commasy","semisy","lparentsy","rparentsy","lbraketsy","rbraketsy","lbracesy","rbracesy","plussy","minussy"
}; //�����������


/*
    ������:getch;
    ����:����һ���ַ�,����ֵ����ch��;
*/
void getch(){
    int i;
    char c;

    if(cc==ll){
        i=0;
        memset(line,0,sizeof(line));
        while(1){
            c=fgetc(pin);
            line[i++]=c;
            if(c=='\n'||c==EOF) break;
        }

        if(errsign!=0) fputs("\n",poute);
        fprintf(poute,"%s",line);

        ll=i;
        cc=0;
        errpos=0;
        errsign=0;
    }

    ch=line[cc++];
    //printf("%c\n",ch);
}


/*
    ��������error
    ����:������,�ڸ��еĴ��������ж�λ�������λ�ü�����
    ������룺
        0:�涨���ַ�;
        1:!����=
        2:�ַ��������쳣�ַ�
        3:�ַ���ȱ�ٺ����"
        4:�ַ�����Ϊ�涨���ַ�
        5:�ַ�ȱ�ٺ����'
        6:��������ǰ��ǰ����
*/

void error(int err){
    int i;
    if(errpos<cc){
        for(i=0;i<cc-errpos;i++) fputc(32,poute);
        fputc('^',poute);
        fputc(err+48,poute);
    }
    errpos=cc+2;
    errsign=1;
}

/*
    ������:clearId;
    ����:���id����,Ϊ��һ����ȡ��ʶ����¼��׼��;
*/
void clearId(){
    memset(id,0,sizeof(id));
}

/*
    ������:clearString;
    ����:���string����,Ϊ��¼��һ���ַ�����׼��;
*/
void clearString(){
    memset(string,0,sizeof(string));
}

/*
    ������:binary_search;
    ����:���ֲ��ұ�����;
*/
int binarySearch(){
    int low=0,high=RESERVENUM-1,mid;

    while(low<=high){
        mid=(high+low)/2;

        if(strcmp(id,reserve_string_array[mid])<0) high=mid-1;
        else if(strcmp(id,reserve_string_array[mid])>0) low=mid+1;
        else return mid;
    }
    return -1;
}

/*
    ������:insymbol;
    ����:��ȡ�ַ�����¼;
*/
void insymbol(){
    //id�ַ����±�
    int i=0,bin_result,string_irre=0,string_lack=0;
    char ch_sec;


    clearId();
    clearString();
    num=0;

    while(ch=='\n'||ch=='\t'||ch==' '||ch=='\r'||ch=='\0'){
        getch();
    }

        //��ʶ��
        if((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')||(ch=='_')){
            while((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||(ch=='_')){
                id[i++]=ch;
                getch();
            }

            bin_result=binarySearch();
            if(bin_result>=0) symbol=reserve_enum_array[bin_result];
            else symbol=idsy;
            fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);
        }

        else if(ch=='0'){
            getch();
            if(ch>='0'&&ch<='9'){
                while(ch>='0'&&ch<='9'){
                    num=num*10+(ch-'0');
                    getch();
                }
                symbol=numsy;
                error(6);
            }
            else{
                num=0;
                symbol=numsy;
                fprintf(poutv,"%-15d%-25s%-20d\n",count++,keyword_string_array[symbol],num);
            }
        }

        else if(ch>='1'&&ch<='9'){
            while(ch>='0'&&ch<='9'){
                    num=num*10+(ch-'0');
                    getch();
            }
            symbol=numsy;
            fprintf(poutv,"%-15d%-25s%-20d\n",count++,keyword_string_array[symbol],num);
        }

        else if(ch=='<'){
            id[i++]=ch;
            getch();
            if(ch=='='){
                id[i++]=ch;
                symbol=lequalsy;
                getch();
            }
            else symbol=lesssy;
            fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);

        }

        else if(ch=='>'){
            id[i++]=ch;
            getch();
            if(ch=='='){
                id[i++]=ch;
                symbol=gequalsy;
                getch();
            }
            else symbol=greatsy;
            fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);
        }

        else if(ch=='='){
            id[i++]=ch;
            getch();
            if(ch=='='){
                id[i++]=ch;
                symbol=equalsy;
                getch();
            }
            else symbol=assignsy;
            fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);
        }

        else if(ch=='!'){
            id[i++]=ch;
            getch();
            if(ch=='='){
                id[i++]=ch;
                symbol=nequalsy;
                fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);
                getch();
            }
            else{
                error(1);
                getch();
            }
        }

        else if(ch=='\''){
            getch();
            ch_sec=ch;

            getch();
            if((ch_sec>='0'&&ch_sec<='9')||(ch_sec>='A'&&ch_sec<='Z')||(ch_sec>='a'&&ch_sec<='z')||(ch_sec=='+')||(ch_sec=='-')||(ch_sec=='*')||(ch_sec=='/')||(ch_sec=='_')){
                if(ch=='\''){
                    symbol=charconsy;
                    string[i++]=ch_sec;
                    fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],string);
                    getch();
                }
                else{
                    error(5);
                    getch();
                }
            }
            else{
                error(4);
                getch();
             }
        }

        else if(ch=='\"'){
            symbol=stringsy;
            getch();
            while(ch!='\"'){
                if(!string_irre){
                    if((ch>=35&&ch<=126)||(ch==32)||(ch==33)) string[i++]=ch;
                    else string_irre=1;
                    getch();
                }
                else getch();

                if(ch=='\n'){
                    string_lack=1;
                    break;
                }
            }

            if(string_irre) error(2);
            if(string_lack) error(3);

            if(ch!='\n') getch();
            if(!string_irre&&!string_lack) fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],string);
        }


        else if((ch=='*')||(ch=='/')||(ch==',')||(ch==';')||(ch=='(')||(ch==')')||(ch=='[')||(ch==']')||(ch=='{')||(ch=='}')||(ch=='+')||(ch=='-')){
            switch(ch){
                case '*':symbol=starsy;    break;
                case '/':symbol=divisy;   break;
                case ',':symbol=commasy;   break;
                case ';':symbol=semisy;    break;
                case '(':symbol=lparentsy; break;
                case ')':symbol=rparentsy; break;
                case '[':symbol=lbraketsy; break;
                case ']':symbol=rbraketsy; break;
                case '{':symbol=lbracesy;  break;
                case '}':symbol=rbracesy;  break;
                case '+':symbol=plussy;    break;
                case '-':symbol=minussy;   break;
            }
            id[i++]=ch;
            fprintf(poutv,"%-15d%-25s%-20s\n",count++,keyword_string_array[symbol],id);
            getch();
        }

        else{
            if(ch!=EOF){
                error(0);
                getch();
            }
        }

}


//������
int main(){

    if((pin=fopen("16061094_test.txt","r"))==NULL){
        printf("The file in can't be opened!\n");
        exit(1);
    }
    if((poutv=fopen("outv.txt","w"))==NULL){
        printf("The file out can't be opened!\n");
        exit(1);
    }
    if((poute=fopen("oute.txt","w"))==NULL){
        printf("The file error can't be opened!\n");
        exit(1);
    }

    fputs("Number   MemoryWord     Value\n",poutv);
    getch();

    while(ch!=EOF){
        insymbol();
    }
    printf("end.");

    fclose(pin);
    fclose(poutv);
    fclose(poute);
    return 0;
}
