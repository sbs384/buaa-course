#include <stdio.h>
#include <stdarg.h>
#include "lexcical.h"

#define intty 1
#define charty 0
typedef enum obj_id
{constobj,varobj,fvalobj,fvoiobj,paraobj,nobj}obj_enum; //定义种类枚举常量
//符号表，目前语法分析阶段只有有返回值和无返回值函数调用需要查表，其他分析暂不需要,因此只对函数名进行记录
struct tab{
    char name[20];  //记录符号名字
    obj_enum obj;  //记录符号种类（常量，变量，有返回值函数，无返回值函数，参数）
    int type;  //记录符号类型（int:intty;char:charty）
    int value; //记录常量值
    int len;  //记录数组大小，参数个数
    int size; //记录函数变量和参数所占空间大小
    int addr;  //变量地址，函数表索引
};

int gt; //gt,全局符号表指针
FILE* outg; //语法分析结果输出文件
char cht,cct; //保存词法读取现场变量
keyword_enum syt;
char idt[20];
struct tab globalTab[100]; //定义全局声明符号表


/*global:
    skipflag,errpos,cc,symbol,id,num,string;
*/
void saveNow();
void recover();
int sentHead(keyword_enum symbol);
void skip(int n,...);
void constSta();
void constDef();
void varSta();
void varDef();
void staHead();
int paralist();
void funcDefValue();
void funcDefVoid();
void sentComp();
void sentList();
void sent();
void condition();
void sentIf();
void sentFor();
void sentDoWhile();
void sentPrintf();
void sentScanf();
void sentReturn();
void valueParalist();
void callValueSent();
void callVoidSent();
void sentAssign();
void expression();
void term();
void factor();
void program();
int searchTab();

void saveNow(){
    syt=symbol;
    cct=cc;
    cht=ch;
    strcpy(idt,id);
}

void recover(){
    symbol=syt;
    cc=cct;
    ch=cht;
    strcpy(id,idt);
}

int sentHead(keyword_enum symbol){
    if(symbol==ifsy||symbol==dosy||symbol==forsy||symbol==idsy||symbol==returnsy||symbol==scanfsy||symbol==printfsy||symbol==lbracesy||symbol==semisy) return 1;
    else return 0;
}

int searchTab(){
    int i;
    for(i=0;i<gt;i++){
        if(strcmp(globalTab[i].name,id)==0){
            if(globalTab[i].obj==fvalobj) return 1;
            else if(globalTab[i].obj==fvoiobj) return 0;
            else return -1;
        }
    }
    return -1;
}

void skip(int n,...){
    int i,sign=0;
    keyword_enum symbolset[30]; //定义合法字符集合
    va_list symbollist; //初始化参数列表
    va_start(symbollist,n); //准备开始读参数

    for(i=0;i<n;i++) symbolset[i]=va_arg(symbollist,int); //记录参数列表的内容
    va_end(symbollist); //参数读取完毕

    while(!sign){    //跳读,如果不在合法后继符号集里，则跳读下一个字符直到找到位置
        for(i=0;i<n;i++){
            if(symbol==symbolset[i]){
                sign=1;
                break;
            }
        }
        if(!sign) insymbol();
    }
}

//＜常量说明＞ ::=  const＜常量定义＞;{ const＜常量定义＞;}
void constSta(){ //已经确定了是const
    do{
        insymbol();
        constDef();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(4,constsy,intsy,charsy,voidsy);
        }
        else{
            insymbol();
        }
    }while(symbol==constsy);
    fprintf(outg,"%s","this is a constSta statement\n");
}

//＜常量定义＞::=int＜标识符＞＝＜整数＞{,＜标识符＞＝＜整数＞}| char＜标识符＞＝＜字符＞{,＜标识符＞＝＜字符＞}
void constDef(){ //已经读入了首字符
    int type;

    //处理第一个字符;如果不是类型标识符,则跳读
    if(symbol!=intsy&&symbol!=charsy){
        error(1); //不是类型标识符
        skip(5,intsy,charsy,constsy,voidsy,semisy);
    }
    else{  //类型标识符正确
        if(symbol==intsy) type=1;
        else type=0;

        insymbol();
        if(symbol!=idsy){  //检测第一个标识符，如果不是则跳读
            error(2); //应为标识符
            skip(5,constsy,intsy,charsy,voidsy,semisy);
        }

        //循环处理标识符
        while(symbol==idsy){
            insymbol();
            if(symbol!=assignsy){
                error(3); //缺少=
                skip(5,intsy,charsy,constsy,voidsy,semisy);
            }
            else{
                insymbol();
                if(type==1){
                    if(symbol==minussy||symbol==plussy) insymbol();
                    if(symbol!=numsy){
                        error(4); //缺少整数
                        skip(5,constsy,intsy,charsy,voidsy,semisy);
                    }
                    else{
                        //登表;
                        insymbol();
                        if(symbol==commasy) insymbol();
                    }
                }
                else{
                    if(symbol!=charconsy){
                        error(6); //缺少字符
                        skip(5,constsy,intsy,charsy,voidsy,semisy); //跳读至numsy+commasy+blockset
                    }
                    else{
                        //登表
                        insymbol();
                        if(symbol==commasy) insymbol(); //缺少逗号
                    }
                }
            }
        }
    }
    fprintf(outg,"%s","this is a constDef statement\n");
}

//＜变量说明＞  ::= ＜变量定义＞;{＜变量定义＞;}
void varSta(){ //已确定首字符是int,char
    do{
        varDef();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(3,intsy,charsy,voidsy);
        }
        else insymbol();

        if(symbol==voidsy){
            break;
        }
        else{
            saveNow();
            insymbol();
            insymbol();
            if(symbol==lparentsy){
                recover();
                break;
            }
            else recover();
        }
    }while(symbol==intsy||symbol==charsy);
    fprintf(outg,"%s","this is a varSta statement\n");
}

//＜变量定义＞  ::=(int|char)(＜标识符＞|＜标识符＞'['＜无符号整数＞']'){,(＜标识符＞|＜标识符＞'['＜无符号整数＞']') } //＜无符号整数＞表示数组元素的个数，其值需大于0
void varDef(){ //已确定为int或char
    int type,sign=0;

    if(symbol==intsy) type=1;
    else type=0;

    insymbol();
    if(symbol!=idsy){  //检测第一个标识符，如果不是则跳读
        error(2); //应为标识符
        skip(4,intsy,charsy,voidsy,semisy);
    }

    while(symbol==idsy){
        //登表;
        insymbol();
        if(symbol==lbracketsy){ //处理数组
            insymbol();
            if(symbol!=numsy){
                error(7); //应为数字
                skip(4,intsy,charsy,voidsy,semisy);
            }
            else {
                //记录
                insymbol();
                if(symbol!=rbracketsy){
                    error(8); //应为]
                    skip(4,intsy,charsy,voidsy,semisy);
                }
                else{
                    insymbol();
                    if(symbol==commasy) insymbol();
                }
            }
        }

        else if(symbol==commasy) insymbol();
    }
    fprintf(outg,"%s","this is a varDef statement\n");
}

//＜参数表＞    ::=  ＜类型标识符＞＜标识符＞{,＜类型标识符＞＜标识符＞}| ＜空＞
int paralist(){
    int i=0;
    if(symbol==rparentsy){
        fprintf(outg,"%s","this is a paralist statement\n");
        return 0;
    }
    else{
        if(symbol!=intsy&&symbol!=charsy){
            error(1); //不是类型标识符
            skip(3,intsy,charsy,rbracesy);
        }
        while(symbol==intsy||symbol==charsy){
            insymbol();
            if(symbol!=idsy) error(2); //应为标识符
            else{
                i++;
                insymbol();
                if(symbol==commasy) insymbol();
            }
        }
        fprintf(outg,"%s","this is a paralist statement\n");
        return i;
    }

}

//＜声明头部＞   ::=  int＜标识符＞|char＜标识符＞
//＜有返回值函数定义＞  ::= ＜声明头部＞'('＜参数表＞')' '{'＜复合语句＞'}'
void funcDefValue(){ //已经确定首字符是int或char
    int type; //return值检测

    if(symbol==intsy) type=1;
    else type=0;

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(4,idsy,intsy,charsy,voidsy); //没有标识符,则找到标识符或抛弃该函数定义
    }
    if(symbol==idsy){
        fprintf(outg,"%s","this is a staHead statement\n");
        //头部声明结束,登表
        strcpy(globalTab[gt].name,id);
        globalTab[gt].obj=fvalobj;
        gt++;

        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(4,lparentsy,intsy,charsy,voidsy); //没有(,则找到(位置或抛弃啊该函数定义
        }
        if(symbol==lparentsy){
            insymbol();
            paralist();
            if(symbol!=rparentsy){
                error(11); //缺)
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            if(symbol!=lbracesy){
                error(12); //缺{
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            sentComp();
            if(symbol!=rbracesy){
                error(13); //缺}
                skip(3,intsy,charsy,voidsy);
            }
            else insymbol();
        }
    }
    fprintf(outg,"%s","this is a funcDefValue statement\n");
}



//＜无返回值函数定义＞  ::= void＜标识符＞'('＜参数表＞')''{'＜复合语句＞'}'
void funcDefVoid(){ //已经确定首字符是void
    int type; //return值检测

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(4,idsy,intsy,charsy,voidsy); //没有标识符,则找到标识符或抛弃该函数定义
    }
    if(symbol==idsy){
        fprintf(outg,"%s","this is a staHead statement\n");
        //头部声明结束,登表
        strcpy(globalTab[gt].name,id);
        globalTab[gt].obj=fvoiobj;
        gt++;

        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(4,lparentsy,intsy,charsy,voidsy); //没有(,则找到(位置或抛弃啊该函数定义
        }
        if(symbol==lparentsy){
            insymbol();
            paralist();
            if(symbol!=rparentsy){
                error(11); //缺)
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            if(symbol!=lbracesy){
                error(12); //缺{
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            sentComp();
            if(symbol!=rbracesy){
                error(13); //缺}
                skip(3,intsy,charsy,voidsy);
            }
            else insymbol();
        }
    }
    fprintf(outg,"%s","this is a funcDefVoid statement\n");
}

//＜复合语句＞   ::=  ［＜常量说明＞］［＜变量说明＞］＜语句列＞
void sentComp(){ //已经读入一个词
    if(symbol==constsy){
        constSta();
        if(symbol!=intsy&&symbol!=charsy&&symbol!=ifsy&&symbol!=dosy&&symbol!=forsy&&symbol!=idsy&&symbol!=returnsy&&symbol!=scanfsy&&symbol!=printfsy&&symbol!=lbracesy&&symbol!=rbracesy&&symbol!=semisy){
            error(18);
            skip(12,intsy,charsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        if(symbol==intsy||symbol==charsy) goto LvarSta;
        else goto LsentList;
    }
    else if(symbol==intsy||symbol==charsy){
LvarSta:
        varSta();
        if(symbol!=ifsy&&symbol!=dosy&&symbol!=forsy&&symbol!=idsy&&symbol!=returnsy&&symbol!=scanfsy&&symbol!=printfsy&&symbol!=lbracesy&&symbol!=rbracesy&&symbol!=semisy){
            error(18);
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        goto LsentList;
    }
    else{
LsentList:
        sentList();
    }
    fprintf(outg,"%s","this is a sentComp statement\n");
}

//＜语句列＞   ::=｛＜语句＞｝
void sentList(){
    while(sentHead(symbol)){
        sent();
    }
    fprintf(outg,"%s","this is a sentList statement\n");
}

//＜语句＞    ::= ＜条件语句＞｜＜循环语句＞| '{'＜语句列＞'}'｜＜有返回值函数调用语句＞; |＜无返回值函数调用语句＞;｜＜赋值语句＞;｜＜读语句＞;｜＜写语句＞;｜＜空＞;｜＜返回语句＞;
void sent(){ //进入语句是合法的首字符
    if(symbol==ifsy){
        sentIf();
    }
    else if(symbol==forsy){
        sentFor();
    }
    else if(symbol==dosy){
        sentDoWhile();
    }
    else if(symbol==lbracesy){
        insymbol();
        sentList();
        if(symbol!=rbracesy){
            error(13);
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==semisy){
        insymbol();
    }
    else if(symbol==scanfsy){
        sentScanf();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==printfsy){
        sentPrintf();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==returnsy){
        sentReturn();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else{ //idsy
        saveNow();
        insymbol();
        if(symbol==assignsy||symbol==lbracketsy){
            recover();
            sentAssign();
            if(symbol!=semisy){
                error(0); //缺分号
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
        else if(symbol==lparentsy){
            recover();
            if(searchTab()==1) callValueSent();
            else callVoidSent();

            if(symbol!=semisy){
                error(0); //缺分号
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
        else{
            error(14); //应为(或[或=
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
    }
    fprintf(outg,"%s","this is a sent statement\n");
}

//＜条件＞    ::=  ＜表达式＞＜关系运算符＞＜表达式＞｜＜表达式＞ //表达式为0条件为假，否则为真
void condition(){
    expression();
    if(symbol==equalsy||symbol==nequalsy||symbol==greatsy||symbol==gequalsy||symbol==lesssy||symbol==lequalsy){
        fprintf(outg,"%s","this is a compare statement\n");
        insymbol();
        expression();
    }
    fprintf(outg,"%s","this is a condition statement\n");
}

//＜条件语句＞  ::=  if '('＜条件＞')'＜语句＞［else＜语句＞］
void sentIf(){ //确定为if
    insymbol();
    if(symbol!=lparentsy){
        error(10);
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        condition();
        if(symbol!=rparentsy){
            error(11); //缺少)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else {
            insymbol();
            sent();
            if(symbol==elsesy){
                insymbol();
                sent();
            }
        }
    }
    fprintf(outg,"%s","this is a sentIf statement\n");
}

//＜步长＞::= ＜无符号整数＞ 
//for'('＜标识符＞＝＜表达式＞;＜条件＞;＜标识符＞＝＜标识符＞(+|-)＜步长＞')'＜语句＞
void sentFor(){
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=assignsy){
        error(3); //缺=
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    expression();
    if(symbol!=semisy){
        error(0); //缺;
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    condition();
    if(symbol!=semisy){
        error(0); //缺;
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=assignsy){
        error(3); //缺=
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=plussy&&symbol!=minussy){
        error(16);
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=numsy){
        error(4); //缺少整数
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    fprintf(outg,"%s","this is a step statement\n");

    insymbol();
    if(symbol!=rparentsy){
        error(11); //缺)
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    sent();
    fprintf(outg,"%s","this is a sentFor statement\n");
}

//do＜语句＞while '('＜条件＞')'
void sentDoWhile(){
    insymbol();
    sent();
    if(symbol!=whilesy){
        error(15); //缺while关键字
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            insymbol();
            condition();
            if(symbol!=rparentsy){
                error(15); //缺while关键字
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
    }
    fprintf(outg,"%s","this is a sentDoWhile statement\n");
}


//＜写语句＞    ::=  printf'('＜字符串＞,＜表达式＞')'|printf '('＜字符串＞')'|printf '('＜表达式＞')'
void sentPrintf(){
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else {
        insymbol();
        if(symbol==stringsy){
            fprintf(outg,"%s","this is a string statement\n");
            insymbol();
            if(symbol==commasy){
                insymbol();
                expression();
            }
        }
        else{
            expression();
        }

        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    fprintf(outg,"%s","this is a sentPrintf statement\n");
}

//＜读语句＞    ::=  scanf '('＜标识符＞{,＜标识符＞}')'
void sentScanf(){
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        if(symbol!=idsy){
            error(2); //应为标识符
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            while(symbol==idsy){
                insymbol();
                if(symbol==commasy) insymbol();
            }


            if(symbol!=rparentsy){
                error(11); //缺)
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
    }
    fprintf(outg,"%s","this is a sentScanf statement\n");
}
//＜返回语句＞   ::=  return['('＜表达式＞')']
void sentReturn(){
    insymbol();
    if(symbol==lparentsy){
        insymbol();
        expression();
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    fprintf(outg,"%s","this is a sentReturn statement\n");
}

//＜值参数表＞   ::= ＜表达式＞{,＜表达式＞}｜＜空＞
void valueParalist(){
    int i=0;
    if(symbol==rparentsy){
        fprintf(outg,"%s","this is a valueParalist statement\n");
        return;
    }
    expression();
    //暂且认为返回值正确
    while(symbol==commasy){
        insymbol();
        expression();
    }
    fprintf(outg,"%s","this is a valueParalist statement\n");
}

//＜有返回值函数调用语句＞ ::= ＜标识符＞'('＜值参数表＞')'
void callValueSent(){ //已经确定是标识符开头
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        valueParalist();
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    fprintf(outg,"%s","this is a callValueSent statement\n");
}
//＜无返回值函数调用语句＞ ::= ＜标识符＞'('＜值参数表＞')'
void callVoidSent(){
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        valueParalist();
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(9,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    fprintf(outg,"%s","this is a callVoidSent statement\n");
}

//＜赋值语句＞   ::=  ＜标识符＞＝＜表达式＞|＜标识符＞'['＜表达式＞']'=＜表达式＞
void sentAssign(){
    insymbol();
    if(symbol==assignsy){
        insymbol();
        expression();
    }
    else if(symbol==lbracketsy){
        insymbol();
        expression();
        if(symbol!=rbracketsy){
            error(8); //缺]
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            insymbol();
            if(symbol!=assignsy){
                error(3); //缺=
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else{
                insymbol();
                expression();
            }
        }
    }
    fprintf(outg,"%s","this is a sentAssign statement\n");
}

//＜表达式＞    ::= ［＋｜－］＜项＞{＜加法运算符＞＜项＞}   //[+|-]只作用于第一个<项>
void expression(){
    int type;
    if(symbol==plussy||symbol==minussy) {
        if(symbol==plussy) type=1;
        else type=0;
        insymbol();
        term();
        while(symbol==minussy||symbol==plussy){
            fprintf(outg,"%s","this is a plus statement\n");
            insymbol();
            term();
        }
    }
    else{
        term();
        while(symbol==minussy||symbol==plussy){
            fprintf(outg,"%s","this is a plus statement\n");
            insymbol();
            term();
        }
    }
    fprintf(outg,"%s","this is a expression statement\n");
}

//＜项＞     ::= ＜因子＞{＜乘法运算符＞＜因子＞}
void term(){
    factor();
    while(symbol==starsy||symbol==divisy){
        fprintf(outg,"this is a mult statement\n");
        insymbol();
        factor();
    }
    fprintf(outg,"%s","this is a term statement\n");
}
//＜因子＞    ::= ＜标识符＞｜＜标识符＞'['＜表达式＞']'｜＜整数＞|＜字符＞｜＜有返回值函数调用语句＞|'('＜表达式＞')'
void factor(){
    if(symbol==idsy){
        saveNow();
        insymbol();
        //数组
        if(symbol==lbracketsy){
            insymbol();
            expression();
            if(symbol!=rbracketsy){
                error(8); //应为]
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
        else if(symbol==lparentsy){
            recover();
            callValueSent();
        }
    }
    //数字
    else if(symbol==numsy){
        fprintf(outg,"%s","this is a wholenum statement\n");
        insymbol();
    }
    else if(symbol==minussy||symbol==plussy){
        insymbol();
        if(symbol!=numsy){
            error(4); //缺少整数
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            fprintf(outg,"%s","this is a wholenum statement\n");
            insymbol();
        }
    }
    //字符
    else if(symbol==charconsy) insymbol();
    //(表达式)
    else if(symbol==lparentsy){
        insymbol();
        expression();
        if(symbol!=rparentsy){
            error(11); //应为)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else{
        error(17); //错误因子成分
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    fprintf(outg,"%s","this is a factor\n");
}

void mainFunc(){
    mexist=1;

    insymbol();
    if(symbol!=lparentsy){
		error(10);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	if(symbol!=rparentsy){
		error(11);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	if(symbol!=lbracesy){
		error(12);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	sentComp();

	if(symbol!=rbracesy) {
        fprintf(outg,"%s","this is a mainFunc statement\n");
        error(13);
        skip(0);
	}
	else{
        fprintf(outg,"%s","this is a mainFunc statement\n");
        insymbol();
        error(20);
        skip(0);
	}

}


//＜程序＞::= ［＜常量说明＞］［＜变量说明＞］{＜有返回值函数定义＞|＜无返回值函数定义＞}＜主函数＞
void program(){
    //检测合法起始符号
    if(symbol!=constsy&&symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
        error(18);
        skip(4,constsy,intsy,charsy,voidsy);
    }

    if(symbol==constsy){
        constSta();

        //检测合法后继
        if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
            error(19);
            skip(3,intsy,charsy,voidsy);
        }

        if(symbol==intsy||symbol==charsy) goto intchar;
        else goto fundef; //void
    }

    if(symbol==intsy||symbol==charsy){

intchar:
        saveNow();
        insymbol();
        insymbol();
        if(symbol==lparentsy){
            recover();
            goto fundef;
        }
        else{
            recover();
            varSta();
            //检测合法后继
            if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                error(18);
                skip(3,intsy,charsy,voidsy);
            }
        }
    }

fundef:

    while(symbol==intsy||symbol==charsy||symbol==voidsy){ //进入有返回值函数前恢复现场;void函数恢复现场
            if(symbol==intsy||symbol==charsy){
                funcDefValue(); //有返回值函数定义
                //检测合法后继
                if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                    error(18);
                    skip(3,intsy,charsy,voidsy);
                }
            }
            else{
                saveNow();
                insymbol();
                if(symbol==mainsy) break; //main函数处理
                else{
                    recover();
                    funcDefVoid(); //无返回值函数定义
                    //检测合法后继
                    if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                        error(18);
                        skip(3,intsy,charsy,voidsy);
                    }
                }
            }
        }

        mainFunc();
        fprintf(outg,"%s\n","this is a programm statement");
}


int main(){
    char filename[50];
    scanf("%s",filename);
    if((outg=fopen("grammar.txt","w"))==NULL){
        printf("The file can't be opened!");
        exit(1);
    }
     if((pin=fopen(filename,"r"))==NULL){
        printf("The file in can't be opened!\n");
        exit(1);
    }
    if((poutv=fopen("outv.txt","w"))==NULL){
        printf("The file out can't be opened!\n");
        exit(1);
    }
    if((poute=fopen("oute.txt","w"))==NULL){
        printf("The file error can't be opened!\n");
        exit(1);
    }
    fputs("Number   MemoryWord     Value\n",poutv);

    getch();
    insymbol();
    program();

    fclose(pin);
    fclose(poutv);
    fclose(poute);
    fclose(outg);

    return 0;
}
