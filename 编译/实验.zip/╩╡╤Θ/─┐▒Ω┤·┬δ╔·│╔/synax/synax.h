#ifndef _SYNAX_H_
#define _SYNAX_H_
#include <stdio.h>
#include <stdarg.h>
#include "lexcical.h"
#include "error.h"
#include "global.h"
#include "midcode.h"

#define intty  0
#define charty 1
#define noty   -1
#define ADDRSTART 8

typedef enum obj_id{constobj,varobj,fvalobj,fvoiobj,paraobj,arrayobj}obj_enum; //定义种类枚举常量

//符号表
struct tab{
    char name[idsize];  //记录符号名字
    obj_enum obj;  //记录符号种类（常量，变量，有返回值函数，无返回值函数，参数,数组）
    int type;  //记录符号类型（int:intty;char:charty;变量常量参数数组,函数返回值）
    int len;  //记录数组大小，参数个数,常量值
    int size; //记录函数变量和参数所占空间大小
    int addr;  //变量地址，函数表索引
};

struct funcindex{
    int gt; //记录该函数在gTab中的位置
    int vstart; //函数局部变量在fTab中开始的索引
    int vend;  //函数局部变量在fTab中结束的索引
    int tstart; //函数临时变量在tTab中开始的索引
    int tend; //函数临时变量在tTab中结束的索引
};

/*
gTab
-------------------------
        全局常量
-------------------------
        全局变量
-------------------------   ----->gn
        函数名(addr)---------|
-------------------------    |
                             |
fTab <-----------------------|
-------------------------
        参数
-------------------------
        局部常量
-------------------------
        局部变量
--------------------------
*/
int gt=0,ft=0,gn=0,lev=0,funcnum=0; //gt,全局符号表指针;ft,函数符号表指针;gn,全局变量常量指针值+1;lev,记录函数层次内部还是全局层次;funcnum,定义的函数个数
int retsign;
struct tab gTab[tabsize],fTab[tabsize]; //定义符号表
struct funcindex findex[fsize]; //定义函数索引结构数组
char cht,cct; //保存词法读取现场变量
keyword_enum syt;
//填表有关变量
char idt[idsize];//name,保存需要填表的符号名称
int type,len,size,addr=0;
obj_enum obj;
char* obj_string[]={"constobj","varobj","fvalobj","fvoiobj","paraobj","arrayobj"};

//语法相关函数
void skip(int n,...);
void saveNow();
void recover();
int sentHead(keyword_enum symbol);
void constSta();
void constDef();
void varSta();
void varDef();
void staHead();
int paralist();
void funcDefValue();
void funcDefVoid();
void sentComp();
void sentList();
void sent();
void condition();
void sentIf();
void sentFor();
void sentDoWhile();
void sentPrintf();
void sentScanf();
void sentReturn();
void valueParalist(int index);
void callValueSent(int index);
void callVoidSent(int index);
void sentAssign();
int expression();
int term();
int factor();
void program();
//语义相关函数
void insertTab(char* name,obj_enum obj,int type,int len,int size,int addr);
int redefine(char *name,int tab);
int searchTab(char* name,obj_enum obj,int* tadd);
void printfgfTab();

void skip(int n,...){
    int i,sign=0;
    keyword_enum symbolset[30]; //定义合法字符集合
    va_list symbollist; //初始化参数列表
    va_start(symbollist,n); //准备开始读参数

    for(i=0;i<n;i++) symbolset[i]=va_arg(symbollist,int); //记录参数列表的内容
    va_end(symbollist); //参数读取完毕

    while(sign==0){    //跳读,如果不在合法后继符号集里，则跳读下一个字符直到找到位置
        for(i=0;i<n;i++){
            if(symbol==symbolset[i]){
                sign=1;
                break;
            }
        }
        if(symbol==eofsy) sign=1;
        if(sign==0) insymbol();
    }
}

void saveNow(){
    syt=symbol;
    cct=cc;
    cht=ch;
    strcpy(idt,id);
}

void recover(){
    symbol=syt;
    cc=cct;
    ch=cht;
    strcpy(id,idt);
}

int sentHead(keyword_enum symbol){
    if(symbol==ifsy||symbol==dosy||symbol==forsy||symbol==idsy||symbol==returnsy||symbol==scanfsy||symbol==printfsy||symbol==lbracesy||symbol==semisy) return 1;
    else return 0;
}

/*
    不重名-->登表
*/
//需要登表的:全局变量常量;函数名及函数变量常量gTab
void insertTab(char* name,obj_enum obj,int type,int len,int size,int addr){
    int rede;

    if(ft==tabsize||gt==tabsize){
        error(28);  //符号表满
        exit(1);
    }
    else{
        //重定义检测
        if(obj==fvalobj||obj==fvoiobj) rede=redefine(name,0); //函数重定义
        else if(obj==paraobj) rede=redefine(name,1); //参数重定义
        else if(obj==constobj||obj==varobj||obj==arrayobj){
            if(lev==0) rede=redefine(name,0); //全局变量常量重定义
            else rede=redefine(name,1); //函数内变量常量重定义
        }

        //插入表
        if(rede==1) error(29); //定义重复
        else{
            if(lev==0){  //插入全局表
                strcpy(gTab[gt].name,name);
                gTab[gt].obj=obj;
                gTab[gt].type=type;
                gTab[gt].len=len;
                gTab[gt].size=size;
                gTab[gt].addr=addr;
                gt++;
            }
            else{
                strcpy(fTab[ft].name,name);
                fTab[ft].obj=obj;
                fTab[ft].type=type;
                fTab[ft].len=len;
                fTab[ft].size=size;
                fTab[ft].addr=addr;
                ft++;
            }
        }
    }
}

/*
*/
//tab=0,全局变量常量函数;tab=1,函数内变量常量参数
int redefine(char *name,int tab){
    int i;
    if(tab==0){ //0--->ft 全局量
        for(i=0;i<gt;i++){
            if(strcmp(gTab[i].name,name)==0) return 1;
        }
        return 0;
    }
    else{ //函数开头--->gt 函数内部变常量
         for(i=gTab[gt-1].addr;i<ft;i++){
            if(strcmp(fTab[i].name,name)==0) return 1;
        }
        return 0;
    }
}

/*
    返回在gTab或fTab中的索引位置;&tadd=0,在gTab中的索引;&tadd=1,在fTab中的索引
*/
int searchTab(char* name,obj_enum obj,int* tadd){
    int i;
    if(obj==fvoiobj||obj==fvalobj){ //查找函数名
        for(i=gn;i<gt;i++){
            if(strcmp(gTab[i].name,name)==0){
                *tadd=0;
                return i;
            }
        }
        *tadd=0;
        return -1;
    }
    else{ //查找变量常量参数数组
        for(i=gTab[gt-1].addr;i<ft;i++){
            if(strcmp(fTab[i].name,name)==0){
                *tadd=1;
                return i;
            }
        }
        for(i=0;i<gn;i++){
            if(strcmp(gTab[i].name,name)==0){
                *tadd=0;
                return i;
            }
        }
        *tadd=0;
        return -1;
    }
}

void printfgfTab(){
    int i;
    FILE* tab;
    if((tab=fopen("fgTab.txt","w"))==NULL){
        printf("The file can't be opened!\n");
        exit(1);
    }
    fprintf(tab,"********************************gTab***********************************\n");
    fprintf(tab,"name     obj      type      len       size      addr\n");
    for(i=0;i<gt;i++) fprintf(tab,"%s     %s      %d      %d      %d      %d\n",gTab[i].name,obj_string[gTab[i].obj],gTab[i].type,gTab[i].len,gTab[i].size,gTab[i].addr);
    fprintf(tab,"********************************fTab***********************************\n");
    fprintf(tab,"name     obj      type      len       size      addr\n");
    for(i=0;i<ft;i++) fprintf(tab,"%s     %s      %d      %d      %d      %d\n",fTab[i].name,obj_string[fTab[i].obj],fTab[i].type,fTab[i].len,fTab[i].size,fTab[i].addr);
}

//＜常量说明＞ ::=  const＜常量定义＞;{ const＜常量定义＞;}
void constSta(){ //已经确定了是const
    do{
        insymbol();
        constDef();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(4,constsy,intsy,charsy,voidsy);
        }
        else{
            insymbol();
        }
    }while(symbol==constsy);
    fprintf(outg,"%s","this is a constSta statement\n");
}

//＜常量定义＞::=int＜标识符＞＝＜整数＞{,＜标识符＞＝＜整数＞}| char＜标识符＞＝＜字符＞{,＜标识符＞＝＜字符＞}
void constDef(){ //已经读入了首字符
    int type,positive=1;
    char name[idsize],strnum[numsize];

    //处理第一个字符;如果不是类型标识符,则跳读
    if(symbol!=intsy&&symbol!=charsy){
        error(1); //不是类型标识符
        skip(5,intsy,charsy,constsy,voidsy,semisy);
    }
    else{  //类型标识符正确
        if(symbol==intsy) type=intty;
        else type=charty;

        insymbol();
        if(symbol!=idsy){  //检测第一个标识符，如果不是则跳读
            error(2); //应为标识符
            skip(5,constsy,intsy,charsy,voidsy,semisy);
        }

        //循环处理标识符
        while(symbol==idsy){
            memset(name,0,idsize);
            strcpy(name,id); //记录当前常量名字

            insymbol(); //=
            if(symbol!=assignsy){
                error(3); //缺少=
                skip(5,intsy,charsy,constsy,voidsy,semisy);
            }
            else{
                insymbol();
                if(type==intty){ //常量是整数
                    if(symbol==minussy||symbol==plussy){
                        if(symbol==minussy) positive=0;
                        insymbol();
                    }
                    if(symbol!=numsy){
                        error(4); //缺少整数(语法层次检测赋值前后类型匹配)
                        skip(5,constsy,intsy,charsy,voidsy,semisy);
                    }
                    else{
                        if(positive==0) len=-num;
                        else len=num;
                        positive=1;

                        //********登表********
                        insertTab(name,constobj,intty,len,0,0);
                        memset(strnum,0,numsize);
                        sprintf(strnum,"%d",len);
                        //######生成四元式######
                        midcode(CONI,name,strnum,NULL);

                        insymbol();
                        if(symbol==commasy) insymbol();
                    }
                }
                else{
                    if(symbol!=charconsy){
                        error(6); //缺少字符(语法层次检测赋值前后类型匹配)
                        skip(5,constsy,intsy,charsy,voidsy,semisy); //跳读至numsy+commasy+blockset
                    }
                    else{
                        //******登表******
                        insertTab(name,constobj,charty,num,0,0);
                        memset(strnum,0,numsize);
                        sprintf(strnum,"%d",num);
                        //######生成四元式######
                        midcode(CONC,name,strnum,NULL);

                        insymbol();
                        if(symbol==commasy) insymbol(); //缺少逗号
                    }
                }
            }
        }
    }
    fprintf(outg,"%s","this is a constDef statement\n");
}

//＜变量说明＞  ::= ＜变量定义＞;{＜变量定义＞;}
void varSta(){ //已确定首字符是int,char
    do{
        varDef();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(3,intsy,charsy,voidsy);
        }
        else insymbol();

        if(symbol==voidsy){
            break;
        }
        else{
            saveNow();
            insymbol();
            insymbol();
            if(symbol==lparentsy){
                recover();
                break;
            }
            else recover();
        }
    }while(symbol==intsy||symbol==charsy);
    fprintf(outg,"%s","this is a varSta statement\n");
}

//＜变量定义＞  ::=(int|char)(＜标识符＞|＜标识符＞'['＜无符号整数＞']'){,(＜标识符＞|＜标识符＞'['＜无符号整数＞']') } //＜无符号整数＞表示数组元素的个数，其值需大于0
void varDef(){ //已确定为int或char
    int type;
    char name[idsize],strnum[numsize];

    if(symbol==intsy) type=intty;
    else type=charty;

    insymbol();
    if(symbol!=idsy){  //检测第一个标识符，如果不是则跳读
        error(2); //应为标识符
        skip(4,intsy,charsy,voidsy,semisy);
    }

    while(symbol==idsy){
        memset(name,0,idsize);
        strcpy(name,id);
        insymbol();

        if(symbol==lbracketsy){ //处理数组
            insymbol();
            if(symbol!=numsy){
                error(7); //应为数字
                skip(4,intsy,charsy,voidsy,semisy);
            }
            else {
                len=num; //记录数组元素个数
                if(len==0) error(30);//数组元素个数应大于零
                else{
                    insymbol();
                    if(symbol!=rbracketsy){
                        error(8); //应为]
                        skip(4,intsy,charsy,voidsy,semisy);
                    }
                    else{
                        //******登表******
                        size=len*4;
                        insertTab(name,arrayobj,type,len,size,addr);
                        addr+=size;
                        //######生成四元式######
                        memset(strnum,0,numsize);
                        sprintf(strnum,"%d",len);
                        if(type==intty) midcode(VARI,name,strnum,NULL);
                        else midcode(VARC,name,strnum,NULL);

                        insymbol();
                        if(symbol==commasy) insymbol();
                    }
                }
            }
        }
        else{
            //******登表******
            insertTab(name,varobj,type,1,4,addr);
            addr+=4;
            //######生成四元式######
            if(type==intty) midcode(VARI,name,"\0",NULL);
            else midcode(VARC,name,"\0",NULL);

            if(symbol==commasy) insymbol();
        }
    }
    fprintf(outg,"%s","this is a varDef statement\n");
}

//＜参数表＞    ::=  ＜类型标识符＞＜标识符＞{,＜类型标识符＞＜标识符＞}| ＜空＞
int paralist(){
    int i=0,type;
    char name[idsize];

    if(symbol==rparentsy){
        fprintf(outg,"%s","this is a paralist statement\n");
        return 0;
    }
    else{
        if(symbol!=intsy&&symbol!=charsy){
            error(1); //不是类型标识符
            skip(3,intsy,charsy,rbracesy);
        }
        while(symbol==intsy||symbol==charsy){
            if(symbol==intsy) type=intty;
            else  type=charty;

            insymbol();
            if(symbol!=idsy) error(2); //应为标识符
            else{
                i++;
                memset(name,0,idsize);
                strcpy(name,id);
                //******登表******
                insertTab(name,paraobj,type,1,4,addr);
                addr+=4;
                //######生成四元式######
                if(type==intty) midcode(PARAI,name,NULL,NULL);
                else midcode(PARAC,name,NULL,NULL);

                insymbol();
                if(symbol==commasy) insymbol();
            }
        }
        fprintf(outg,"%s","this is a paralist statement\n");
        return i;
    }

}

//＜声明头部＞   ::=  int＜标识符＞|char＜标识符＞
//＜有返回值函数定义＞  ::= ＜声明头部＞'('＜参数表＞')' '{'＜复合语句＞'}'
void funcDefValue(){ //已经确定首字符是int或char
    int type,i,sumsize=0; //return值检测
    char name[idsize];

    retsign=0;
    addr=ADDRSTART;

    if(symbol==intsy) type=intty;
    else type=charty;

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(4,idsy,intsy,charsy,voidsy); //没有标识符,则找到标识符或抛弃该函数定义
    }
    if(symbol==idsy){
        memset(name,0,idsize);
        strcpy(name,id); //记录函数名
        fprintf(outg,"%s","this is a staHead statement\n");

        //******登表******
        insertTab(name,fvalobj,type,0,0,ft);
        //######生成四元式######
        if(type==intty) midcode(FUNDEFI,name,NULL,NULL);
        else midcode(FUNDEFC,name,NULL,NULL);

        lev=1;
        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(4,lparentsy,intsy,charsy,voidsy); //没有(,则找到(位置或抛弃啊该函数定义
        }
        if(symbol==lparentsy){
            insymbol();
            len=paralist(); //记录参数个数
            gTab[gt-1].len=len; //填函数表中的len域

            if(symbol!=rparentsy){
                error(11); //缺)
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            if(symbol!=lbracesy){
                error(12); //缺{
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            sentComp();
            if(retsign==0) error(46); //有返回值函数没有return语句
            if(symbol!=rbracesy){
                error(13); //缺}
                skip(3,intsy,charsy,voidsy);
            }
            else insymbol();
        }

        retsign=0;
        midcode(FUNEND,gTab[gt-1].name,NULL,NULL);

        for(i=gTab[gt-1].addr;i<ft;i++) sumsize=sumsize+fTab[i].size; //计算函数变量和参数占空间总大小
        gTab[gt-1].size=sumsize;
        lev=0; //函数声明结束恢复lev和addr值
        addr=ADDRSTART;

        findex[funcnum].gt=gt-1;
        findex[funcnum].vstart=gTab[gt-1].addr;
        findex[funcnum].vend=ft;
        funcnum++;
    }
    fprintf(outg,"%s","this is a funcDefValue statement\n");
}



//＜无返回值函数定义＞  ::= void＜标识符＞'('＜参数表＞')''{'＜复合语句＞'}'
void funcDefVoid(){ //已经确定首字符是void
    int type,i,sumsize=0; //return值检测
    char name[idsize];

    retsign=0;
    addr=ADDRSTART;
    type=noty;

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(4,idsy,intsy,charsy,voidsy); //没有标识符,则找到标识符或抛弃该函数定义
    }
    if(symbol==idsy){
        memset(name,0,idsize);
        strcpy(name,id); //记录函数名
        fprintf(outg,"%s","this is a staHead statement\n");

        //******登表******
        insertTab(name,fvoiobj,type,0,0,ft);
        //######生成四元式######
        midcode(FUNDEFV,name,NULL,NULL);

        lev=1;
        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(4,lparentsy,intsy,charsy,voidsy); //没有(,则找到(位置或抛弃啊该函数定义
        }
        if(symbol==lparentsy){
            insymbol();
            len=paralist();
            gTab[gt-1].len=len;

            if(symbol!=rparentsy){
                error(11); //缺)
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            if(symbol!=lbracesy){
                error(12); //缺{
                skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
            }
            else insymbol();

            sentComp();
            if(symbol!=rbracesy){
                error(13); //缺}
                skip(3,intsy,charsy,voidsy);
            }
            else insymbol();
        }
    }

    if(retsign==0) midcode(RET,NULL,NULL,NULL);
    retsign=0;
    midcode(FUNEND,gTab[gt-1].name,NULL,NULL);

    for(i=gTab[gt-1].addr;i<ft;i++) sumsize=sumsize+fTab[i].size; //计算函数变量和参数占空间总大小
    gTab[gt-1].size=sumsize;
    lev=0; //函数声明结束恢复lev和addr值
    addr=ADDRSTART;

    findex[funcnum].gt=gt-1;
    findex[funcnum].vstart=gTab[gt-1].addr;
    findex[funcnum].vend=ft;
    funcnum++;

    fprintf(outg,"%s","this is a funcDefVoid statement\n");

}

//＜复合语句＞   ::=  ［＜常量说明＞］［＜变量说明＞］＜语句列＞
void sentComp(){ //已经读入一个词
    if(symbol==constsy){
        constSta();
        if(symbol!=intsy&&symbol!=charsy&&symbol!=ifsy&&symbol!=dosy&&symbol!=forsy&&symbol!=idsy&&symbol!=returnsy&&symbol!=scanfsy&&symbol!=printfsy&&symbol!=lbracesy&&symbol!=rbracesy&&symbol!=semisy){
            error(18);
            skip(12,intsy,charsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        if(symbol==intsy||symbol==charsy) goto LvarSta;
        else goto LsentList;
    }
    else if(symbol==intsy||symbol==charsy){
LvarSta:
        varSta();
        if(symbol!=ifsy&&symbol!=dosy&&symbol!=forsy&&symbol!=idsy&&symbol!=returnsy&&symbol!=scanfsy&&symbol!=printfsy&&symbol!=lbracesy&&symbol!=rbracesy&&symbol!=semisy){
            error(18);
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        goto LsentList;
    }
    else{
LsentList:
        sentList();
    }
    fprintf(outg,"%s","this is a sentComp statement\n");
}

//＜语句列＞   ::=｛＜语句＞｝
void sentList(){
    while(sentHead(symbol)){
        sent();
    }
    fprintf(outg,"%s","this is a sentList statement\n");
}

//＜语句＞    ::= ＜条件语句＞｜＜循环语句＞| '{'＜语句列＞'}'｜＜有返回值函数调用语句＞; |＜无返回值函数调用语句＞;｜＜赋值语句＞;｜＜读语句＞;｜＜写语句＞;｜＜空＞;｜＜返回语句＞;
void sent(){ //进入语句是合法的首字符
    int index,tadd;
    char name[idsize];

    if(symbol==ifsy){
        sentIf();
    }
    else if(symbol==forsy){
        sentFor();
    }
    else if(symbol==dosy){
        sentDoWhile();
    }
    else if(symbol==lbracesy){
        insymbol();
        sentList();
        if(symbol!=rbracesy){
            error(13);
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==semisy){
        insymbol();
    }
    else if(symbol==scanfsy){
        sentScanf();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==printfsy){
        sentPrintf();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else if(symbol==returnsy){
        sentReturn();
        if(symbol!=semisy){
            error(0); //缺分号
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();
    }
    else{ //idsy
        memset(name,0,idsize);
        strcpy(name,id);
        saveNow();
        insymbol();
        if(symbol==assignsy||symbol==lbracketsy){
            recover();
            sentAssign();
            if(symbol!=semisy){
                error(0); //缺分号
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
        else if(symbol==lparentsy){
            recover();
            if((index=searchTab(name,fvalobj,&tadd))==-1){
                error(31); //调用函数未定义
                skip(9,ifsy,dosy,forsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else{
                if(gTab[index].obj==fvalobj) callValueSent(index);
                else if(gTab[index].obj==fvoiobj) callVoidSent(index);
                else{
                    error(41); //不是函数
                    skip(9,ifsy,dosy,forsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return;
                }

                if(symbol!=semisy){
                    error(0); //缺分号
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                }
                else insymbol();
            }
        }
        else{
            error(14); //应为(或[或=
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
    }
    fprintf(outg,"%s","this is a sent statement\n");
}

//＜条件＞    ::=  ＜表达式＞＜关系运算符＞＜表达式＞｜＜表达式＞ //表达式为0条件为假，否则为真
void condition(){
    int sign,typel,typer;
    char op1[opsize],op2[opsize],result[opsize];
    newtemp(result);

    typel=expression(op1);
    if(typel!=intty){
        error(43); //类型需要为整型
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    if(symbol==equalsy||symbol==nequalsy||symbol==greatsy||symbol==gequalsy||symbol==lesssy||symbol==lequalsy){
        switch(symbol){
            case equalsy:sign=EQUAL; break;
            case nequalsy:sign=NEQUAL; break;
            case greatsy:sign=GREAT; break;
            case gequalsy:sign=GEQUAL; break;
            case lesssy:sign=LESS; break;
            case lequalsy:sign=LEQUAL; break;
            default: break;
        }
        fprintf(outg,"%s","this is a compare statement\n");
        insymbol();
        typer=expression(op2);
        if(typel!=typer){
            error(39); //类型不匹配
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else midcode(sign,op1,op2,result); //op1=op1(compare)op2
    }
    else midcode(ASS,result,op1,NULL);
    fprintf(outg,"%s","this is a condition statement\n");
}

//＜条件语句＞  ::=  if '('＜条件＞')'＜语句＞［else＜语句＞］
/*
(1) if(条件)
        <语句>
label1:
------------
(2)
    if(条件)
    (jal label1)
        <语句>
    (jal label2)
label1:
    else
        <语句>
label2:
*/
void sentIf(){ //确定为if
    char label1[labelsize],label2[labelsize];
    newlabel(label1);
    newlabel(label2);

    insymbol();
    if(symbol!=lparentsy){
        error(10);
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        condition();
        midcode(JAL,label1,NULL,NULL);

        if(symbol!=rparentsy){
            error(11); //缺少)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else {
            insymbol();
            sent();
            midcode(JUMP,label2,NULL,NULL);
            midcode(LABEL,label1,NULL,NULL);

            if(symbol==elsesy){
                insymbol();
                sent();
            }
            midcode(LABEL,label2,NULL,NULL);
        }
    }
    fprintf(outg,"%s","this is a sentIf statement\n");
}

//＜步长＞::= ＜无符号整数＞ 
//for'('＜标识符＞＝＜表达式＞;＜条件＞;＜标识符＞＝＜标识符＞(+|-)＜步长＞')'＜语句＞
/*
        assign
        (goto label2)
label1:
        condition
        (jal label3)
label2:
        sentence
        add/sub
        (goto label1)
label3:
*/
void sentFor(){
    char label1[labelsize],label2[labelsize],namet[idsize],op1[opsize],op2[opsize],name[idsize],strnum[numsize];
    int typel,typer,tadd,index,sign;
    struct mcode codetemp[2];
    obj_enum objt;
    newlabel(label1);
    newlabel(label2);

    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    memset(name,0,idsize);
    strcpy(name,id);//记录标识符名字
    index=searchTab(name,varobj,&tadd);
    if(index==-1){
        error(35); //标识符未定义
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    //记录obj和type
    if(tadd==1){
        objt=fTab[index].obj;
        typel=fTab[index].type;
    }
    else{
        objt=gTab[index].obj;
        typel=gTab[index].type;
    }

    //检测type和obj
    if(objt!=varobj&&objt!=paraobj){
        error(38); //只有变量或参数可以被赋值
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    if(typel!=intty){
        error(43); //类型需要为整型
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=assignsy){
        error(3); //缺=
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    typer=expression(op1);
    if(typel!=typer){
        error(39); //类型不一致
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    midcode(ASS,name,op1,NULL);
    if(symbol!=semisy){
        error(0); //缺;
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    midcode(LABEL,label1,NULL,NULL);

    insymbol();
    condition();
    if(symbol!=semisy){
        error(0); //缺;
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    midcode(JAL,label2,NULL,NULL);

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    strcpy(namet,id);
    if(strcmp(name,namet)!=0){
        error(44); //标识符不一致
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=assignsy){
        error(3); //缺=
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=idsy){
        error(2); //应为标识符
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    memset(namet,0,idsize);
    strcpy(namet,id);
    if(strcmp(namet,name)!=0){
        error(44); //标识符不一致
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    if(symbol!=plussy&&symbol!=minussy){
        error(16);  //缺+或-
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    if(symbol==plussy) sign=ADD;
    else sign=SUB;

    insymbol();
    if(symbol!=numsy){
        error(4); //缺少整数
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    //记录加法或减法midcode
    codetemp[0].sign=sign;
    strcpy(codetemp[0].op1,name);
    memset(strnum,0,numsize);
    sprintf(strnum,"%d",num);
    strcpy(codetemp[0].op2,strnum);
    newtemp(op2);
    strcpy(codetemp[0].op3,op2);
    fprintf(outg,"%s","this is a step statement\n");
    //记录赋值语句中间代码
    codetemp[1].sign=ASS;
    strcpy(codetemp[1].op1,name);
    strcpy(codetemp[1].op2,op2);

    insymbol();
    if(symbol!=rparentsy){
        error(11); //缺)
        skip(10,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }

    insymbol();
    sent();
    midcode(codetemp[0].sign,codetemp[0].op1,codetemp[0].op2,codetemp[0].op3);
    midcode(codetemp[1].sign,codetemp[1].op1,codetemp[1].op2,NULL);
    midcode(JUMP,label1,NULL,NULL);
    midcode(LABEL,label2,NULL,NULL);
    fprintf(outg,"%s","this is a sentFor statement\n");
}

//do＜语句＞while '('＜条件＞')'
/*
        do
label1:
        <语句>
        condition
        (jal label1)
*/
void sentDoWhile(){
    char label0[labelsize],label1[labelsize];

    insymbol();
    newlabel(label0);
    newlabel(label1);

    midcode(LABEL,label1,NULL,NULL);
    sent();

    if(symbol!=whilesy){
        error(15); //缺while关键字
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        if(symbol!=lparentsy){
            error(10); //缺(
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            insymbol();
            condition();
            if(symbol!=rparentsy){
                error(15); //缺while关键字
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else{
                insymbol();
                midcode(JAL,label0,NULL,NULL);
                midcode(JUMP,label1,NULL,NULL);
                midcode(LABEL,label0,NULL,NULL);
            }
        }
    }
    fprintf(outg,"%s","this is a sentDoWhile statement\n");
}


//＜写语句＞    ::=  printf'('＜字符串＞,＜表达式＞')'|printf '('＜字符串＞')'|printf '('＜表达式＞')'
void sentPrintf(){
    int type,sign=0; //sign=0,只有表达式;sign=1,只有字符串;sign=2,有字符串和表达式
    char op1[opsize],stringt[stringsize];

    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else {
        insymbol();
        if(symbol==stringsy){
            sign=1;
            strcpy(stringt,string); //记录字符串值
            fprintf(outg,"%s","this is a string statement\n");
            insymbol();
            if(symbol==commasy){
                sign=2;
                insymbol();
                type=expression(op1);
            }

        }
        else{
            type=expression(op1);
        }

        //检测)
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else insymbol();

        //输出midcode
        if(sign==1) midcode(PRINTS,stringt,NULL,NULL);
        else if(sign==0){
            if(type==charty) midcode(PRINTC,op1,NULL,NULL);
            else midcode(PRINTI,op1,NULL,NULL);
        }
        else{
            midcode(PRINTS,stringt,NULL,NULL);
            if(type==charty) midcode(PRINTC,op1,NULL,NULL);
            else midcode(PRINTI,op1,NULL,NULL);
        }
    }
    fprintf(outg,"%s","this is a sentPrintf statement\n");
}

//＜读语句＞    ::=  scanf '('＜标识符＞{,＜标识符＞}')'
void sentScanf(){
    int tadd,index,type,objt;
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return;
    }
    else{
        insymbol();
        if(symbol!=idsy){
            error(2); //应为标识符
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return;
        }
        else{
            while(symbol==idsy){
                index=searchTab(id,varobj,&tadd);
                if(index==-1){
                    error(35); //标识符未定义
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return;
                }
                else{
                    if(tadd==1){
                        type=fTab[index].type;
                        objt=fTab[index].obj;
                    }
                    else{
                        type=gTab[index].type;
                        objt=gTab[index].obj;
                    }
                    if(objt!=varobj&&objt!=paraobj){
                        error(36); //不是变量或参数
                        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                        return;
                    }
                    else{
                        if(type==charty) midcode(SCANC,id,NULL,NULL);
                        else midcode(SCANI,id,NULL,NULL);

                        insymbol();
                        if(symbol==commasy) insymbol();
                    }
                }
            }


            if(symbol!=rparentsy){
                error(11); //缺)
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else insymbol();
        }
    }
    fprintf(outg,"%s","this is a sentScanf statement\n");
}
//＜返回语句＞   ::=  return['('＜表达式＞')']
void sentReturn(){
    int typel,typer;
    char op1[opsize];
    obj_enum objt;
    typel=gTab[gt-1].type;
    objt=gTab[gt-1].obj;

    insymbol();
    if(symbol==lparentsy){
        insymbol();
        typer=expression(op1);

        if(objt==fvalobj){
            retsign=1;
        }
        if(typel!=typer){
            error(39); //类型不一致
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return;
        }
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return;
        }

        midcode(RET,op1,NULL,NULL);
        insymbol();
    }

    else{
        if(objt==fvoiobj){
            retsign=1;
            midcode(RET,"\0",NULL,NULL);
        }
    }
    fprintf(outg,"%s","this is a sentReturn statement\n");
}

//＜值参数表＞   ::= ＜表达式＞{,＜表达式＞}｜＜空＞
void valueParalist(int index){
    int i=0,j,type1,type2,parao;
    char op1[opsize];
    j=gTab[index].addr;
    parao=gTab[index].len;

    if(symbol==rparentsy){
        fprintf(outg,"%s","this is a valueParalist statement\n");
        return;
    }

    type1=expression(op1);
    type2=fTab[j++].type;
    i++;
    if(type1!=type2) error(39); //类型不匹配
    midcode(VPARA,op1,NULL,NULL);

    while(symbol==commasy){
        insymbol();
        type1=expression(op1);
        type2=fTab[j++].type;
        i++;
        if(type1!=type2) error(39); //类型不匹配
        midcode(VPARA,op1,NULL,NULL);
    }

    if(i!=parao) error(42); //实参形参个数不一致
    fprintf(outg,"%s","this is a valueParalist statement\n");
}

//＜有返回值函数调用语句＞ ::= ＜标识符＞'('＜值参数表＞')'
void callValueSent(int index){ //已经确定是标识符开头
    char name[idsize];

    memset(name,0,idsize);
    strcpy(name,id);
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        valueParalist(index);
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            midcode(CALL,name,NULL,NULL);
            insymbol();
        }
    }
    fprintf(outg,"%s","this is a callValueSent statement\n");
}
//＜无返回值函数调用语句＞ ::= ＜标识符＞'('＜值参数表＞')'
void callVoidSent(int index){
    char name[idsize];

    memset(name,0,idsize);
    strcpy(name,id);
    insymbol();
    if(symbol!=lparentsy){
        error(10); //缺(
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
    }
    else{
        insymbol();
        valueParalist(index);
        if(symbol!=rparentsy){
            error(11); //缺)
            skip(9,idsy,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
             midcode(CALL,name,NULL,NULL);
            insymbol();
        }
    }
    fprintf(outg,"%s","this is a callVoidSent statement\n");
}

//＜赋值语句＞   ::=  ＜标识符＞＝＜表达式＞|＜标识符＞'['＜表达式＞']'=＜表达式＞
void sentAssign(){
    int index=0,tadd,typel,typer;
    obj_enum objt;
    char op1[opsize],op2[opsize],name[idsize];
    memset(name,0,idsize);
    strcpy(name,id);

    insymbol();
    if(symbol==assignsy){
        index=searchTab(name,varobj,&tadd);
        if(index==-1){
            error(35); //标识符未定义
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            if(tadd==1){
                obj=fTab[index].obj;
                typel=fTab[index].type;
            }
            else{
                obj=gTab[index].obj;
                typel=gTab[index].type;
            }

            if(obj!=varobj&&obj!=paraobj){
                error(38); //只能给常量或参数赋值
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else{
                insymbol();
                typer=expression(op1);
                if(typel!=typer){
                    error(39); //类型不匹配
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                }
                else midcode(ASS,name,op1,NULL);
            }
        }
    }
    else if(symbol==lbracketsy){
        index=searchTab(name,arrayobj,&tadd);
        if(index==-1){
            error(32); //数组未定义
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return;
        }
        //记录obj和type
        if(tadd==1){
            objt=fTab[index].obj;
            typel=fTab[index].type;
        }
        else{
            objt=gTab[index].obj;
            typel=gTab[index].type;
        }

        if(objt!=arrayobj){
            error(33); //不是数组
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return;
        }

        insymbol();
        typer=expression(op1);
        if(typer==charty){
            error(40); //数组下标必须为非负整数;注意！！！：此时无法判断是否为大于0的数，需要运行才知道
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        }
        else{
            if(symbol!=rbracketsy){
                error(8); //缺]
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            }
            else{
                insymbol();
                if(symbol!=assignsy){
                    error(3); //缺=
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                }
                else{
                    insymbol();
                    typer=expression(op2);
                    if(typel!=typer){
                        error(39); //类型不匹配
                        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    }
                    else midcode(ARRW,name,op1,op2);
                }
            }
        }
    }
    fprintf(outg,"%s","this is a sentAssign statement\n");
}

//＜表达式＞    ::= ［＋｜－］＜项＞{＜加法运算符＞＜项＞}   //[+|-]只作用于第一个<项>
int expression(char* op1){
    int type=0,positive;
    char top[opsize],strnum[numsize],eop1[opsize],eop2[opsize],eop3[opsize];

    if(symbol==plussy||symbol==minussy) {
        if(symbol==plussy) positive=1;
        else positive=0;
        insymbol();
        term(top);

        memset(strnum,0,numsize);
        sprintf(strnum,"%d",0);
        newtemp(eop3);
        if(positive==1) midcode(ADD,strnum,top,eop3); //op1=0+top
        else midcode(SUB,strnum,top,eop3); //op1=0-top;

        while(symbol==minussy||symbol==plussy){
            if(symbol==plussy) positive=1;
            else positive=0;
            fprintf(outg,"%s","this is a plus statement\n");

            memset(eop1,0,opsize);
            strcpy(eop1,eop3);

            insymbol();
            term(top);
            memset(eop2,0,opsize);
            strcpy(eop2,top);
            newtemp(eop3);

            if(positive==1) midcode(ADD,eop1,eop2,eop3); //op1=op1+top
            else midcode(SUB,eop1,eop2,eop3); //op1=op1-top;
        }
        type=0;
    }
    else{
        type=term(top);
        memset(eop3,0,opsize);
        strcpy(eop3,top);

        while(symbol==minussy||symbol==plussy){
            if(symbol==plussy) positive=1;
            else positive=0;
            fprintf(outg,"%s","this is a plus statement\n");

            memset(eop1,0,opsize);
            strcpy(eop1,eop3);

            insymbol();
            term(top);
            memset(eop2,0,opsize);
            strcpy(eop2,top);
            newtemp(eop3);

            if(positive==1) midcode(ADD,eop1,eop2,eop3); //op1=op1+top
            else midcode(SUB,eop1,eop2,eop3); //op1=op1-top;
            type=intty;
        }
    }

    memset(op1,0,opsize);
    strcpy(op1,eop3);
    fprintf(outg,"%s","this is a expression statement\n");
    return type;
}

//＜项＞     ::= ＜因子＞{＜乘法运算符＞＜因子＞}
int term(char* op1){
    int type=intty,sign;
    char fop[opsize],top1[opsize],top2[opsize],top3[opsize];

    type=factor(fop);
    memset(top3,0,opsize);
    strcpy(top3,fop);

    while(symbol==starsy||symbol==divisy){
        memset(top1,0,opsize);
        strcpy(top1,top3);
        fprintf(outg,"this is a mult statement\n");

        if(symbol==starsy) sign=0;
        else sign=1;
        insymbol();

        factor(fop);
        memset(top2,0,opsize);
        strcpy(top2,fop);
        newtemp(top3);

        if(sign==0) midcode(MUL,top1,top2,top3);
        else midcode(DIVI,top1,top2,top3);  //op1=op1*fop;op1=op1/fop;
        type=intty;
    }
    fprintf(outg,"%s","this is a term statement\n");
    memset(op1,0,opsize);
    strcpy(op1,top3);
    return type;
}
//＜因子＞    ::= ＜标识符＞｜＜标识符＞'['＜表达式＞']'｜＜整数＞|＜字符＞｜＜有返回值函数调用语句＞|'('＜表达式＞')'
//result为中间变量名,返回值为结果类型;1为int型,0为char型
int factor(char* op1){
    int type=intty,positive,index,tadd,typer;
    char op2[opsize],name[idsize],strnum[numsize];
    obj_enum objt;

    if(symbol==idsy){
        memset(name,0,idsize);
        strcpy(name,id); //记录标识符名字
        saveNow();
        insymbol();
        //数组
        if(symbol==lbracketsy){
            //查找数组
            index=searchTab(name,varobj,&tadd);
            if(index==-1){
                error(32); //数组未定义
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                return type;
            }
            else{
                //检查是否为数组类型,不是报错,是则记录type
                if(tadd==1){
                    objt=fTab[index].obj;
                    type=fTab[index].type;
                }
                else{
                   objt=gTab[index].obj;
                   type=gTab[index].type;
                }

                if(objt!=arrayobj){
                    error(33); //不是数组
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return type;
                }

                insymbol();
                typer=expression(op2);
                if(typer!=intty){
                    error(40); //数组小标必须为非负整数
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return type;
                }
                if(symbol!=rbracketsy){
                    error(8); //应为]
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return type;
                }
                else{
                    newtemp(op1);
                    midcode(ARR,name,op2,op1);
                    insymbol();
                }
            }
        }
        else if(symbol==lparentsy){
            recover();
            index=searchTab(name,fvalobj,&tadd);
            if(index==-1){
                error(31);
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                return type;
            }
            else{
                if(gTab[index].obj!=fvalobj){
                    error(34);
                    skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                    return type;
                }
                else{
                    newtemp(op1);
                    type=gTab[index].type;
                    callValueSent(index);
                    midcode(ASSF,op1,NULL,NULL);
                }
            }
        }
        else{
            index=searchTab(name,varobj,&tadd);
            if(index==-1){
                error(35); //标识符未定义
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                return type;
            }

            //记录obj和type
            if(tadd==1){
                objt=fTab[index].obj;
                type=fTab[index].type;
                len=fTab[index].len;
            }
            else{
                objt=gTab[index].obj;
                type=gTab[index].type;
                len=gTab[index].len;
            }

            if(objt!=varobj&&objt!=constobj&&objt!=paraobj){
                error(36);  //不是
                skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
                return type;
            }

            //标识符是常量
            if(objt==constobj){
                memset(strnum,0,numsize);
                sprintf(strnum,"%d",len);
                memset(op1,0,opsize);
                strcpy(op1,strnum);
            }
            else{
                memset(op1,0,opsize);
                strcpy(op1,name);
            }
        }
    }
    //数字
    else if(symbol==numsy){  //op1=num;
        memset(strnum,0,numsize);
        sprintf(strnum,"%d",num);
        memset(op1,0,opsize);
        strcpy(op1,strnum);
        fprintf(outg,"%s","this is a wholenum statement\n");
        insymbol();
    }
    else if(symbol==minussy||symbol==plussy){ //op1=num;
        if(symbol==minussy) positive=0;
        else positive=1;

        insymbol();
        if(symbol!=numsy){
            error(4); //缺少整数
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return type;
        }
        else{
            if(positive==0) num=-num;
            memset(strnum,0,idsize);
            sprintf(strnum,"%d",num);
            memset(op1,0,opsize);
            strcpy(op1,strnum);
            fprintf(outg,"%s","this is a wholenum statement\n");
            insymbol();
        }
    }
    //字符
    else if(symbol==charconsy){ //op1=num;
        memset(strnum,0,numsize);
        sprintf(strnum,"%d",num);
        memset(op1,0,opsize);
        strcpy(op1,strnum);
        type=charty;
        insymbol();
    }
    //(表达式)
    else if(symbol==lparentsy){
        insymbol();
        expression(op2);
        type=intty;
        if(symbol!=rparentsy){
            error(11); //应为)
            skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
            return type;
        }
        else{
            memset(op1,0,opsize);
            strcpy(op1,op2);
            insymbol();
        }
    }
    else{
        error(17); //错误因子成分
        skip(10,ifsy,dosy,forsy,idsy,returnsy,scanfsy,printfsy,lbracesy,rbracesy,semisy);
        return type;
    }
    fprintf(outg,"%s","this is a factor\n");
    return type;
}


void mainFunc(){
    int type,sumsize=0,i;
    char name[idsize];

    addr=0;
    mexist=1;
    type=noty;

    memset(name,0,idsize);
    strcpy(name,"main");

    //******登表******
    insertTab(name,fvoiobj,type,0,0,ft);
    //######生成四元式######
    midcode(FUNDEFV,name,NULL,NULL);
    lev=1;

    insymbol();
    if(symbol!=lparentsy){
		error(10);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	if(symbol!=rparentsy){
		error(11);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	if(symbol!=lbracesy){
		error(12);
		skip(13,intsy,charsy,constsy,idsy,ifsy,forsy,dosy,scanfsy,returnsy,printfsy,semisy,lbracesy,rbracesy);
	}
	else{
		insymbol();
	}

	sentComp();

    if(retsign==0) midcode(RET,NULL,NULL,NULL);
    retsign=0;
    midcode(FUNEND,gTab[gt-1].name,NULL,NULL);

    for(i=gTab[gt-1].addr;i<ft;i++) sumsize=sumsize+fTab[i].size; //计算函数变量和参数占空间总大小
    gTab[gt-1].size=sumsize;
    lev=0; //函数声明结束恢复lev和addr值
    addr=0;

    findex[funcnum].gt=gt-1;
    findex[funcnum].vstart=gTab[gt-1].addr;
    findex[funcnum].vend=ft;
    funcnum++;

    if(symbol!=rbracesy) {
        fprintf(outg,"%s","this is a mainFunc statement\n");
        error(13);
        skip(0);
    }
	else{
        fprintf(outg,"%s","this is a mainFunc statement\n");
        insymbol();
        //error(20);
        skip(0);
	}
}


//＜程序＞::= ［＜常量说明＞］［＜变量说明＞］{＜有返回值函数定义＞|＜无返回值函数定义＞}＜主函数＞
void program(){
    addr=0;
    //检测合法起始符号
    if(symbol!=constsy&&symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
        error(18);
        skip(4,constsy,intsy,charsy,voidsy);
    }

    if(symbol==constsy){
        constSta();
        //检测合法后继
        if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
            error(18);
            skip(3,intsy,charsy,voidsy);
        }

        if(symbol==intsy||symbol==charsy) goto intchar;
        else goto fundef; //void
    }

    if(symbol==intsy||symbol==charsy){

intchar:
        saveNow();
        insymbol();
        insymbol();
        if(symbol==lparentsy){
            recover();
            goto fundef;
        }
        else{
            recover();
            varSta();
            //检测合法后继
            if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                error(18);
                skip(3,intsy,charsy,voidsy);
            }
        }
    }

fundef:

    gn=gt;
    while(symbol==intsy||symbol==charsy||symbol==voidsy){ //进入有返回值函数前恢复现场;void函数恢复现场
            if(symbol==intsy||symbol==charsy){
                funcDefValue(); //有返回值函数定义
                //检测合法后继
                if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                    error(18);
                    skip(3,intsy,charsy,voidsy);
                }
            }
            else{
                saveNow();
                insymbol();
                if(symbol==mainsy){
                    mainFunc();
                    break; //main函数处理
                }
                else{
                    recover();
                    funcDefVoid(); //无返回值函数定义
                    //检测合法后继
                    if(symbol!=intsy&&symbol!=charsy&&symbol!=voidsy){
                        error(18);
                        skip(3,intsy,charsy,voidsy);
                    }
                }
            }
        }
        fprintf(outg,"%s\n","this is a programm statement");
}

#endif
