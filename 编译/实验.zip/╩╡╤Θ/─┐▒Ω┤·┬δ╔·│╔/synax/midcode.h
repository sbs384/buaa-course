#ifndef _MIDCODE_H_
#define _MIDCODE_H_
#include <stdio.h>
#include "global.h"

#define codesize 2048
#define opsize 32
#define labelsize 32
#define tempsize 32

#define CONI        0
#define CONC        1
#define VARI        2
#define VARC        3
#define ADD         4
#define SUB         5
#define MUL         6
#define DIVI        7
#define EQUAL       8
#define NEQUAL      9
#define LESS	    10
#define LEQUAL	    11
#define GREAT   	12
#define GEQUAL 	    13
#define ARR     	14
#define ARRW    	15
#define ASS     	16
#define SCANI    	17
#define SCANC   	18
#define PRINTS  	19
#define PRINTI  	20
#define PRINTC  	21
#define RET     	22
#define FUNDEFI  	23
#define FUNDEFC 	24
#define FUNDEFV 	25
#define FUNEND  	26
#define ASSF    	27
#define CALL     	28
#define JUMP     	29
#define JAL      	30
#define LABEL    	31
#define PARAI   	32
#define PARAC   	33
#define VPARA   	34


FILE* poutco,*poutcos; //����м�����ļ�ָ��
int tempcount=0,labelcount=0,ct=0; //temp��label������;ctΪcTabָ��
struct mcode{ //�м����ṹ��
    int sign;
    char op1[stringsize];
    char op2[opsize];
    char op3[opsize];
};
struct mcode cTab[codesize];

void newtemp(char* temp);
void newlabel(char* label);
void midcode();
void printfcode();


void newtemp(char* temp){
    memset(temp,0,strlen(temp));
    sprintf(temp,"$temp%d",tempcount);
    tempcount++;
}

void newlabel(char* label){
    memset(label,0,strlen(label));
    sprintf(label,"label%d",labelcount);
    labelcount++;
}

void midcode(int sign,char* op1,char* op2,char* op3){
    if(ct==codesize){
        error(45); //code����
        exit(1);
    }
    cTab[ct].sign=sign;
    if(op1!=NULL) strcpy(cTab[ct].op1,op1);
    if(op2!=NULL) strcpy(cTab[ct].op2,op2);
    if(op3!=NULL) strcpy(cTab[ct].op3,op3);
    ct++;
}

void printfcode(){
    int i;
    if((poutco=fopen("code.txt","w"))==NULL){
        printf("the file can't be opened!\n");
        return;
    }
    if((poutcos=fopen("coderead.txt","w"))==NULL){
        printf("the file can't be opened!\n");
        return;
    }

       for(i=0;i<ct;i++){
            switch(cTab[i].sign){
                 case CONI:
                     fprintf(poutco,"coni %s,%s\n",cTab[i].op1,cTab[i].op2);
                     fprintf(poutcos,"coni %s=%s\n",cTab[i].op1,cTab[i].op2);
                     break;
                 case CONC:
                     fprintf(poutco,"conc %s,%s\n",cTab[i].op1,cTab[i].op2);
                     fprintf(poutcos,"conc %s=%s\n",cTab[i].op1,cTab[i].op2);
                     break;
                 case VARI:
                      if(strcmp(cTab[i].op2,"\0")==0){
                        fprintf(poutco,"vari %s\n",cTab[i].op1);
                        fprintf(poutcos,"vari %s\n",cTab[i].op1);
                      }
                      else{
                        fprintf(poutco,"vari %s,%s\n",cTab[i].op1,cTab[i].op2);
                        fprintf(poutcos,"vari %s,%s\n",cTab[i].op1,cTab[i].op2);
                      }
                      break;
                 case VARC:
                      if(strcmp(cTab[i].op2,"\0")==0){
                        fprintf(poutco,"varc %s\n",cTab[i].op1);
                        fprintf(poutcos,"varc %s\n",cTab[i].op1);
                      }
                      else{
                        fprintf(poutco,"varc %s,%s\n",cTab[i].op1,cTab[i].op2);
                        fprintf(poutcos,"varc %s,%s\n",cTab[i].op1,cTab[i].op2);
                      }
                      break;
                 case ADD:
                      fprintf(poutco,"add %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=%s+%s\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case SUB:
                      fprintf(poutco,"sub %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=%s-%s\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case MUL:
                      fprintf(poutco,"mul %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=%s*%s\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case DIVI:
                      fprintf(poutco,"divi %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=%s/%s\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case EQUAL:
                      fprintf(poutco,"equal %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s==%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case NEQUAL:
                      fprintf(poutco,"nequal %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s!=%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case LESS:
                      fprintf(poutco,"less %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s<%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case LEQUAL:
                      fprintf(poutco,"lequal %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s<=%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case GREAT:
                      fprintf(poutco,"great %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s>%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case GEQUAL:
                      fprintf(poutco,"gequal %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=(%s>=%s)\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case ARR:
                      fprintf(poutco,"arr %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s=%s[%s]\n",cTab[i].op3,cTab[i].op1,cTab[i].op2);
                      break;
                 case ARRW:
                      fprintf(poutco,"arrw %s,%s,%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      fprintf(poutcos,"%s[%s]=%s\n",cTab[i].op1,cTab[i].op2,cTab[i].op3);
                      break;
                 case ASS:
                      fprintf(poutco,"ass %s,%s\n",cTab[i].op1,cTab[i].op2);
                      fprintf(poutcos,"%s=%s\n",cTab[i].op1,cTab[i].op2);
                      break;
                 case SCANI:
                      fprintf(poutco,"scani %s\n",cTab[i].op1);
                      fprintf(poutcos,"scani(%s)\n",cTab[i].op1);
                      break;
                 case SCANC:
                      fprintf(poutco,"scanc %s\n",cTab[i].op1);
                      fprintf(poutcos,"scanc(%s)\n",cTab[i].op1);
                      break;
                 case PRINTS:
                      fprintf(poutco,"prints %s\n",cTab[i].op1);
                      fprintf(poutcos,"prints(%s)\n",cTab[i].op1);
                      break;
                 case PRINTI:
                      fprintf(poutco,"printi %s\n",cTab[i].op1);
                      fprintf(poutcos,"printi(%s)\n",cTab[i].op1);
                      break;
                 case PRINTC:
                      fprintf(poutco,"printc %s\n",cTab[i].op1);
                      fprintf(poutcos,"printc(%s)\n",cTab[i].op1);
                      break;
                 case RET:
                      if(strcmp(cTab[i].op1,"\0")==0){
                            fprintf(poutco,"ret");
                            fprintf(poutcos,"ret");
                      }
                      else{
                            fprintf(poutco,"ret %s\n",cTab[i].op1);
                            fprintf(poutcos,"ret %s\n",cTab[i].op1);
                      }
                      break;
                 case FUNDEFI:
                      fprintf(poutco,"fundefi %s\n",cTab[i].op1);
                      fprintf(poutcos,"fundefi %s\n",cTab[i].op1);
                      break;
                 case FUNDEFC:
                      fprintf(poutco,"fundefc %s\n",cTab[i].op1);
                      fprintf(poutcos,"fundefc %s\n",cTab[i].op1);
                      break;
                 case FUNDEFV:
                      fprintf(poutco,"fundefv %s\n",cTab[i].op1);
                      fprintf(poutcos,"fundefv %s\n",cTab[i].op1);
                      break;
                 case FUNEND:
                      fprintf(poutco,"funend %s\n",cTab[i].op1);
                      fprintf(poutcos,"funend %s\n",cTab[i].op1);
                      break;
                 case ASSF:
                      fprintf(poutco,"assf %s\n",cTab[i].op1);
                      fprintf(poutcos,"assf %s\n",cTab[i].op1);
                      break;
                 case CALL:
                      fprintf(poutco,"call %s\n",cTab[i].op1);
                      fprintf(poutcos,"call %s\n",cTab[i].op1);
                      break;
                 case JUMP:
                      fprintf(poutco,"jump %s\n",cTab[i].op1);
                      fprintf(poutcos,"jump %s\n",cTab[i].op1);
                      break;
                 case JAL:
                      fprintf(poutco,"jal %s\n",cTab[i].op1);
                      fprintf(poutcos,"jal %s\n",cTab[i].op1);
                      break;
                 case LABEL:
                      fprintf(poutco,"label %s\n",cTab[i].op1);
                      fprintf(poutcos,"%s:\n",cTab[i].op1);
                      break;
                 case PARAI:
                      fprintf(poutco,"parai %s\n",cTab[i].op1);
                      fprintf(poutcos,"parai %s\n",cTab[i].op1);
                      break;
                 case PARAC:
                      fprintf(poutco,"parac %s\n",cTab[i].op1);
                      fprintf(poutcos,"parac %s\n",cTab[i].op1);
                      break;
                 case VPARA:
                      fprintf(poutco,"vpara %s\n",cTab[i].op1);
                      fprintf(poutcos,"vpara %s\n",cTab[i].op1);
                      break;
            }
       }

       fclose(poutco);
       fclose(poutcos);
}

#endif



