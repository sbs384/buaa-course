#ifndef _MIPS_H_
#define _MIPS_H_
#include <stdio.h>
#include "global.h"
#include "synax.h"

struct tempTab{
    char name[tempsize]; //temp����
    int addr; //temp��ַ
};

FILE *poutm;
int stringcount=0,codeindex=0,tt=0,fttemp=0,calnum=0,funsize,faddr; //tt,temp������;ftempt,��ǰ�����������
char stringtemp[32];
struct tempTab tTab[512];

void printftTab();
int isnum();
void newstring();
void globalvar();
int searchtemp(char *temp);
void inserttemp(char *name);
int searchid(char *name);
void initmips();
void fundefmips();
void funendmips();
void vparamips();
void callmips();
void retmips();
void assfmips();
void jumpmips();
void jalmips();
void labelmips();
void arrmips();
void arrwmips();
void calcumips();
void assignmips();
void scanmips();
void printmips();
void genmips();


void printftTab(){
    int i;
    FILE* poutt;
    if((poutt=fopen("tTab.txt","w"))==NULL) printf("the file can't be opened!\n");
    fprintf(poutt,"*******************tTab******************\n");
    fprintf(poutt,"name       addr        \n");
    for(i=0;i<tt;i++) fprintf(poutt,"%s       %d      \n",tTab[i].name,tTab[i].addr);
}

int isnum(char *name){ //�����ַ���1,���Ƿ���0
    if((name[0]>='0'&&name[0]<='9')||name[0]=='-') return 1;
    else return 0;
}

void newstring(){
    if(stringcount==stringnum){
        error(47); //string����
        exit(1);
    }
    memset(stringtemp,0,strlen(stringtemp));
    sprintf(stringtemp,"$string%d",stringcount);
    stringcount++;
}

int searchtemp(char *temp){ //1,�ҵ���;0,û���ҵ�
    int i;
    for(i=findex[fttemp].tstart;i<tt;i++){
        if(strcmp(temp,tTab[i].name)==0) return 1;
    }
    return 0;
}

void inserttemp(char *temp){
    strcpy(tTab[tt].name,temp);
    faddr+=4;
    tTab[tt].addr=faddr;
    funsize+=4;
    tt++;
}

int searchid(char *name){ //û�ҵ�,����ֵΪ-1;���򷵻�ֵΪ������ַ
    int i;
    //�Ҿֲ�����
    for(i=findex[fttemp].vstart;i<findex[fttemp].vend;i++){
        if(strcmp(fTab[i].name,name)==0) return fTab[i].addr;
    }
    //����ʱ����
    for(i=findex[fttemp].tstart;i<findex[fttemp].tend;i++){
        if(strcmp(tTab[i].name,name)==0) return tTab[i].addr;
    }
    return -1;
}

void globalvar(){
    int i=0,len;
    while(cTab[i].sign==CONI||cTab[i].sign==CONC) i++;
    while(cTab[i].sign==VARI||cTab[i].sign==VARC){
        if(strcmp(cTab[i].op2,"\0")!=0){
            len=atoi(cTab[i].op2);
            len=len*4;
            memset(cTab[i].op2,0,opsize);
            sprintf(cTab[i].op2,"%d",len);
            fprintf(poutm,"\t%s: .word %s\n",cTab[i].op1,cTab[i].op2);
        }
        else fprintf(poutm,"\t%s: .word 4\n",cTab[i].op1);
        i++;
    }
    codeindex=i;
}

/*
    1.temp
    2.string
    4.main(j,$sp)
*/
void initmips(){
    int i,mainsize,stemp;
    fprintf(poutm,".data\n");

    //����ȫ�ֱ���
    globalvar();

    //������Ԫʽ����string��temp����,temp�������ڵ�tTab���������µ�funsize�ǻ�gTab��
    for(i=codeindex;i<ct;i++){
        //�����ַ���
        if(cTab[i].sign==PRINTS){
            newstring();
            fprintf(poutm,"\t%s:.asciiz \"%s\"\n",stringtemp,cTab[i].op1);
            memset(cTab[i].op1,0,stringsize);
            strcpy(cTab[i].op1,stringtemp);
        }
        else if(cTab[i].sign==FUNDEFC||cTab[i].sign==FUNDEFI||cTab[i].sign==FUNDEFV){
            findex[fttemp].tstart=tt;
            funsize=gTab[findex[fttemp].gt].size;
            if(funsize==0) faddr=4;
            else faddr=fTab[findex[fttemp].vend-1].addr;
        }
        else if(cTab[i].sign==FUNEND){
            gTab[findex[fttemp].gt].size=funsize;
            findex[fttemp].tend=tt;
            fttemp++;
        }
        else if(cTab[i].sign==ADD||cTab[i].sign==SUB||cTab[i].sign==MUL||cTab[i].sign==DIVI||cTab[i].sign==ARR){
            if(cTab[i].op3[0]=='$'){
                stemp=searchtemp(cTab[i].op3);
                if(stemp==0) inserttemp(cTab[i].op3);
            }
        }
        else if(cTab[i].sign==ASSF){
            if(cTab[i].op1[0]=='$'){
                stemp=searchtemp(cTab[i].op1);
                if(stemp==0) inserttemp(cTab[i].op1);
            }
        }
        else if(cTab[i].sign==ASS){
            if(cTab[i].op1[0]=='$'){
                stemp=searchtemp(cTab[i].op1);
                if(stemp==0) inserttemp(cTab[i].op1);
            }
            if(cTab[i].op2[0]=='$'){
                stemp=searchtemp(cTab[i].op2);
                if(stemp==0) inserttemp(cTab[i].op2);
            }
        }
    }


    mainsize=gTab[findex[funcnum-1].gt].size;
    fprintf(poutm,".text\n");
    fprintf(poutm,"\taddi $fp,$sp,0\n"); //����mainջ��
    fprintf(poutm,"\tsubi $sp,$sp,%d\n",mainsize); //����$sp,����ռ�
    fprintf(poutm,"\tj main\n"); //��תmain

    fttemp=0;
}

/*
    fundefi a,NULL,NULL
*/
void fundefmips(){
    int gt,funsize;
    gt=findex[fttemp].gt;
    funsize=gTab[gt].size+8;
    calnum=0;

    fprintf(poutm,"%s:\n",cTab[codeindex].op1); //���ú�����ǩ
    if(strcmp(cTab[codeindex].op1,"main")!=0){
        fprintf(poutm,"\tsw $ra,-4($fp)\n"); //���淵�ص�ַ
        fprintf(poutm,"\tsubi $sp,$sp,%d\n",funsize); //����ջ�ռ�
    }
}

/*
    funend a,NULL,NULL
*/
void funendmips(){
    fttemp++;
    calnum=0;
}

/*
    vpara a,NULL,NULL;
*/
void vparamips(){
    int index;
    if(calnum==parasize){
        error(49); //��������
        exit(1);
    }
    if(isnum(cTab[codeindex].op1)==1) fprintf(poutm,"\tli $t8,%s\n",cTab[codeindex].op1); //������
    else{
        index=searchid(cTab[codeindex].op1); //�Ҳ����ĵ�ַ
        if(index==-1){ //global
            fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
            fprintf(poutm,"\tlw $t8,($t0)\n");
        }
        else fprintf(poutm,"\tlw $t8,%d($fp)\n",-1*index);
    }
    fprintf(poutm,"\tsw $t8,%d($sp)\n",-1*(calnum*4+8));
    calnum++;
}

/*
    call a,NULL,NULL;
*/
void callmips(){
    fprintf(poutm,"\tsw $fp,($sp)\n"); //������һ��������ջ��
    fprintf(poutm,"\taddi $fp,$sp,0\n"); //����$fpֵ
    fprintf(poutm,"\tjal %s\n",cTab[codeindex].op1); //��ת��Ŀ�꺯��
}

/*
    ret a,NULL,NULL
*/
void retmips(){
    int index;
    if(strcmp(cTab[codeindex].op1,"\0")!=0){ //���淵��ֵ��$v0
        if(isnum(cTab[codeindex].op1)==1) fprintf(poutm,"\tli $v0,%s\n",cTab[codeindex].op1);
        else{
            index=searchid(cTab[codeindex].op1);
            if(index==-1){ //global
                fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
                fprintf(poutm,"\tlw $v0,($t0)\n");
            }
            else fprintf(poutm,"\tlw $v0,%d($fp)\n",-1*index);
        }
    }

    if(fttemp!=funcnum-1){ //����main����
        fprintf(poutm,"\tlw $ra,-4($fp)\n"); //ȡ���ص�ַ��$ra
        fprintf(poutm,"\tmove $sp,$fp\n"); //����$spΪ$fp
        fprintf(poutm,"\tlw $fp,($fp)\n"); //����$fpֵ
        fprintf(poutm,"\tjr $ra\n"); //��ת�����ص�ַ��
    }
    else{ //��main����
        fprintf(poutm,"\tli $v0,10\n");
        fprintf(poutm,"\tsyscall\n");
    }
}

/*
    ass a,b==>a=b
*/
void assmips(){
    int index;
    //b
    if(isnum(cTab[codeindex].op2)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex].op2);
    else{
        index=searchid(cTab[codeindex].op2);
        if(index==-1){ //global
            fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op2);
            fprintf(poutm,"\tlw $t1,($t0)\n");
        }
        else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
    }

    //a
    index=searchid(cTab[codeindex].op1);
    if(index==-1){ //global
        fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
        fprintf(poutm,"\tsw $t1,($t0)\n");
    }
    else fprintf(poutm,"\tsw $t1,%d($fp)\n",-1*index);
}

/*
    assf,a,NULL,NULL
*/
void assfmips(){
    int index;

    index=searchid(cTab[codeindex].op1);
    if(index==-1){ //global
        fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
        fprintf(poutm,"\tsw $v0,($t0)\n");
    }
    else fprintf(poutm,"\tsw $v0,%d($fp)\n",-1*index);
}

/*
    jump a,NULL,NULL
*/
void jumpmips(){
    fprintf(poutm,"\tj %s\n",cTab[codeindex].op1);
}

/*
    jal a,NULL,NULL
*/
void jalmips(){
    int index;
    //����,����,op3
    //��������ֵ,��ֵ,op1
    //�Ƚ�

    //$t0��Ž��
    //����,����
    if(cTab[codeindex-1].sign==ADD||cTab[codeindex-1].sign==SUB||cTab[codeindex-1].sign==MUL||cTab[codeindex-1].sign==DIVI||cTab[codeindex-1].sign==ARR){
        index=searchid(cTab[codeindex-1].op3);
        if(index==-1){
            fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex-1].op3);
            fprintf(poutm,"\tlw $t0,($t0)\n");
        }
        else fprintf(poutm,"\tlw $t0,%d($fp)\n",-1*index);
    }
    //��������ֵ,��ֵ
    else if(cTab[codeindex-1].sign==ASSF||cTab[codeindex-1].sign==ASS){
        index=searchid(cTab[codeindex-1].op1);
        if(index==-1){
            fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex-1].op1);
            fprintf(poutm,"\tlw $t0,($t0)\n");
        }
        else fprintf(poutm,"\tlw $t0,%d($fp)\n",-1*index);
    }
    //$t0�ŵ�һ��������,$t1�ŵڶ���������
    //�Ƚ�
    else if(cTab[codeindex-1].sign==EQUAL||cTab[codeindex-1].sign==NEQUAL||cTab[codeindex-1].sign==GREAT||cTab[codeindex-1].sign==LESS||cTab[codeindex-1].sign==GEQUAL||cTab[codeindex-1].sign==LEQUAL){
        if(isnum(cTab[codeindex-1].op1)==1) fprintf(poutm,"\tli $t0,%s\n",cTab[codeindex-1].op1);
        else{
            index=searchid(cTab[codeindex-1].op1);
            if(index==-1){
                fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex-1].op1);
                fprintf(poutm,"\tlw $t0,($t0)\n");
            }
            else fprintf(poutm,"\tlw $t0,%d($fp)\n",-1*index);
        }

        if(isnum(cTab[codeindex-1].op2)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex-1].op2);
        else{
            index=searchid(cTab[codeindex-1].op2);
            if(index==-1){
                fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex-1].op2);
                fprintf(poutm,"\tlw $t1,($t1)\n");
            }
            else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
        }
    }
    else error(50); //�����ܳ���


    //������תָ��
    if(cTab[codeindex-1].sign==ADD||cTab[codeindex-1].sign==SUB||cTab[codeindex-1].sign==MUL||cTab[codeindex-1].sign==DIVI||cTab[codeindex-1].sign==ARR||cTab[codeindex-1].sign==ASSF||cTab[codeindex-1].sign==ASS){
        fprintf(poutm,"\tbeqz $t0,%s\n",cTab[codeindex].op1);
    }
    else if(cTab[codeindex-1].sign==EQUAL) fprintf(poutm,"\tbne $t0,$t1,%s\n",cTab[codeindex].op1);
    else if(cTab[codeindex-1].sign==NEQUAL) fprintf(poutm,"\tbeq $t0,$t1,%s\n",cTab[codeindex].op1);
    else if(cTab[codeindex-1].sign==GREAT) fprintf(poutm,"\tble $t0,$t1,%s\n",cTab[codeindex].op1);
    else if(cTab[codeindex-1].sign==LESS) fprintf(poutm,"\tbge $t0,$t1,%s\n",cTab[codeindex].op1);
    else if(cTab[codeindex-1].sign==GEQUAL) fprintf(poutm,"\tblt $t0,$t1,%s\n",cTab[codeindex].op1);
    else if(cTab[codeindex-1].sign==LEQUAL) fprintf(poutm,"\tbgt $t0,$t1,%s\n",cTab[codeindex].op1);
    else error(50); //�����ܳ���
}

/*
    label a,NULL,NULL
*/
void labelmips(){
    fprintf(poutm,"%s:\n",cTab[codeindex].op1);
}

/*
    arr a,b,c==>c=a[b]
*/
void arrmips(){
    int index;

    //$t0,a�Ļ�ַ
    index=searchid(cTab[codeindex].op1);
    if(index==-1)fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
    else{
        fprintf(poutm,"\tli $t0,%d\n",-1*index);
        fprintf(poutm,"\tadd $t0,$t0,$fp\n");
    }

    //$t1,b*-4
    if(isnum(cTab[codeindex].op2)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex].op2);
    else{
        index=searchid(cTab[codeindex].op2);
        if(index==-1){
            fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex].op2);
            fprintf(poutm,"\tlw $t1,($t1)\n");
        }
        else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
    }
    fprintf(poutm,"\tmul $t1,$t1,-4\n");

    //$t0,����Ԫ�ػ�ַ
    fprintf(poutm,"\tadd $t0,$t0,$t1\n");
    //$t0,����Ԫ��ֵ
    fprintf(poutm,"\tlw $t0,($t0)\n");

    //$t1,c�ĵ�ַ
    index=searchid(cTab[codeindex].op3);
    if(index==-1){
        fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex].op3);
        fprintf(poutm,"\tsw $t0,($t1)\n");
    }
    else fprintf(poutm,"\tsw $t0,%d($fp)\n",-1*index);
}

/*
    arrw,a,b,c==>a[b]=c
*/
void arrwmips(){
    int index;

    //$t0,a�Ļ�ַ
    index=searchid(cTab[codeindex].op1);
    if(index==-1)fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
    else{
        fprintf(poutm,"\tli $t0,%d\n",-1*index);
        fprintf(poutm,"\tadd $t0,$t0,$fp\n");
    }

    //$t1,b*-4
    if(isnum(cTab[codeindex].op2)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex].op2);
    else{
        index=searchid(cTab[codeindex].op2);
        if(index==-1){
            fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex].op2);
            fprintf(poutm,"\tlw $t1,($t1)\n");
        }
        else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
    }
    fprintf(poutm,"\tmul $t1,$t1,-4\n");

    //$t0,����Ԫ�ػ�ַ
    fprintf(poutm,"\tadd $t0,$t0,$t1\n");

    //$t1,c��ֵ
    if(isnum(cTab[codeindex].op3)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex].op3);
    else{
        index=searchid(cTab[codeindex].op3);
        if(index==-1){
            fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex].op3);
            fprintf(poutm,"\tlw $t1,($t1)\n");
        }
        else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
    }

    fprintf(poutm,"\tsw $t1,($t0)\n");
}

/*
    + - * /
    add,a,b,c==>c=a+b
*/
void calcumips(){
    int index;

    //������һ�������� $t0
    if(isnum(cTab[codeindex].op1)==1) fprintf(poutm,"\tli $t0,%s\n",cTab[codeindex].op1);
    else{
        index=searchid(cTab[codeindex].op1);
        if(index==-1){
            fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
            fprintf(poutm,"\tlw $t0,($t0)\n");
        }
        else fprintf(poutm,"\tlw $t0,%d($fp)\n",-1*index);
    }

    //�����ڶ��������� $t1
    if(isnum(cTab[codeindex].op2)==1) fprintf(poutm,"\tli $t1,%s\n",cTab[codeindex].op2);
    else{
        index=searchid(cTab[codeindex].op2);
        if(index==-1){
            fprintf(poutm,"\tla $t1,%s\n",cTab[codeindex].op2);
            fprintf(poutm,"\tlw $t1,($t1)\n");
        }
        else fprintf(poutm,"\tlw $t1,%d($fp)\n",-1*index);
    }

    //��������
    switch(cTab[codeindex].sign){
        case ADD:fprintf(poutm,"\tadd $t0,$t0,$t1\n"); break;
        case SUB:fprintf(poutm,"\tsub $t0,$t0,$t1\n"); break;
        case MUL:{
            fprintf(poutm,"\tmult $t0,$t1\n");
            fprintf(poutm,"\tmflo $t0\n");
            break;
        }
        case DIVI:{
            fprintf(poutm,"\tdiv $t0,$t1\n");
            fprintf(poutm,"\tmflo $t0\n");
            break;
        }
        default: break;
    }

     //���������������� $t0
    index=searchid(cTab[codeindex].op3);
    if(index==-1){
        fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op3);
        fprintf(poutm,"\tsw $t0,($t0)\n");
    }
    else fprintf(poutm,"\tsw $t0,%d($fp)\n",-1*index);
}


/*
    scani,a,NULL==>scan(a)
*/
void scanmips(){
    int index;

    if(cTab[codeindex].sign==SCANC) fprintf(poutm,"\tli $v0,12\n");
    else fprintf(poutm,"\tli $v0,5\n");
    fprintf(poutm,"\tsyscall\n");

    index=searchid(cTab[codeindex].op1);
    if(index==-1){
        fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
        fprintf(poutm,"\tsw $v0,($t0)\n");
    }
    else fprintf(poutm,"\tsw $v0,%d($fp)\n",-1*index);
}

/*
    prints a,NULL,NULL==>print(a)
*/
void printmips(){
    int index;

    if(cTab[codeindex].sign==PRINTS){
        fprintf(poutm,"\tli $v0,4\n");
        fprintf(poutm,"\tla $a0,%s\n",cTab[codeindex].op1);
    }
    else{
        if(cTab[codeindex].sign==PRINTI) fprintf(poutm,"\tli $v0,1\n");
        else fprintf(poutm,"\tli $v0,11\n");

        if(isnum(cTab[codeindex].op1)==1) fprintf(poutm,"\tli $a0,%s\n",cTab[codeindex].op1);
        else{
            index=searchid(cTab[codeindex].op1);
            if(index==-1){
                fprintf(poutm,"\tla $t0,%s\n",cTab[codeindex].op1);
                fprintf(poutm,"\tlw $a0,($t0)\n");
            }
            else fprintf(poutm,"\tlw $a0,%d($fp)\n",-1*index);
        }
    }
    fprintf(poutm,"\tsyscall\n");
}

void genmips(){
    initmips();

    for(;codeindex<ct;codeindex++){
        if(cTab[codeindex].sign==ADD||cTab[codeindex].sign==SUB||cTab[codeindex].sign==MUL||cTab[codeindex].sign==DIVI){
             calcumips();
        }
        else if(cTab[codeindex].sign==ARRW) arrwmips();
        else if(cTab[codeindex].sign==ARR) arrmips();
        else if(cTab[codeindex].sign==SCANC||cTab[codeindex].sign==SCANI) scanmips();
        else if(cTab[codeindex].sign==PRINTC||cTab[codeindex].sign==PRINTI||cTab[codeindex].sign==PRINTS) printmips();
        else if(cTab[codeindex].sign==FUNDEFV||cTab[codeindex].sign==FUNDEFI||cTab[codeindex].sign==FUNDEFC) fundefmips();
        else if(cTab[codeindex].sign==FUNEND) funendmips();
        else if(cTab[codeindex].sign==RET) retmips();
        else if(cTab[codeindex].sign==CALL) callmips();
        else if(cTab[codeindex].sign==ASS) assmips();
        else if(cTab[codeindex].sign==ASSF) assfmips();
        else if(cTab[codeindex].sign==JUMP) jumpmips();
        else if(cTab[codeindex].sign==JAL) jalmips();
        else if(cTab[codeindex].sign==LABEL) labelmips();
        else if(cTab[codeindex].sign==VPARA) vparamips();
    }
}

#endif // _MIPS_H_
