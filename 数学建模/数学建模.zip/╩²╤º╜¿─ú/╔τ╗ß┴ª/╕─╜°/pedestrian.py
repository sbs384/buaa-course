import numpy as np
import random
import math
from function import *


MASS=80.0
RADIUS=0.3 #行人实际的尺寸
DESIREDV=0.8 #查看文献改动(relax)
INIDIRECTION=np.array([0.0,0.0])
INIACTUALV=np.array([0.0,0.0])
ACTIME=0.008
BFACTOR=37000
FFACTOR=240000
PARAA=2000
PARAB=0.08

def initseed():
    random.seed()
            


class pede(object):
    
    #构造方法
    def __init__(self,num,pedeset):

      
        self.initcoord()
        while self.checkcoord(pedeset)==1:
            self.initcoord()
       

            
        #颜色设置
        if self.x>=10:
            self.color="yellow"
        else:
            self.color="red"
            
        
        #最近出口选择
        self.kind=self.nearestdest(self.x,self.y)
        if self.kind==0:
            self.mapdest=[19,51]
        else:
            self.mapdest=[41,24]


        self.mass = MASS
        self.radius = RADIUS
        self.desV = DESIREDV
        self.actV = INIACTUALV
        self.acTime = ACTIME
        self.dir = INIDIRECTION #期望方向
        self.bFactor = BFACTOR
        self.fFactor = FFACTOR
        self.A = PARAA
        self.B = PARAB
        self.num=num #行人编号
        self.sign=0
        self.path=[]

    def nearestdest(self,x,y):
        dist1=np.linalg.norm(np.array([x,y])-np.array([20.6,7.8])) #右出口
        dist2=np.linalg.norm(np.array([x,y])-np.array([9.8,16.6]))#左出口
        if dist1<=dist2:
            return 0
        else:
            return 1
    
    def drivForce(self): #计算驱动力
        diffV = self.desV*self.dir - self.actV #速度向量之差
        return diffV*self.mass/self.acTime

    
    def pedeForce(self,pedeset):
        #计算心理力，这里在之后修正：前方后方；一定范围内的行人才算
        pedeForce=0
        sumForce=0
        c=0.6
        
        for pedetemp in pedeset:
            if pedetemp.num!=self.num and pedetemp.sign==0:
                rij = self.radius+pedetemp.radius
                dij = np.linalg.norm(self.pos-pedetemp.pos)
                if dij==0:
                    nij = self.pos-pedetemp.pos
                else:
                    nij = (self.pos-pedetemp.pos)/dij
                diffVn = np.dot((pedetemp.actV-self.actV),nij)
                
                psycoForce = (1+c*g(diffVn))*self.A*np.exp((rij-dij)/self.B)
                bodyForce = self.bFactor*g(rij-dij)

                tij = np.array([-nij[1],nij[0]])
                diffV = np.dot((pedetemp.actV-self.actV),tij)
                fricForce = self.fFactor*g(rij-dij)*diffV*tij

                sumForce = (psycoForce+bodyForce)*nij+fricForce
                pedeForce=pedeForce+sumForce
        return pedeForce

    
    def obForce(self,wallset):
        obForce = 0
        sumForce=0
        c=0.6

        for i,wall in enumerate(wallset):
            if i<22:
                diw,niw = nearestwall(self.pos,wall)
            else:
                diw,niw=nearestcircle(self.pos,wall)
            diffVn=np.dot(-self.actV,niw)
                
                
            ri=self.radius
            tiw = np.array([-niw[1],niw[0]])

            psycoForce = self.A*np.exp((ri-diw)/self.B)*(1+c*g(diffVn))
            bodyForce = self.bFactor*g(ri-diw)
            fricForce=self.fFactor*g(ri-diw)*np.dot(self.actV,tiw)*tiw
            sumForce=(psycoForce+bodyForce)*niw-fricForce
            obForce=obForce+sumForce
        return obForce

    
    def initcoord(self):
        #设置行人初始位置
        self.zone=random.randint(1,12)
        if self.zone==6:
            self.x = random.uniform(0.8+RADIUS,7.2-RADIUS)
            self.y = random.uniform(0.8+RADIUS,11.2-RADIUS)
        elif self.zone==2:
            self.x = random.uniform(0.8++RADIUS,2.4-RADIUS)
            self.y = random.uniform(11.2+RADIUS,15.2-RADIUS)
        elif self.zone==3:
            self.x = random.uniform(2.4+RADIUS,4.8-RADIUS)
            self.y = random.uniform(12.0+RADIUS,15.2-RADIUS)
        elif self.zone==4:
            self.x = random.uniform(4.9+RADIUS,7.2-RADIUS)
            self.y = random.uniform(11.2+RADIUS,15.2-RADIUS)
        elif self.zone==5:
            self.x = random.uniform(7.2+RADIUS,19.2-RADIUS)
            self.y = random.uniform(11.0+RADIUS,15.2-RADIUS)
        elif self.zone==1:
            self.x = random.uniform(12.9+RADIUS,14.4-RADIUS)
            self.y = random.uniform(2.8+RADIUS,10.8-RADIUS)
        elif self.zone==7:
            self.x = random.uniform(14.4+RADIUS,17.6-RADIUS)
            self.y = random.uniform(7.1,10.5)
        elif self.zone==8:
            self.x = random.uniform(17.6+RADIUS,19.2-RADIUS)
            self.y = random.uniform(2.8+RADIUS,10.8-RADIUS)
        elif self.zone==9:
            self.x = random.uniform(7.2+RADIUS,19.2-RADIUS)
            self.y = random.uniform(0.8+RADIUS,2.8-RADIUS)
        elif self.zone==10:
            self.x = random.uniform(7.2+RADIUS,8.8-RADIUS)
            self.y = random.uniform(3.6+RADIUS,5.2-RADIUS)
        elif self.zone==11:
            self.x = random.uniform(8.8+RADIUS,11.2-RADIUS)
            self.y = random.uniform(2.8+RADIUS,5.2-RADIUS)
        else:
            self.x = random.uniform(11.2+RADIUS,12.8-RADIUS)
            self.y = random.uniform(3.6+RADIUS,5.2-RADIUS)

        self.pos = np.array([self.x,self.y])
       
        

    def checkcoord(self,pedeset):
        for pede in pedeset:
            if np.linalg.norm(pede.pos-self.pos)<0.9:
                return 1
        return 0
            
                
                    
        

     
            
