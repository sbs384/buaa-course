import tkinter
import time


CANVASWIDTH = 700
CANVASHEIGHT = 600
BACKGROUNDCOLOR = "black"
OBSTACLECOLOR = "grey"
GRASSCOLOR="green"
LAKECOLOR="blue"
OBSTACLEST = [[100,100,600,120],   #1
                [100,120,120,480], #2
                #[100,480,300,500], #3
                [100,480,330,500],
                #[400,480,600,500], #4
                [360,480,600,500],
                [580,120,600,270], #5 
                [580,330,600,480], #6 
                [160,380,220,400], #7
                [280,170,320,190], #8
                [380,170,420,190], #9
                [460,170,540,270]] #10


                    
tk = tkinter.Tk()
cv = tkinter.Canvas(tk,
                    width = CANVASWIDTH,
                    height = CANVASHEIGHT,
                    bd = 0,
                    bg = BACKGROUNDCOLOR,)
balls = []
texts = []

    
class GUI:
    def __init__(self):
        tk.title("Social Force Model")
        cv.pack()
        tk.update()

    def Real2ScreenPos(self,RealPos):
        ScreenPos = [a/0.04+100 for a in RealPos]
        return ScreenPos
        

    def Real2ScreenR(self,RealR):
        return RealR/0.04

    def init_obstacles(self):     
        for i,obstacle in enumerate(OBSTACLEST):
            if i==6 or i==7 or i==8:
                cv.create_rectangle(obstacle,fill = GRASSCOLOR)
            else:
                cv.create_rectangle(obstacle,fill = OBSTACLECOLOR)
        cv.create_oval([280,230],[420,370],fill = LAKECOLOR) #11
        

    def init_balls(self,pos,radius,color):
        pos = self.Real2ScreenPos(pos)
        radius = self.Real2ScreenR(radius)
        left = [c-radius for c in pos]
        right = [c+radius for c in pos]
        ball = cv.create_oval(left,right,fill = color)
        balls.append(ball)
        tk.update_idletasks()
        tk.update()
       
        
    def move(self,num,pos,radius):
        p = self.Real2ScreenPos(pos)
        r = self.Real2ScreenR(radius)
        left = [c-r for c in p]
        right = [c+r for c in p]
        left.extend(right)
        ballnum = balls[num]
        cv.coords(ballnum,left)
        #tk.update_idletasks()
        #tk.update()

    def refresh(self):
        tk.update_idletasks()
        tk.update()
        
    def deleteball(self,num):
        cv.delete(balls[num])
        
