import numpy as np

    
def g(x):
    if x>0:
        #print(x)
        return x
    else:
        return 0


# 计算点到线段的距离，并计算由点到与线段交点的单位向量
def nearestwall(pede, wall):
    point0 = np.array([wall[0],wall[1]])
    point1 = np.array([wall[2],wall[3]])
    line = point1-point0
    pointline = pede-point0
        
    t = np.dot(line,pointline)/np.dot(line,line)
    if t <= 0.0:
        dist = np.sqrt(np.dot(pointline,pointline))
        cross = point0 + t*line
    elif t >= 1.0:
        pointline1 = pede-point1
        dist = np.sqrt(np.dot(pointline1,pointline1))
        cross = point0 + t*line
    else:
        cross = point0 + t*line
        dist = np.linalg.norm(cross-pede)
            
    niw = normalize(pede-cross)
    return dist,niw


def nearestcircle(pede,wall):
    dist=np.linalg.norm(np.array([10,8])-pede)-2.8
    niw=normalize(pede-np.array([10,8]))
    return dist,niw


def normalize(v):
    norm=np.linalg.norm(v)
    if norm==0:
        return v
    return v/norm



