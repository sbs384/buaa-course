import numpy as np
import random
import math
from function import *


MASS=80.0
RADIUS=0.3 #行人实际的尺寸
DESIREDV=2 #查看文献改动(relax)
INIDIRECTION=np.array([0.0,0.0])
INIACTUALV=np.array([0.0,0.0])
ACTIME=0.008
BFACTOR=120000
FFACTOR=240000
PARAA=2000
PARAB=0.08
#发生错误的坐标样例
coord=[[1.88808234,13.46550456],
    [1.95477757,14.40271604],
    [1.20691493,13.02425092],
    [1.43552348,11.93804846],
    [1.93763882,12.33488017]]


def initseed():
    random.seed()
            


class pede(object):
    
    #构造方法
    def __init__(self,num,pedeset):

        self.num=num
        
        
        self.initcoord()
        while self.checkcoord(pedeset)==1:
            self.initcoord()
        
                
        #颜色设置
        if self.num>19:
            self.color="yellow"
        else:
            self.color="red"
            
        
        #最近出口选择
        if self.num<=19:
            self.mapdest=[math.floor(self.y/0.4),49]
        else:
            self.mapdest=[math.floor(self.y/0.4),0]

        
        self.mass = MASS
        self.radius = RADIUS
        self.desV = DESIREDV
        self.actV = INIACTUALV
        self.acTime = ACTIME
        self.dir = INIDIRECTION #期望方向
        self.bFactor = BFACTOR
        self.fFactor = FFACTOR
        self.A = PARAA
        self.B = PARAB
        self.num=num #行人编号
        self.sign=0
        self.path=[]


    
    def drivForce(self): #计算驱动力
        diffV = self.desV*self.dir - self.actV #速度向量之差
        return diffV*self.mass/self.acTime

    
    def pedeForce(self,pedeset):
        pedeForce=0
        sumForce=0
        c=0.0
        
        for pedetemp in pedeset:
            if pedetemp.num!=self.num and pedetemp.sign==0:
                rij = self.radius+pedetemp.radius
                dij = np.linalg.norm(self.pos-pedetemp.pos)
                if dij==0:
                    nij = self.pos-pedetemp.pos
                else:
                    nij = (self.pos-pedetemp.pos)/dij
               
                psycoForce = self.A*np.exp((rij-dij)/self.B)
                bodyForce = self.bFactor*g(rij-dij)

                tij = np.array([-nij[1],nij[0]])
                diffV = np.dot((pedetemp.actV-self.actV),tij)
                fricForce = self.fFactor*g(rij-dij)*diffV*tij

                sumForce = (psycoForce+bodyForce)*nij+fricForce
                pedeForce=pedeForce+sumForce
        return pedeForce

    
    def obForce(self,wallset):
        obForce = 0
        sumForce=0

        for i,wall in enumerate(wallset):
            if i<22:
                diw,niw = nearestwall(self.pos,wall)
            else:
                diw,niw=nearestcircle(self.pos,wall)
                
                
            ri=self.radius
            tiw = np.array([-niw[1],niw[0]])
            

            psycoForce = self.A*np.exp((ri-diw)/self.B)
            bodyForce = self.bFactor*g(ri-diw)

            fricForce=self.fFactor*g(ri-diw)*np.dot(self.actV,tiw)*tiw
            sumForce=(psycoForce+bodyForce)*niw-fricForce
            obForce=obForce+sumForce
        return obForce

    
    def initcoord(self):
        #设置行人初始位置
      
        self.x=random.uniform(0.3,19.7)
        self.y=random.uniform(2.1,12.9)
        self.pos = np.array([self.x,self.y])
        
       
        

    def checkcoord(self,pedeset):
        for pede in pedeset:
            if np.linalg.norm(pede.pos-self.pos)<1:
                return 1
        return 0
            
                
                    
        

     
            
