import numpy as np
import sys
import random
import time
import math
from GUI import*
from pedestrian import *
from function import*
from Astar import*

'''
定义一些量
'''
#定义障碍物坐标，目的地坐标,行人信息及GUI信息
wallset = [[0,0.8,20,0.8],
           [0.0,15.2,20.0,15.2]]


PEDESIZE=0.3 #定义行人半径
PEDENUM=40  #定义行人数目
ACCTIME=0.008 #定义适应时间


#定义地图量
MAPLINE=40   #地图行尺寸   
MAPCOL=50    #地图列尺寸
MAPPASS=0    #表示可通行点
MAPOB=1      #值表示障碍物

#设置随机数



#main函数
if __name__== '__main__':
    time_start=time.time()
    timesum=0

    stop=0
    pedeset=[]
    pedevrset=[]
    pedenum=0
    
    
    #初始化行人集合
    initseed()
    for i in range(PEDENUM):
        pedenew=pede(pedenum,pedeset)
        pedeset.append(pedenew)
        pedevrset.append([0,0])
        pedenum=pedenum+1
        #print(pedenew.pos)

        
    #初始化地图
    mapgri = np.full((MAPLINE, MAPCOL), int(MAPPASS), dtype=np.int8) #栅格地图
    mapgri[0:2,0:50]=MAPOB
    mapgri[48:50,0:50]=MAPOB

    
    
    #初始化GUI界面
    gui=GUI()
    gui.init_obstacles()
    for pede in pedeset:  #行人
        gui.init_balls([pede.pos[0],pede.pos[1]],PEDESIZE,pede.color)
    


    
    while True:
    
        #事件检测
        #运行结束
        #if pointx>=19 and pointy>=51:
            #break
        
        if stop==PEDENUM:
            break

        for  pede in pedeset:
            
            if pede.sign==1:
                continue
            
            #行人初始速度及位置
            
        
            v0 = pede.actV
            pos0 = pede.pos
            
            
            #行人预期方向
            astary=math.floor(pede.pos[0]/0.4)
            astarx=math.floor(pede.pos[1]/0.4)
            #print("start1:",pede.pos[0],pede.pos[1])
            #print("start2:",astarx,astary)
            lenpath=len(pede.path)

            #需要重新搜索A*的情况
            if lenpath==0:
                #print("A*")
                pede.path=astar(mapgri,(astarx,astary),(pede.mapdest[0],pede.mapdest[1]))
                if type(pede.path)==bool:
                    print(pede.num)
                    sys.exit(1)
            else:
                if (astarx,astary)!=pede.path[lenpath-1]:
                    if (astarx,astary)==pede.path[lenpath-2]:
                        pede.path.pop(lenpath-1)
                    else:
                        #print("A*")
                        pede.path=astar(mapgri,(astarx,astary),(pede.mapdest[0],pede.mapdest[1]))
                        if type(pede.path)==bool:
                            print(pede.num)
                            sys.exit(1)
                            
            pointx=pede.path[len(pede.path)-2][0]
            pointy=pede.path[len(pede.path)-2][1]
            
            py=pointx*0.4+0.2
            px=pointy*0.4+0.2
            
            dirtemp=np.array([px,py])-pede.pos
            dirtempl=np.linalg.norm(dirtemp)
            if(dirtempl!=0):
                dirtemp=dirtemp/dirtempl
            pede.dir=dirtemp
            

            #行人得到的社会力总和
            drivef=pede.drivForce()
            pedef=pede.pedeForce(pedeset)
            wallf=pede.obForce(wallset)
            sumForce =drivef+pedef+wallf
            accler=sumForce/pede.mass
    

            #更新行人速度和位置
            v=v0+accler*ACCTIME
            pos=pos0+v*ACCTIME
            pedevrset[pede.num]=[v,pos]
            
        
        timesum=timesum+0.008  
        
        for pede in pedeset:
            #gui.move(pede.num,pede.pos,PEDESIZE)
              
            pede.actV=pedevrset[pede.num][0]
            pede.pos=pedevrset[pede.num][1]
            gui.move(pede.num,[pede.pos[0],pede.pos[1]],PEDESIZE)

            if (pede.num<=19 and pede.pos[0]>19.6) or (pede.num>19 and pede.pos[0]<=0.2):
                if pede.sign==0:
                    stop=stop+1
                    pede.sign=1
                    gui.deleteball(pede.num)
        
            
    
        gui.refresh()
        
        
        
        
    print("timeideal",timesum)
   
    sys.exit(0)
