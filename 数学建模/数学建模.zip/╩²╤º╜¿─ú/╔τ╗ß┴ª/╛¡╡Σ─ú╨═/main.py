import numpy as np
import sys
import random
import time
import math
from GUI import*
from pedestrian import *
from function import*
from Astar import*

'''
定义一些量
'''
#定义障碍物坐标，目的地坐标,行人信息及GUI信息
wallset = [[0.8,0.8,19.2,0.8],      #1
            [0.8,0.8,0.8,15.2],     #2
            [0.8,15.2,9.2,15.2],     #3
            [10.4,15.2,19.2,15.2],   #4
            [19.2,0.8,19.2,6.8],    #5
            [19.2,9.2,19.2,15.2],   #6
            [2.4,11.2,2.4,12],      #7l
            [14.8,11.2,14.8,12],    #7r
            [2.4,11.2,4.8,11.2],    #7u
            [2.4,12,4.8,12],        #7d
            [7.2,2.8,7.2,3.6],      #8l
            [8.8,2.8,8.8,3.6],      #8r
            [7.2,2.8,8.8,2.8],      #8u
            [7.2,3.6,8.8,3.6],       #8d
            [11.2,2.8,11.2,3.6],     #9l
            [12.8,2.8,12.8,3.6],     #9r
            [11.2,2.8,12.8,2.8],     #9u
            [11.2,3.6,12.8,3.6],     #9d
            [14.4,2.8,14.4,6.8],     #10l
            [17.6,2.8,17.6,6.8],     #10r
            [14.4,2.8,17.6,2.8],     #10u
            [14.4,6.8,17.6,6.8],     #10d
            [10,2.8]]                #11


#DESTR=[20.6,7.8]
#DESTD=[9.8,16.6]
#MAPDESTR=[19,51]
#MAPDESTD=[41,24]
PEDESIZE=0.3 #定义行人半径
PEDENUM=20 #定义行人数目
ACCTIME=0.008 #定义适应时间


#定义地图量
MAPLINE=42   #地图行尺寸   
MAPCOL=52    #地图列尺寸
MAPPASS=0    #表示可通行点
MAPOB=1      #值表示障碍物


#设置随机数



#main函数
if __name__== '__main__':
    time_start=time.time()
    timesum=0

    stop=0
    pedeset=[]
    pedevrset=[]
    pedenum=0
    
    
    #初始化行人集合
    initseed()
    for i in range(PEDENUM):
        pedenew=pede(pedenum,pedeset)
        pedeset.append(pedenew)
        pedevrset.append([0,0])
        pedenum=pedenum+1

        
    #初始化地图
    mapgri = np.full((MAPLINE, MAPCOL), int(MAPPASS), dtype=np.int8) #栅格地图
    mapgri[0:2,0:50]=MAPOB    #1 定义障碍物点
    mapgri[2:38,0:2]=MAPOB    #2
    #mapgri[38:40,0:20]=MAPOB  #3
    mapgri[38:40,0:23]=MAPOB  
    #mapgri[38:40,30:60]=MAPOB #4
    mapgri[38:40,26:60]=MAPOB 
    mapgri[2:17,48:50]=MAPOB  #5
    mapgri[23:38,48:50]=MAPOB #6
    mapgri[28:30,6:12]=MAPOB  #7
    mapgri[7:9,18:22]=MAPOB  #8
    mapgri[7:9,28:32]=MAPOB  #9
    mapgri[7:17,36:44]=MAPOB #10
    mapgri[13:27,18:32]=MAPOB #11

    
    #初始化GUI界面
    gui=GUI()
    gui.init_obstacles()  #窗口和障碍物
    for pede in pedeset:  #行人
        gui.init_balls([pede.pos[0],pede.pos[1]],PEDESIZE,pede.color)
    


    timestart=time.time()
    while True:
    
        #事件检测
        #运行结束
        #if pointx>=19 and pointy>=51:
            #break
        
        if stop==PEDENUM:
            break

        for  pede in pedeset:
            
            if pede.sign==1:
                continue
            
            #行人初始速度及位置
            
        
            v0 = pede.actV
            pos0 = pede.pos
            
            
            
            #行人预期方向
            astary=math.floor(pede.pos[0]/0.4)
            astarx=math.floor(pede.pos[1]/0.4)
            lenpath=len(pede.path)

            #需要重新搜索A*的情况
            if lenpath==0:
                #print("A*")
                pede.path=astar(mapgri,(astarx,astary),(pede.mapdest[0],pede.mapdest[1]))
                if type(pede.path)==bool:
                    print(pede.num)
                    sys.exit(1)
            else:
                if (astarx,astary)!=pede.path[lenpath-1]:
                    if (astarx,astary)==pede.path[lenpath-2]:
                        pede.path.pop(lenpath-1)
                    else:
                        #print("A*")
                        pede.path=astar(mapgri,(astarx,astary),(pede.mapdest[0],pede.mapdest[1]))
                        if type(pede.path)==bool:
                            print(pede.num)
                            sys.exit(1)

    
            pointx=pede.path[len(pede.path)-2][0]
            pointy=pede.path[len(pede.path)-2][1]
            
            py=pointx*0.4+0.2
            px=pointy*0.4+0.2
            
            dirtemp=np.array([px,py])-pede.pos
            dirtempl=np.linalg.norm(dirtemp)
            if(dirtempl!=0):
                dirtemp=dirtemp/dirtempl
            pede.dir=dirtemp
            

            #行人得到的社会力总和
            drivef=pede.drivForce()
            pedef=pede.pedeForce(pedeset)
            wallf=pede.obForce(wallset)
            sumForce =drivef+pedef+wallf
            accler=sumForce/pede.mass
    

            #更新行人速度和位置
            v=v0+accler*ACCTIME
            pos=pos0+v*ACCTIME
            pedevrset[pede.num]=[v,pos]
            
            
        
        timesum=timesum+0.008  
        
        for pede in pedeset:
            pede.actV=pedevrset[pede.num][0]
            pede.pos=pedevrset[pede.num][1]
            gui.move(pede.num,[pede.pos[0],pede.pos[1]],PEDESIZE)

            if (pede.kind==0 and pede.pos[0]>=20.6) or (pede.kind==1 and pede.pos[1]>=16.6):
                if pede.sign==0:
                    stop=stop+1
                    pede.sign=1
                    gui.deleteball(pede.num)
        
            
    
        gui.refresh()
        
        
        
    timeend=time.time()
    timeresult=timeend-timestart
    print("s",timesum)
    print(timeresult)
   
    sys.exit(0)
