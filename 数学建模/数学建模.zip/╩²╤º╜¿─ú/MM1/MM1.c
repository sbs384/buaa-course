#include <stdio.h>
#include <stdlib.h>
#include <math.h> 

#define ARRIVE 0
#define DEPAR 1
#define IDLE   0
#define OCCUPY 1

int queueMax,queueLength=0,custNum,custNumQueue=0,busy=IDLE; 
double clock=0,sumDelay=0,sumServe=0;


typedef struct eventNode{
	int type,id;
	double arriveTime;
	double serveTime;
	double deparTime;
	
	struct eventNode* nextLink; 
}event;
event* queueTail;

struct eventHeadNode{
	struct eventNode* eventLink ;
};
struct eventHeadNode* eventHead;


struct queueHeadNode{
	struct eventNode* queueLink;
};
struct queueHeadNode* queueHead;

double U_Random();
double possion(int lambdaArrive);
double exponential(double lambdaServe);
void initialFEL(int lambdaArrive,double lambdaServe);
void serve();
void placeEvent(event* eventTemp);
void addQueue(event* eventTemp);
void destroyEventHead(event* eventTemp);
event* popQueue();
void bl();

double U_Random()  
{
  double f;
  f = (float)(rand() % 100);
 
  return f/100;
}


double possion(int lambdaArrive){
	int k=0;
	long double p=1.0;
	long double l=exp(-lambdaArrive);
	
	
	while(p>=l){
		double u = U_Random();
		p*=u;
		k++;
	}
	return k-1;
}

double exponential(double lambdaServe){
	double u;
	
	do{
		u=(double)(rand()%100)/100;
	}while(u==0);
	u=(-1/lambdaServe)*log(u);
	return u;
}

void initialFEL(int lambdaArrive,double lambdaServe){
	int i;
	double sumTime=0;
	event* eventCur;

	for(i=0;i<custNum;i++){
		if(eventHead->eventLink==NULL){
			eventCur=(event*)malloc(sizeof(event));
			eventCur->type=ARRIVE;
			eventCur->arriveTime=possion(lambdaArrive);
			eventCur->serveTime=exponential(lambdaServe);
			eventCur->deparTime=-1;
			eventCur->nextLink=NULL;
			eventCur->id=i;
			eventHead->eventLink=eventCur;
			sumTime=eventCur->arriveTime;
		}
		else{
			eventCur->nextLink=(event*)malloc(sizeof(event));
			eventCur=eventCur->nextLink;
			eventCur->type=ARRIVE;
			sumTime+=possion(lambdaArrive);
			eventCur->arriveTime=sumTime;
			eventCur->serveTime=exponential(lambdaServe);
			eventCur->deparTime=-1;
			
			eventCur->nextLink=NULL;
			eventCur->id=i;
		}
		printf("%d�Ź˿͵���ʱ�䣺%lf������ʱ�䣺%lf\n",eventCur->id,eventCur->arriveTime,eventCur->serveTime);
	}	
	
}

void serve(){
	event* eventCur;
	while(eventHead->eventLink!=NULL){
		eventCur=eventHead->eventLink;
		
		if(eventCur->type==ARRIVE){
			clock=eventCur->arriveTime;
		
			if(busy==IDLE){
				busy=OCCUPY;
				eventCur->deparTime=clock+eventCur->serveTime;
				eventCur->type=DEPAR;
				
				destroyEventHead(eventCur);
				placeEvent(eventCur);
			}
			else{
				if(queueLength<queueMax){
					destroyEventHead(eventCur);
					addQueue(eventCur);
					 
					custNumQueue++;
					queueLength++;
				}
				else{
					destroyEventHead(eventCur);
					free(eventCur);
				}
			}
		}
		
		else{
			clock=eventCur->deparTime;
			printf("%d�Ź˿��뿪ʱ�䣺%lf\n",eventCur->id,eventCur->deparTime); 
			
			sumServe+=eventCur->serveTime;
			destroyEventHead(eventCur);
			free(eventCur);
			
			if(queueHead->queueLink==NULL){
				busy=IDLE;
			}	
			else{
				eventCur=popQueue();
				eventCur->deparTime=clock+eventCur->serveTime;
				eventCur->type=DEPAR;
				placeEvent(eventCur);
				
				sumDelay+=clock-eventCur->arriveTime;
				queueLength--;
			}		
		}
	}
}

void placeEvent(event* eventTemp){
	event* eventP,*eventL;
	eventL=eventHead->eventLink;
	
	if(eventL!=NULL){
		for(;eventL!=NULL;eventL=eventL->nextLink){
			if(eventL->arriveTime>=eventTemp->deparTime||eventL->deparTime>=eventTemp->deparTime){
				if(eventL==eventHead->eventLink){
					eventTemp->nextLink=eventHead->eventLink;
					eventHead->eventLink=eventTemp;
				}
				else{
					eventTemp->nextLink=eventP->nextLink;
					eventP->nextLink=eventTemp;
				}
				break;
			}
			eventP=eventL;
		}
		if(eventL==NULL) eventP->nextLink=eventTemp;
	}
	
	else eventHead->eventLink=eventTemp;
}

void addQueue(event* eventTemp){
	if(queueHead->queueLink==NULL) queueHead->queueLink=eventTemp;
	else queueTail->nextLink=eventTemp;
	queueTail=eventTemp;
}

void destroyEventHead(event* eventTemp){
	eventHead->eventLink=eventTemp->nextLink;
	eventTemp->nextLink=NULL;
}

event* popQueue(){
	event* eventTemp=queueHead->queueLink;
	queueHead->queueLink=eventTemp->nextLink;
	eventTemp->nextLink=NULL;
	return eventTemp;
}

void bl(){
	event* eventbl;
	eventbl=eventHead->eventLink;
	printf("\\\\\\\\\\\n");
	for(;eventbl!=NULL;eventbl=eventbl->nextLink){
		printf("eventbl->id:%d\n",eventbl->id);
	}
	printf("\\\\\\\\\\\n");
}

int main(){
	int i,lambdaArrive;
	double lambdaServe,average_number_of_customer,average_delay_in_queue,utilisation_of_serve;
	
     
	//input 
	printf("������ƽ������ʱ��lambda������\n");
	scanf("%d",&lambdaArrive);
	printf("������ƽ������ʱ��lambda������\n");
	scanf("%lf",&lambdaServe);
	printf("��������г��ȣ�\n");
	scanf("%d",&queueMax);
	printf("������˿���Ŀ��\n");
	scanf("%d",&custNum);
	
	eventHead=(struct eventHeadNode*)malloc(sizeof(struct eventHeadNode));
	queueHead=(struct queueHeadNode*)malloc(sizeof(struct queueHeadNode)); 
	eventHead->eventLink=NULL;
	queueHead->queueLink=NULL;
	
	srand((unsigned)time(NULL));
	initialFEL(lambdaArrive,lambdaServe);
    printf("\n");
	serve();
	printf("\n");
	
	average_delay_in_queue=sumDelay/custNumQueue;
	average_number_of_customer=sumDelay/clock;
	utilisation_of_serve=sumServe/clock;
	 
	printf("���ӳ�ʱ��%lf\n",sumDelay);
	printf("��ǰʱ��%lf\n",clock);
	printf("�ܷ���ʱ��%lf\n",sumServe);
	printf("\n"); 
	
	printf("ƽ���ȴ�ʱ�䣺%lf\n",average_delay_in_queue);
	printf("������ƽ���˿�����%lf\n",average_number_of_customer);
	printf("�����������ʣ�%lf\n",utilisation_of_serve); 
	
}

